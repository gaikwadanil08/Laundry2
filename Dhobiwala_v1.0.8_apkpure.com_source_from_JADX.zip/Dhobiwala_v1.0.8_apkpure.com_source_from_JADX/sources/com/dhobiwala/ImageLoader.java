package com.dhobiwala;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.widget.ImageView;
import com.dhobiwala.Utils.Utils;
import com.google.firebase.appindexing.Indexable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ImageLoader {
    ExecutorService executorService;
    FileCache fileCache;
    Handler handler = new Handler();
    private Map<ImageView, String> imageViews = Collections.synchronizedMap(new WeakHashMap());
    MemoryCache memoryCache = new MemoryCache();
    final int stub_id = C0354R.mipmap.ic_launcher;

    class BitmapDisplayer implements Runnable {
        Bitmap bitmap;
        PhotoToLoad photoToLoad;

        public BitmapDisplayer(Bitmap bitmap, PhotoToLoad photoToLoad) {
            this.bitmap = bitmap;
            this.photoToLoad = photoToLoad;
        }

        public void run() {
            if (!ImageLoader.this.imageViewReused(this.photoToLoad)) {
                if (this.bitmap != null) {
                    this.photoToLoad.imageView.setImageBitmap(this.bitmap);
                } else {
                    this.photoToLoad.imageView.setImageResource(C0354R.mipmap.ic_launcher);
                }
            }
        }
    }

    private class PhotoToLoad {
        public ImageView imageView;
        public String url;

        public PhotoToLoad(String str, ImageView imageView) {
            this.url = str;
            this.imageView = imageView;
        }
    }

    class PhotosLoader implements Runnable {
        PhotoToLoad photoToLoad;

        PhotosLoader(PhotoToLoad photoToLoad) {
            this.photoToLoad = photoToLoad;
        }

        public void run() {
            try {
                if (!ImageLoader.this.imageViewReused(this.photoToLoad)) {
                    Bitmap access$000 = ImageLoader.this.getBitmap(this.photoToLoad.url);
                    ImageLoader.this.memoryCache.put(this.photoToLoad.url, access$000);
                    if (!ImageLoader.this.imageViewReused(this.photoToLoad)) {
                        ImageLoader.this.handler.post(new BitmapDisplayer(access$000, this.photoToLoad));
                    }
                }
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
    }

    public ImageLoader(Context context) {
        this.fileCache = new FileCache(context);
        this.executorService = Executors.newFixedThreadPool(5);
    }

    public void DisplayImage(String str, ImageView imageView) {
        this.imageViews.put(imageView, str);
        Bitmap bitmap = this.memoryCache.get(str);
        if (bitmap != null) {
            imageView.setImageBitmap(bitmap);
            return;
        }
        queuePhoto(str, imageView);
        imageView.setImageResource(C0354R.mipmap.ic_launcher);
    }

    private void queuePhoto(String str, ImageView imageView) {
        this.executorService.submit(new PhotosLoader(new PhotoToLoad(str, imageView)));
    }

    private Bitmap getBitmap(String str) {
        File file = this.fileCache.getFile(str);
        Bitmap decodeFile = decodeFile(file);
        if (decodeFile != null) {
            return decodeFile;
        }
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            httpURLConnection.setConnectTimeout(Indexable.MAX_BYTE_SIZE);
            httpURLConnection.setReadTimeout(Indexable.MAX_BYTE_SIZE);
            httpURLConnection.setInstanceFollowRedirects(true);
            InputStream inputStream = httpURLConnection.getInputStream();
            OutputStream fileOutputStream = new FileOutputStream(file);
            Utils.CopyStream(inputStream, fileOutputStream);
            fileOutputStream.close();
            httpURLConnection.disconnect();
            return decodeFile(file);
        } catch (String str2) {
            str2.printStackTrace();
            if ((str2 instanceof OutOfMemoryError) != null) {
                this.memoryCache.clear();
            }
            return null;
        }
    }

    private android.graphics.Bitmap decodeFile(java.io.File r7) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
        /*
        r6 = this;
        r0 = 0;
        r1 = new android.graphics.BitmapFactory$Options;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r1.<init>();	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r2 = 1;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r1.inJustDecodeBounds = r2;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r3 = new java.io.FileInputStream;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r3.<init>(r7);	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        android.graphics.BitmapFactory.decodeStream(r3, r0, r1);	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r3.close();	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r3 = r1.outWidth;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r1 = r1.outHeight;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
    L_0x0018:
        r4 = r3 / 2;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r5 = 1024; // 0x400 float:1.435E-42 double:5.06E-321;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        if (r4 < r5) goto L_0x002a;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
    L_0x001e:
        r4 = r1 / 2;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        if (r4 >= r5) goto L_0x0023;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
    L_0x0022:
        goto L_0x002a;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
    L_0x0023:
        r3 = r3 / 2;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r1 = r1 / 2;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r2 = r2 * 2;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        goto L_0x0018;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
    L_0x002a:
        r1 = new android.graphics.BitmapFactory$Options;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r1.<init>();	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r1.inSampleSize = r2;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r2 = new java.io.FileInputStream;	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r2.<init>(r7);	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r7 = android.graphics.BitmapFactory.decodeStream(r2, r0, r1);	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        r2.close();	 Catch:{ FileNotFoundException -> 0x0042, IOException -> 0x003e }
        return r7;
    L_0x003e:
        r7 = move-exception;
        r7.printStackTrace();
    L_0x0042:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.dhobiwala.ImageLoader.decodeFile(java.io.File):android.graphics.Bitmap");
    }

    boolean imageViewReused(PhotoToLoad photoToLoad) {
        String str = (String) this.imageViews.get(photoToLoad.imageView);
        if (str != null) {
            if (str.equals(photoToLoad.url) != null) {
                return null;
            }
        }
        return true;
    }

    public void clearCache() {
        this.memoryCache.clear();
        this.fileCache.clear();
    }
}
