package com.dhobiwala.Utils;

public class Utils {
    public static void CopyStream(java.io.InputStream r5, java.io.OutputStream r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
        /*
        r0 = 1024; // 0x400 float:1.435E-42 double:5.06E-321;
        r1 = new byte[r0];	 Catch:{ Exception -> 0x0011 }
    L_0x0004:
        r2 = 0;	 Catch:{ Exception -> 0x0011 }
        r3 = r5.read(r1, r2, r0);	 Catch:{ Exception -> 0x0011 }
        r4 = -1;	 Catch:{ Exception -> 0x0011 }
        if (r3 != r4) goto L_0x000d;	 Catch:{ Exception -> 0x0011 }
    L_0x000c:
        goto L_0x0011;	 Catch:{ Exception -> 0x0011 }
    L_0x000d:
        r6.write(r1, r2, r3);	 Catch:{ Exception -> 0x0011 }
        goto L_0x0004;
    L_0x0011:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.dhobiwala.Utils.Utils.CopyStream(java.io.InputStream, java.io.OutputStream):void");
    }
}
