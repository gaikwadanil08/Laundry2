package com.dhobiwala.Utils;

import android.content.Context;
import android.os.Build.VERSION;
import android.provider.Settings.Secure;
import android.text.TextUtils;

public class AppUtils {

    public class LocationConstants {
        public static final int FAILURE_RESULT = 1;
        public static final String LOCATION_DATA_AREA = "com.dhobiwala.maplocation.LOCATION_DATA_AREA";
        public static final String LOCATION_DATA_CITY = "com.dhobiwala.maplocation.LOCATION_DATA_CITY";
        public static final String LOCATION_DATA_EXTRA = "com.dhobiwala.maplocation.LOCATION_DATA_EXTRA";
        public static final String LOCATION_DATA_STREET = "com.dhobiwala.maplocation.LOCATION_DATA_STREET";
        public static final String PACKAGE_NAME = "com.dhobiwala.maplocation";
        public static final String RECEIVER = "com.dhobiwala.maplocation.RECEIVER";
        public static final String RESULT_DATA_KEY = "com.dhobiwala.maplocation.RESULT_DATA_KEY";
        public static final int SUCCESS_RESULT = 0;
    }

    public static boolean hasLollipop() {
        return VERSION.SDK_INT >= 21;
    }

    public static boolean isLocationEnabled(Context context) {
        if (VERSION.SDK_INT < 19) {
            return TextUtils.isEmpty(Secure.getString(context.getContentResolver(), "location_providers_allowed")) ^ 1;
        }
        boolean z = false;
        try {
            context = Secure.getInt(context.getContentResolver(), "location_mode");
        } catch (Context context2) {
            context2.printStackTrace();
            context2 = null;
        }
        if (context2 != null) {
            z = true;
        }
        return z;
    }
}
