package com.dhobiwala.Utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.graphics.drawable.VectorDrawableCompat;
import android.support.v4.content.ContextCompat;

public class VectorDrawableUtils {
    public static Drawable getDrawable(Context context, int i) {
        if (VERSION.SDK_INT > 23) {
            return context.getResources().getDrawable(i, context.getTheme());
        }
        return VectorDrawableCompat.create(context.getResources(), i, context.getTheme());
    }

    public static Drawable getDrawable(Context context, int i, int i2) {
        i = getDrawable(context, i);
        i.setColorFilter(ContextCompat.getColor(context, i2), Mode.SRC_IN);
        return i;
    }

    public static Bitmap getBitmap(Context context, int i) {
        context = getDrawable(context, i);
        i = Bitmap.createBitmap(context.getIntrinsicWidth(), context.getIntrinsicHeight(), Config.ARGB_8888);
        Canvas canvas = new Canvas(i);
        context.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        context.draw(canvas);
        return i;
    }
}
