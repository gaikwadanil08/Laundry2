package com.dhobiwala.Utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;

public class SmsAutoVerification extends BroadcastReceiver {
    final SmsManager sms = SmsManager.getDefault();

    public void onReceive(Context context, Intent intent) {
        intent = intent.getExtras();
        if (intent != null) {
            try {
                Object[] objArr = (Object[]) intent.get("pdus");
                for (Object obj : objArr) {
                    SmsMessage createFromPdu = SmsMessage.createFromPdu((byte[]) obj);
                    String displayOriginatingAddress = createFromPdu.getDisplayOriginatingAddress();
                    String str = createFromPdu.getDisplayMessageBody().split(":")[1];
                    str = str.substring(0, str.length() - 1);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("senderNum: ");
                    stringBuilder.append(displayOriginatingAddress);
                    stringBuilder.append("; message: ");
                    stringBuilder.append(str);
                    Log.i("SmsReceiver", stringBuilder.toString());
                    Intent intent2 = new Intent("otp");
                    intent2.putExtra("message", str);
                    LocalBroadcastManager.getInstance(context).sendBroadcast(intent2);
                }
            } catch (Context context2) {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Exception smsReceiver");
                stringBuilder2.append(context2);
                Log.e("SmsReceiver", stringBuilder2.toString());
            }
        }
    }
}
