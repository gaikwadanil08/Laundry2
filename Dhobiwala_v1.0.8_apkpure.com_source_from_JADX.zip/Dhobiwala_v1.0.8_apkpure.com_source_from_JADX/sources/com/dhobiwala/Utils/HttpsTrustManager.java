package com.dhobiwala.Utils;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.http.conn.ssl.SSLSocketFactory;

public class HttpsTrustManager implements X509TrustManager {
    private static final X509Certificate[] _AcceptedIssuers = new X509Certificate[0];
    private static TrustManager[] trustManagers;

    public void checkClientTrusted(X509Certificate[] x509CertificateArr, String str) throws CertificateException {
    }

    public void checkServerTrusted(X509Certificate[] x509CertificateArr, String str) throws CertificateException {
    }

    public boolean isClientTrusted(X509Certificate[] x509CertificateArr) {
        return true;
    }

    public boolean isServerTrusted(X509Certificate[] x509CertificateArr) {
        return true;
    }

    public X509Certificate[] getAcceptedIssuers() {
        return _AcceptedIssuers;
    }

    public static void allowAllSSL() {
        SSLContext instance;
        NoSuchAlgorithmException e;
        KeyManagementException e2;
        HttpsURLConnection.setDefaultHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        if (trustManagers == null) {
            trustManagers = new TrustManager[]{new HttpsTrustManager()};
        }
        try {
            instance = SSLContext.getInstance("TLS");
            try {
                instance.init(null, trustManagers, new SecureRandom());
            } catch (NoSuchAlgorithmException e3) {
                e = e3;
                e.printStackTrace();
                HttpsURLConnection.setDefaultSSLSocketFactory(instance.getSocketFactory());
            } catch (KeyManagementException e4) {
                e2 = e4;
                e2.printStackTrace();
                HttpsURLConnection.setDefaultSSLSocketFactory(instance.getSocketFactory());
            }
        } catch (NoSuchAlgorithmException e5) {
            NoSuchAlgorithmException noSuchAlgorithmException = e5;
            instance = null;
            e = noSuchAlgorithmException;
            e.printStackTrace();
            HttpsURLConnection.setDefaultSSLSocketFactory(instance.getSocketFactory());
        } catch (KeyManagementException e6) {
            KeyManagementException keyManagementException = e6;
            instance = null;
            e2 = keyManagementException;
            e2.printStackTrace();
            HttpsURLConnection.setDefaultSSLSocketFactory(instance.getSocketFactory());
        }
        HttpsURLConnection.setDefaultSSLSocketFactory(instance.getSocketFactory());
    }
}
