package com.dhobiwala.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dhobiwala.Adapter.OrderDetailsAdapter;
import com.dhobiwala.C0354R;
import com.dhobiwala.Models.OrderDetailsData;
import com.dhobiwala.Models.Orientation;
import com.dhobiwala.Utils.HttpsTrustManager;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

public class MyOrderDetailsActivity extends AppCompatActivity {
    public static final String EXTRA_ORIENTATION = "EXTRA_ORIENTATION";
    public static final String EXTRA_WITH_LINE_PADDING = "EXTRA_WITH_LINE_PADDING";
    private static final String TAG_ORDER_CANCEL_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=order_cancel";
    private static final String TAG_ORDER_DETAILS_INVOICE_DETAILS_ARRAY = "invoice_details";
    private static final String TAG_ORDER_DETAILS_ORDER_DELIVERY_ARRAY = "order_delivery";
    private static final String TAG_ORDER_DETAILS_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=order_details_new";
    private TextView OrderDateTv;
    private TextView OrderIdTv;
    private TextView OrderServiceTv;
    private TextView OrderStatusTv;
    private String StrclientId;
    private String StrorderId;
    String TotalGarmentsStr;
    private TextView TotalGarmentsTv;
    private Button TrackYoueOrderBtn;
    OrderDetailsAdapter adapter;
    CardView cardview;
    private String customerNameStr;
    private String franchiseIdStr;
    private TextView franchiseIdTv;
    private Button garmentDetailsBtn;
    private String getOrderDate;
    private TextView invoiceCustomerName;
    private String invoiceDateStr;
    private TextView invoiceDateTv;
    private String invoiceNoStr;
    private TextView invoiceNumberTv;
    private TextView invoicePhoneTv;
    private String invoiceTotalStr;
    private TextView invoiceTotalTv;
    private Button orderCancelBtn;
    private RecyclerView orderDetailsRecyclerview;
    private String orderDetailsSuccess;
    List<OrderDetailsData> orderDetailsdata = new ArrayList();
    String orderId;
    String orderService;
    String orderStatus;
    String orderTotalInvoiceStr;
    private ArrayList<String> orderTrackingStatusList;
    private Button payBtn;
    private String paymentLinkStr;
    private String paymentStatusStr;
    private TextView paymentStatusTv;
    private String phoneStr;
    boolean pickup_done_total_garments;
    ProgressBar progressBar;
    private RelativeLayout recyclerRelativeLayout;
    private RelativeLayout relativeLayout;
    String responseOrderDate;
    String responseOrderId;
    String responseOrderStatus;
    private Button showInvoiceBtn;
    private boolean successTrueInvoiceCreated;

    /* renamed from: com.dhobiwala.Activity.MyOrderDetailsActivity$1 */
    class C03131 implements OnClickListener {
        C03131() {
        }

        public void onClick(View view) {
            MyOrderDetailsActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(MyOrderDetailsActivity.this.paymentLinkStr)));
        }
    }

    /* renamed from: com.dhobiwala.Activity.MyOrderDetailsActivity$2 */
    class C03142 implements OnClickListener {
        C03142() {
        }

        public void onClick(View view) {
            MyOrderDetailsActivity.this.cancelOrder();
        }
    }

    /* renamed from: com.dhobiwala.Activity.MyOrderDetailsActivity$3 */
    class C03153 implements OnClickListener {
        C03153() {
        }

        public void onClick(View view) {
            MyOrderDetailsActivity.this.onButtonClick(Orientation.VERTICAL, true);
        }
    }

    /* renamed from: com.dhobiwala.Activity.MyOrderDetailsActivity$4 */
    class C03164 implements OnClickListener {
        /* renamed from: i */
        int f11i = null;

        C03164() {
        }

        public void onClick(View view) {
            if (this.f11i % 1 != null) {
                MyOrderDetailsActivity.this.recyclerRelativeLayout.setVisibility(0);
            } else if (MyOrderDetailsActivity.this.pickup_done_total_garments != null) {
                MyOrderDetailsActivity.this.recyclerRelativeLayout.setVisibility(0);
                MyOrderDetailsActivity.this.relativeLayout.setVisibility(8);
                MyOrderDetailsActivity.this.cardview.setVisibility(0);
            } else {
                view = MyOrderDetailsActivity.this;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Your Order is in ");
                stringBuilder.append(MyOrderDetailsActivity.this.responseOrderStatus);
                Toast.makeText(view, stringBuilder.toString(), 0).show();
                MyOrderDetailsActivity.this.cardview.setVisibility(8);
            }
            this.f11i++;
        }
    }

    /* renamed from: com.dhobiwala.Activity.MyOrderDetailsActivity$5 */
    class C03175 implements OnClickListener {
        /* renamed from: j */
        int f12j = null;

        C03175() {
        }

        public void onClick(View view) {
            if (this.f12j % 1 != null) {
                MyOrderDetailsActivity.this.relativeLayout.setVisibility(8);
            } else if (MyOrderDetailsActivity.this.successTrueInvoiceCreated != null) {
                MyOrderDetailsActivity.this.relativeLayout.setVisibility(0);
                MyOrderDetailsActivity.this.recyclerRelativeLayout.setVisibility(8);
                MyOrderDetailsActivity.this.cardview.setVisibility(0);
            } else {
                Toast.makeText(MyOrderDetailsActivity.this, "No Invoice Generated", 0).show();
                MyOrderDetailsActivity.this.cardview.setVisibility(8);
            }
            this.f12j++;
        }
    }

    /* renamed from: com.dhobiwala.Activity.MyOrderDetailsActivity$9 */
    class C03189 implements DialogInterface.OnClickListener {
        C03189() {
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            MyOrderDetailsActivity.this.orderCancelApi();
        }
    }

    /* renamed from: com.dhobiwala.Activity.MyOrderDetailsActivity$6 */
    class C05566 implements Listener<String> {
        C05566() {
        }

        public void onResponse(String str) {
            Log.e("response", str);
            MyOrderDetailsActivity.this.progressBar.setVisibility(8);
            try {
                JSONObject jSONObject;
                JSONObject jSONObject2 = new JSONObject(str);
                MyOrderDetailsActivity.this.orderTrackingStatusList = new ArrayList();
                MyOrderDetailsActivity.this.orderDetailsSuccess = jSONObject2.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                MyOrderDetailsActivity.this.responseOrderId = jSONObject2.getString("order_id");
                MyOrderDetailsActivity.this.responseOrderStatus = jSONObject2.getString("status");
                MyOrderDetailsActivity.this.responseOrderDate = jSONObject2.getString(MyOrderActivity.KEY_MY_ORDERS_DATE);
                MyOrderDetailsActivity.this.TotalGarmentsStr = jSONObject2.getString("total_garment");
                MyOrderDetailsActivity.this.successTrueInvoiceCreated = jSONObject2.getBoolean("invoice_created");
                MyOrderDetailsActivity.this.OrderIdTv.setText(MyOrderDetailsActivity.this.responseOrderId);
                MyOrderDetailsActivity.this.OrderDateTv.setText(MyOrderDetailsActivity.this.responseOrderDate);
                MyOrderDetailsActivity.this.OrderStatusTv.setText(MyOrderDetailsActivity.this.responseOrderStatus);
                MyOrderDetailsActivity.this.TotalGarmentsTv.setText(MyOrderDetailsActivity.this.TotalGarmentsStr);
                MyOrderDetailsActivity.this.OrderServiceTv.setText(MyOrderDetailsActivity.this.orderService);
                if (MyOrderDetailsActivity.this.successTrueInvoiceCreated != null) {
                    str = jSONObject2.getJSONArray(MyOrderDetailsActivity.TAG_ORDER_DETAILS_INVOICE_DETAILS_ARRAY);
                    for (int i = 0; i < str.length(); i++) {
                        jSONObject = str.getJSONObject(i);
                        MyOrderDetailsActivity.this.customerNameStr = jSONObject.getString("customer_name");
                        MyOrderDetailsActivity.this.invoiceNoStr = jSONObject.getString("invoice_no");
                        MyOrderDetailsActivity.this.franchiseIdStr = jSONObject.getString("franchise_id");
                        MyOrderDetailsActivity.this.phoneStr = jSONObject.getString("phone");
                        MyOrderDetailsActivity.this.invoiceDateStr = jSONObject.getString("invoice_date");
                        MyOrderDetailsActivity.this.responseOrderDate = jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_DATE);
                        MyOrderDetailsActivity.this.invoiceTotalStr = jSONObject.getString("invoice_total");
                        MyOrderDetailsActivity.this.paymentStatusStr = jSONObject.getString("payment_status");
                        MyOrderDetailsActivity.this.paymentLinkStr = jSONObject.getString("payment_link");
                        TextView access$2000 = MyOrderDetailsActivity.this.invoiceCustomerName;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("  :  ");
                        stringBuilder.append(MyOrderDetailsActivity.this.customerNameStr);
                        access$2000.setText(stringBuilder.toString());
                        access$2000 = MyOrderDetailsActivity.this.invoiceNumberTv;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("  :  ");
                        stringBuilder.append(MyOrderDetailsActivity.this.invoiceNoStr);
                        access$2000.setText(stringBuilder.toString());
                        access$2000 = MyOrderDetailsActivity.this.franchiseIdTv;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("  :  ");
                        stringBuilder.append(MyOrderDetailsActivity.this.franchiseIdStr);
                        access$2000.setText(stringBuilder.toString());
                        access$2000 = MyOrderDetailsActivity.this.invoicePhoneTv;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("  :  ");
                        stringBuilder.append(MyOrderDetailsActivity.this.phoneStr);
                        access$2000.setText(stringBuilder.toString());
                        access$2000 = MyOrderDetailsActivity.this.invoiceDateTv;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("  :  ");
                        stringBuilder.append(MyOrderDetailsActivity.this.invoiceDateStr);
                        access$2000.setText(stringBuilder.toString());
                        access$2000 = MyOrderDetailsActivity.this.invoiceTotalTv;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("  :  ");
                        stringBuilder.append(MyOrderDetailsActivity.this.invoiceTotalStr);
                        access$2000.setText(stringBuilder.toString());
                        access$2000 = MyOrderDetailsActivity.this.paymentStatusTv;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("  :  ");
                        stringBuilder.append(MyOrderDetailsActivity.this.paymentStatusStr);
                        access$2000.setText(stringBuilder.toString());
                    }
                }
                MyOrderDetailsActivity.this.pickup_done_total_garments = jSONObject2.getBoolean("pickup_done");
                if (MyOrderDetailsActivity.this.pickup_done_total_garments != null) {
                    str = jSONObject2.getJSONArray(MyOrderDetailsActivity.TAG_ORDER_DETAILS_ORDER_DELIVERY_ARRAY);
                    for (int i2 = 0; i2 < str.length(); i2++) {
                        OrderDetailsData orderDetailsData = new OrderDetailsData();
                        jSONObject = str.getJSONObject(i2);
                        orderDetailsData.setGarmentnme(jSONObject.getString("garment_name").trim());
                        orderDetailsData.setQty(jSONObject.getString(Param.QUANTITY).trim());
                        MyOrderDetailsActivity.this.orderDetailsdata.add(orderDetailsData);
                        Log.e("test12345", String.valueOf(orderDetailsData));
                    }
                    MyOrderDetailsActivity.this.adapter = new OrderDetailsAdapter(MyOrderDetailsActivity.this.orderDetailsdata);
                    MyOrderDetailsActivity.this.orderDetailsRecyclerview.setAdapter(MyOrderDetailsActivity.this.adapter);
                }
            } catch (String str2) {
                str2.printStackTrace();
            }
            if ("paid".equalsIgnoreCase(MyOrderDetailsActivity.this.paymentStatusStr) != null) {
                MyOrderDetailsActivity.this.payBtn.setVisibility(8);
            } else {
                MyOrderDetailsActivity.this.payBtn.setVisibility(0);
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.MyOrderDetailsActivity$7 */
    class C05577 implements ErrorListener {
        C05577() {
        }

        public void onErrorResponse(VolleyError volleyError) {
            MyOrderDetailsActivity.this.progressBar.setVisibility(8);
        }
    }

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.my_order_details);
        this.StrclientId = PreferenceManager.getDefaultSharedPreferences(this).getString("loginuserId", null);
        this.recyclerRelativeLayout = (RelativeLayout) findViewById(C0354R.id.linear_recyclerview);
        this.payBtn = (Button) findViewById(C0354R.id.pay_btn);
        this.payBtn.setOnClickListener(new C03131());
        this.progressBar = (ProgressBar) findViewById(C0354R.id.order_details_p_bar);
        setSupportActionBar((Toolbar) findViewById(C0354R.id.order_details_toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle((CharSequence) "ORDER DETAILS");
        this.OrderIdTv = (TextView) findViewById(C0354R.id.get_my_order_id);
        this.OrderDateTv = (TextView) findViewById(C0354R.id.get_my_order_date);
        this.OrderServiceTv = (TextView) findViewById(C0354R.id.total_garment_details_service);
        this.TotalGarmentsTv = (TextView) findViewById(C0354R.id.total_garments);
        this.OrderStatusTv = (TextView) findViewById(C0354R.id.order_status);
        this.orderCancelBtn = (Button) findViewById(C0354R.id.order_cancel_btn);
        this.orderCancelBtn.setOnClickListener(new C03142());
        this.invoiceCustomerName = (TextView) findViewById(C0354R.id.customer_name);
        this.invoiceNumberTv = (TextView) findViewById(C0354R.id.invoice_no);
        this.franchiseIdTv = (TextView) findViewById(C0354R.id.franchise_id);
        this.invoicePhoneTv = (TextView) findViewById(C0354R.id.phone);
        this.invoiceDateTv = (TextView) findViewById(C0354R.id.invoice_date);
        this.invoiceTotalTv = (TextView) findViewById(C0354R.id.invoice_total);
        this.paymentStatusTv = (TextView) findViewById(C0354R.id.payment_status);
        this.garmentDetailsBtn = (Button) findViewById(C0354R.id.garment_details_btn);
        this.showInvoiceBtn = (Button) findViewById(C0354R.id.show_invoice_btn);
        this.TrackYoueOrderBtn = (Button) findViewById(C0354R.id.track_your_order_btn);
        this.TrackYoueOrderBtn.setOnClickListener(new C03153());
        this.orderDetailsRecyclerview = (RecyclerView) findViewById(C0354R.id.garments_details_recyclerview);
        this.relativeLayout = (RelativeLayout) findViewById(C0354R.id.relative_layout);
        this.cardview = (CardView) findViewById(C0354R.id.garment_deatils_cardview);
        this.orderDetailsRecyclerview.setLayoutManager(new LinearLayoutManager(this));
        this.recyclerRelativeLayout.setVisibility(0);
        bundle = getIntent();
        this.orderId = bundle.getStringExtra("orderId");
        this.orderStatus = bundle.getStringExtra("orderStatus");
        this.orderService = bundle.getStringExtra("orderService");
        orderdetails();
        if ("pending".equalsIgnoreCase(this.orderStatus.toLowerCase()) != null) {
            this.cardview.setVisibility(8);
            this.orderCancelBtn.setVisibility(0);
            this.garmentDetailsBtn.setVisibility(8);
            this.showInvoiceBtn.setVisibility(8);
        } else if ("cancelled".equalsIgnoreCase(this.orderStatus.toLowerCase()) != null) {
            Toast.makeText(this, "Your order has been cancelled", 0).show();
            this.cardview.setVisibility(8);
            this.orderCancelBtn.setVisibility(8);
            this.garmentDetailsBtn.setVisibility(8);
            this.showInvoiceBtn.setVisibility(8);
        } else {
            this.cardview.setVisibility(0);
            this.orderCancelBtn.setVisibility(8);
            this.garmentDetailsBtn.setVisibility(0);
            this.showInvoiceBtn.setVisibility(0);
        }
        this.garmentDetailsBtn.setOnClickListener(new C03164());
        this.showInvoiceBtn.setOnClickListener(new C03175());
    }

    private void orderdetails() {
        HttpsTrustManager.allowAllSSL();
        Request c06288 = new StringRequest(1, TAG_ORDER_DETAILS_URL, new C05566(), new C05577()) {
            protected Map<String, String> getParams() {
                Map<String, String> hashMap = new HashMap();
                hashMap.put("order_id", MyOrderDetailsActivity.this.orderId);
                return hashMap;
            }
        };
        c06288.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(c06288);
        this.progressBar.setVisibility(0);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void onButtonClick(Orientation orientation, boolean z) {
        Intent intent = new Intent(this, TimeLineActivity.class);
        intent.putExtra("orderId", this.responseOrderId);
        intent.putExtra(EXTRA_ORIENTATION, orientation);
        intent.putExtra(EXTRA_WITH_LINE_PADDING, z);
        startActivity(intent);
    }

    private void cancelOrder() {
        Builder builder = new Builder(this);
        builder.setMessage((CharSequence) "Are you sure you want to cancle the order?");
        builder.setPositiveButton((CharSequence) "Yes", new C03189());
        builder.setNegativeButton((CharSequence) "No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.create().show();
    }

    private void orderCancelApi() {
        HttpsTrustManager.allowAllSSL();
        Request anonymousClass13 = new StringRequest(1, TAG_ORDER_CANCEL_URL, new Listener<String>() {
            public void onResponse(String str) {
                Log.e("cancel_order_res:", str.toString());
                MyOrderDetailsActivity.this.progressBar.setVisibility(8);
                try {
                    JSONObject jSONObject = new JSONObject(str);
                    str = System.out;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("jsonobj_response");
                    stringBuilder.append(jSONObject);
                    str.println(stringBuilder.toString());
                    str = jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                    CharSequence string = jSONObject.getString("msg");
                    if (str.equalsIgnoreCase("true")) {
                        Toast.makeText(MyOrderDetailsActivity.this, string, 1).show();
                        MyOrderDetailsActivity.this.startActivity(new Intent(MyOrderDetailsActivity.this, MyOrderActivity.class));
                    }
                    if (str.equalsIgnoreCase("false") != null) {
                        MyOrderDetailsActivity.this.progressBar.setVisibility(8);
                        Toast.makeText(MyOrderDetailsActivity.this, string, 1).show();
                    }
                } catch (String str2) {
                    str2.printStackTrace();
                }
            }
        }, new ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                MyOrderDetailsActivity.this.progressBar.setVisibility(8);
            }
        }) {
            protected Map<String, String> getParams() {
                Map<String, String> hashMap = new HashMap();
                hashMap.put("order_id", MyOrderDetailsActivity.this.orderId);
                hashMap.put("client_id", MyOrderDetailsActivity.this.StrclientId);
                return hashMap;
            }
        };
        anonymousClass13.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(anonymousClass13);
    }
}
