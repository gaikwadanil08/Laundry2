package com.dhobiwala.Activity;

import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dhobiwala.C0354R;
import com.dhobiwala.Fragment.OTPDialogFragment;
import com.dhobiwala.Utils.HttpsTrustManager;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;

public class SignUpActivity extends AppCompatActivity implements OnClickListener {
    public static final String KEY_EMAIL = "email";
    public static final String KEY_MOBILE_NO = "mobile";
    public static final String TAG_REGISTER_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=register_otp";
    private EditText edittextEmail;
    private EditText edittextFirstName;
    private EditText edittextFlatNo;
    private EditText edittextLastName;
    private EditText edittextMobileNo;
    private EditText edittextPassword;
    private EditText edittextReenterPassword;
    private EditText edittextStreetName;
    private Double latitude;
    private TextView locationFromMap;
    private Double longitude;
    String regEmailValidation = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    private Button registerBtn;
    private Button signinNavigationBtn;
    private Toolbar toolbar;
    private String userAddressFromMap;
    private String userEmail;
    private String userFirstName;
    private String userFlatNo;
    private String userLastName;
    private String userMobileNo;
    private String userOtp;
    private String userPassword;
    private String userReenterPassword;
    private String userStreetName;

    /* renamed from: com.dhobiwala.Activity.SignUpActivity$1 */
    class C03221 implements OnClickListener {
        C03221() {
        }

        public void onClick(View view) {
            view = new Intent(SignUpActivity.this, LoginActivity.class);
            view.setFlags(67108864);
            SignUpActivity.this.startActivity(view);
        }
    }

    /* renamed from: com.dhobiwala.Activity.SignUpActivity$2 */
    class C03232 implements OnClickListener {
        C03232() {
        }

        public void onClick(View view) {
            SignUpActivity.this.startActivityForResult(new Intent(SignUpActivity.this, DragMapActivity.class), 2);
        }
    }

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.activity_signup);
        this.toolbar = (Toolbar) findViewById(C0354R.id.toolbar_signup);
        setSupportActionBar(this.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle((CharSequence) "SIGNUP");
        this.registerBtn = (Button) findViewById(C0354R.id.register_button);
        this.registerBtn.setOnClickListener(this);
        this.signinNavigationBtn = (Button) findViewById(C0354R.id.sign_in_btn);
        this.signinNavigationBtn.setOnClickListener(new C03221());
        this.edittextFirstName = (EditText) findViewById(C0354R.id.register_first_name);
        this.edittextLastName = (EditText) findViewById(C0354R.id.register_last_name);
        this.edittextEmail = (EditText) findViewById(C0354R.id.register_email_id);
        this.edittextPassword = (EditText) findViewById(C0354R.id.register_password);
        this.edittextReenterPassword = (EditText) findViewById(C0354R.id.register_re_enter_password);
        this.edittextMobileNo = (EditText) findViewById(C0354R.id.register_mobile_no);
        this.edittextFlatNo = (EditText) findViewById(C0354R.id.register_flat_no);
        this.edittextStreetName = (EditText) findViewById(C0354R.id.register_street_name);
        this.locationFromMap = (TextView) findViewById(C0354R.id.signup_address_map);
        this.locationFromMap.setOnClickListener(new C03232());
    }

    private void registerUser() {
        HttpsTrustManager.allowAllSSL();
        final ProgressDialog show = ProgressDialog.show(this, "Registering", "Please wait...", false, false);
        Request c06325 = new StringRequest(1, TAG_REGISTER_URL, new Listener<String>() {
            public void onResponse(String str) {
                JSONException e;
                FragmentManager fragmentManager;
                OTPDialogFragment oTPDialogFragment;
                show.dismiss();
                String str2 = "";
                PrintStream printStream = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("signup_Response");
                stringBuilder.append(str);
                printStream.println(stringBuilder.toString());
                try {
                    JSONObject jSONObject = new JSONObject(str);
                    str = System.out;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("jsonobj response");
                    stringBuilder.append(jSONObject);
                    str.println(stringBuilder.toString());
                    str = jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                    try {
                        SignUpActivity.this.userOtp = jSONObject.getString("otp");
                        PrintStream printStream2 = System.out;
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("success_response");
                        stringBuilder2.append(str);
                        printStream2.println(stringBuilder2.toString());
                        printStream2 = System.out;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("otp_response");
                        stringBuilder2.append(SignUpActivity.this.userOtp);
                        printStream2.println(stringBuilder2.toString());
                    } catch (JSONException e2) {
                        e = e2;
                        e.printStackTrace();
                        if (str.equalsIgnoreCase("true") != null) {
                            Toast.makeText(SignUpActivity.this, "Mobile Number is already registered", 1).show();
                            show.dismiss();
                        }
                        str = new Bundle();
                        fragmentManager = SignUpActivity.this.getFragmentManager();
                        oTPDialogFragment = new OTPDialogFragment();
                        str.putString("registerOtp", SignUpActivity.this.userOtp);
                        str.putString("userFirstName", SignUpActivity.this.userFirstName);
                        str.putString("userLastName", SignUpActivity.this.userLastName);
                        str.putString("userEmail", SignUpActivity.this.userEmail);
                        str.putString("userPassword", SignUpActivity.this.userPassword);
                        str.putString("userMobileNo", SignUpActivity.this.userMobileNo);
                        str.putString("userFlatNo", SignUpActivity.this.userFlatNo);
                        str.putString("userStreetName", SignUpActivity.this.userStreetName);
                        str.putString("userAddressFromMap", SignUpActivity.this.userAddressFromMap);
                        str.putString("latSignUp", String.valueOf(SignUpActivity.this.latitude));
                        str.putString("lngSignUp", String.valueOf(SignUpActivity.this.longitude));
                        oTPDialogFragment.setArguments(str);
                        oTPDialogFragment.show(fragmentManager, "something");
                        return;
                    }
                } catch (String str3) {
                    String str4 = str2;
                    e = str3;
                    str3 = str4;
                    e.printStackTrace();
                    if (str3.equalsIgnoreCase("true") != null) {
                        str3 = new Bundle();
                        fragmentManager = SignUpActivity.this.getFragmentManager();
                        oTPDialogFragment = new OTPDialogFragment();
                        str3.putString("registerOtp", SignUpActivity.this.userOtp);
                        str3.putString("userFirstName", SignUpActivity.this.userFirstName);
                        str3.putString("userLastName", SignUpActivity.this.userLastName);
                        str3.putString("userEmail", SignUpActivity.this.userEmail);
                        str3.putString("userPassword", SignUpActivity.this.userPassword);
                        str3.putString("userMobileNo", SignUpActivity.this.userMobileNo);
                        str3.putString("userFlatNo", SignUpActivity.this.userFlatNo);
                        str3.putString("userStreetName", SignUpActivity.this.userStreetName);
                        str3.putString("userAddressFromMap", SignUpActivity.this.userAddressFromMap);
                        str3.putString("latSignUp", String.valueOf(SignUpActivity.this.latitude));
                        str3.putString("lngSignUp", String.valueOf(SignUpActivity.this.longitude));
                        oTPDialogFragment.setArguments(str3);
                        oTPDialogFragment.show(fragmentManager, "something");
                        return;
                    }
                    Toast.makeText(SignUpActivity.this, "Mobile Number is already registered", 1).show();
                    show.dismiss();
                }
                if (str3.equalsIgnoreCase("true") != null) {
                    str3 = new Bundle();
                    fragmentManager = SignUpActivity.this.getFragmentManager();
                    oTPDialogFragment = new OTPDialogFragment();
                    str3.putString("registerOtp", SignUpActivity.this.userOtp);
                    str3.putString("userFirstName", SignUpActivity.this.userFirstName);
                    str3.putString("userLastName", SignUpActivity.this.userLastName);
                    str3.putString("userEmail", SignUpActivity.this.userEmail);
                    str3.putString("userPassword", SignUpActivity.this.userPassword);
                    str3.putString("userMobileNo", SignUpActivity.this.userMobileNo);
                    str3.putString("userFlatNo", SignUpActivity.this.userFlatNo);
                    str3.putString("userStreetName", SignUpActivity.this.userStreetName);
                    str3.putString("userAddressFromMap", SignUpActivity.this.userAddressFromMap);
                    str3.putString("latSignUp", String.valueOf(SignUpActivity.this.latitude));
                    str3.putString("lngSignUp", String.valueOf(SignUpActivity.this.longitude));
                    oTPDialogFragment.setArguments(str3);
                    oTPDialogFragment.show(fragmentManager, "something");
                    return;
                }
                Toast.makeText(SignUpActivity.this, "Mobile Number is already registered", 1).show();
                show.dismiss();
            }
        }, new ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                show.dismiss();
            }
        }) {
            protected Map<String, String> getParams() {
                Map<String, String> hashMap = new HashMap();
                hashMap.put("email", SignUpActivity.this.userEmail);
                hashMap.put("mobile", SignUpActivity.this.userMobileNo);
                return hashMap;
            }
        };
        c06325.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(c06325);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onClick(View view) {
        if (view == this.registerBtn) {
            this.userFirstName = this.edittextFirstName.getText().toString();
            this.userLastName = this.edittextLastName.getText().toString();
            this.userEmail = this.edittextEmail.getText().toString();
            this.userPassword = this.edittextPassword.getText().toString();
            this.userReenterPassword = this.edittextReenterPassword.getText().toString();
            this.userMobileNo = this.edittextMobileNo.getText().toString();
            this.userFlatNo = this.edittextFlatNo.getText().toString();
            this.userStreetName = this.edittextStreetName.getText().toString();
            this.userAddressFromMap = this.locationFromMap.getText().toString();
            view = Pattern.compile(this.regEmailValidation).matcher(this.userEmail);
            if (this.userFirstName.equals("")) {
                this.edittextFirstName.setError("First name is mandatory");
            } else if (this.userLastName.equals("")) {
                this.edittextLastName.setError("Last name is mandatory");
            } else if (view.matches() == null) {
                this.edittextEmail.setText("");
                this.edittextEmail.setError("Enter valid Email ID");
            } else if (this.userPassword.equals("") != null) {
                this.edittextPassword.setError("Enter password");
            } else if (this.userPassword.equals(this.userReenterPassword) == null) {
                this.edittextReenterPassword.setError("Password Mismatch");
            } else if (this.userMobileNo.length() < 10) {
                this.edittextMobileNo.setError("Enter valid mobile number");
            } else if (this.userAddressFromMap.equals("") != null) {
                this.locationFromMap.setError("Address is mandatory");
            } else {
                registerUser();
            }
        }
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 2 && i2 == -1) {
            this.userAddressFromMap = intent.getStringExtra("AddressOutputFromMap");
            this.latitude = Double.valueOf(intent.getDoubleExtra("mapLatitude", FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE));
            this.longitude = Double.valueOf(intent.getDoubleExtra("mapLongitude", FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE));
            this.locationFromMap.setText(this.userAddressFromMap);
        }
    }
}
