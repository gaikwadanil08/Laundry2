package com.dhobiwala.Activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dhobiwala.C0354R;
import com.dhobiwala.Utils.HttpsTrustManager;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public class DonateClothsActivity extends AppCompatActivity {
    public static final String KEY_LAT_HOME_SCREEN = "lat";
    public static final String KEY_LNG_HOME_SCREEN = "lng";
    public static final String KEY_PICKUP_DAY_HOME_SCREEN = "p_day";
    public static final String TAG_DONATE_CLOTHS_URL = "https://www.dhobiwala.com/dw_api/api_v1.1/?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=donate_order";
    public static final String TAG_PICKUP_DATE_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=services_pick_date";
    public static final String TAG_PICKUP_TIME_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=services_time_slot";
    Button Next;
    private String StringpickupDate;
    private String StringpickupTime;
    String address;
    String apt_str;
    String cityId;
    String clientId;
    private ArrayList<String> daySlotArrayList = new ArrayList();
    Spinner day_pickup_spinner;
    String flat_door;
    private Double latitude;
    private Double longitude;
    String msg;
    String phone_no;
    private String pickupDayStr;
    private ProgressBar progressBar;
    String slotId;
    private ArrayList<String> slotIdArrayList;
    String slotIdValueString;
    String storeId;
    private String success;
    String timeSlot;
    private ArrayList<String> timeSlotArrayList;
    private ArrayAdapter<String> time_adapter;
    Spinner time_pickup_spinner;
    private Toolbar toolbar;

    /* renamed from: com.dhobiwala.Activity.DonateClothsActivity$1 */
    class C02891 implements OnClickListener {
        C02891() {
        }

        public void onClick(View view) {
            view = new Intent(DonateClothsActivity.this, HomeScreenActivity.class);
            view.setFlags(67108864);
            DonateClothsActivity.this.startActivity(view);
        }
    }

    /* renamed from: com.dhobiwala.Activity.DonateClothsActivity$2 */
    class C02902 implements OnClickListener {
        C02902() {
        }

        public void onClick(View view) {
            try {
                DonateClothsActivity.this.StringpickupDate = DonateClothsActivity.this.day_pickup_spinner.getSelectedItem().toString();
                DonateClothsActivity.this.StringpickupTime = DonateClothsActivity.this.time_pickup_spinner.getSelectedItem().toString();
                if (DonateClothsActivity.this.day_pickup_spinner.getSelectedItem().toString().equalsIgnoreCase("Select Day And Date") != null) {
                    Toast.makeText(DonateClothsActivity.this, "Select Day And Date", 1).show();
                } else if (DonateClothsActivity.this.time_pickup_spinner.getSelectedItem().toString().equalsIgnoreCase("Select Time") != null) {
                    Toast.makeText(DonateClothsActivity.this, "Select Time", 1).show();
                } else {
                    DonateClothsActivity.this.donateCloths();
                }
            } catch (View view2) {
                view2.printStackTrace();
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.DonateClothsActivity$3 */
    class C02913 implements OnItemSelectedListener {
        public void onNothingSelected(AdapterView<?> adapterView) {
        }

        C02913() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            DonateClothsActivity.this.pickupDayStr = (String) DonateClothsActivity.this.daySlotArrayList.get(i);
            Log.e("day", DonateClothsActivity.this.pickupDayStr);
            if (DonateClothsActivity.this.pickupDayStr.equalsIgnoreCase("Select Day And Date") != null) {
                DonateClothsActivity.this.time_pickup_spinner.setVisibility(4);
                return;
            }
            DonateClothsActivity.this.time_pickup_spinner.setVisibility(null);
            DonateClothsActivity.this.pickupTimeApi(DonateClothsActivity.this.pickupDayStr);
        }
    }

    /* renamed from: com.dhobiwala.Activity.DonateClothsActivity$4 */
    class C05414 implements Listener<String> {
        C05414() {
        }

        public void onResponse(String str) {
            PrintStream printStream = System.out;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("result");
            stringBuilder.append(str);
            printStream.println(stringBuilder.toString());
            try {
                JSONObject jSONObject = new JSONObject(str);
                Log.d("Jsonobject response", jSONObject.toString());
                Log.d("Success_msg", jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE));
                str = jSONObject.getJSONArray("pick_date_list");
                Log.d("JsonArray_response", str.toString());
                DonateClothsActivity.this.daySlotArrayList.add("Select Day And Date");
                for (int i = 0; i < str.length(); i++) {
                    DonateClothsActivity.this.daySlotArrayList.add(str.getJSONObject(i).getString("pick_date_key").trim());
                    Log.e("result_p_day", String.valueOf(DonateClothsActivity.this.daySlotArrayList));
                }
                DonateClothsActivity.this.day_pickup_spinner.setAdapter(new ArrayAdapter(DonateClothsActivity.this, 17367049, DonateClothsActivity.this.daySlotArrayList));
            } catch (String str2) {
                str2.printStackTrace();
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.DonateClothsActivity$5 */
    class C05425 implements ErrorListener {
        public void onErrorResponse(VolleyError volleyError) {
        }

        C05425() {
        }
    }

    /* renamed from: com.dhobiwala.Activity.DonateClothsActivity$7 */
    class C05437 implements Listener<String> {

        /* renamed from: com.dhobiwala.Activity.DonateClothsActivity$7$2 */
        class C02932 implements OnItemSelectedListener {
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

            C02932() {
            }

            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                DonateClothsActivity.this.slotIdValueString = (String) DonateClothsActivity.this.slotIdArrayList.get(i);
            }
        }

        C05437() {
        }

        public void onResponse(String str) {
            PrintStream printStream = System.out;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("result");
            stringBuilder.append(str);
            printStream.println(stringBuilder.toString());
            DonateClothsActivity.this.progressBar.setVisibility(8);
            DonateClothsActivity.this.slotIdArrayList = new ArrayList();
            DonateClothsActivity.this.slotIdArrayList.add("0");
            DonateClothsActivity.this.timeSlotArrayList = new ArrayList();
            DonateClothsActivity.this.timeSlotArrayList.add("Select Time");
            try {
                JSONObject jSONObject = new JSONObject(str);
                DonateClothsActivity.this.success = jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                DonateClothsActivity.this.msg = jSONObject.getString("msg");
                if (!(DonateClothsActivity.this.success.equalsIgnoreCase("false") == null || DonateClothsActivity.this.msg.equalsIgnoreCase("Store not found") == null)) {
                    str = new Dialog(DonateClothsActivity.this);
                    str.setContentView(C0354R.layout.custom_alert_dialog);
                    ((Button) str.findViewById(C0354R.id.dialogButtonOK)).setOnClickListener(new OnClickListener() {
                        public void onClick(View view) {
                            str.dismiss();
                        }
                    });
                    str.show();
                }
                DonateClothsActivity.this.storeId = jSONObject.getString(OrderConfirmationActivity.KEY_STORE_ID);
                DonateClothsActivity.this.cityId = jSONObject.getString(OrderConfirmationActivity.KEY_CITY_ID);
                str = jSONObject.getJSONArray("time_slot_data");
                for (int i = 0; i < str.length(); i++) {
                    JSONObject jSONObject2 = str.getJSONObject(i);
                    DonateClothsActivity.this.slotId = jSONObject2.getString("slot_id");
                    DonateClothsActivity.this.timeSlot = jSONObject2.getString("time_slot");
                    PrintStream printStream2 = System.out;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("Timeslot is");
                    stringBuilder2.append(DonateClothsActivity.this.timeSlot);
                    printStream2.println(stringBuilder2.toString());
                    DonateClothsActivity.this.slotIdArrayList.add(DonateClothsActivity.this.slotId);
                    DonateClothsActivity.this.timeSlotArrayList.add(DonateClothsActivity.this.timeSlot);
                    Log.i("Timeslot arraylist", DonateClothsActivity.this.timeSlotArrayList.toString());
                }
                Log.i("Times arraylist", DonateClothsActivity.this.timeSlotArrayList.toString());
                DonateClothsActivity.this.time_adapter = new ArrayAdapter(DonateClothsActivity.this, C0354R.layout.support_simple_spinner_dropdown_item, DonateClothsActivity.this.timeSlotArrayList);
                if (DonateClothsActivity.this.timeSlotArrayList.size() == null) {
                    DonateClothsActivity.this.time_pickup_spinner.setVisibility(4);
                    Toast.makeText(DonateClothsActivity.this, "No empty time slot on selected date. Select a different date", 1).show();
                }
                DonateClothsActivity.this.time_pickup_spinner.setAdapter(DonateClothsActivity.this.time_adapter);
                DonateClothsActivity.this.time_pickup_spinner.setOnItemSelectedListener(new C02932());
            } catch (String str2) {
                str2.printStackTrace();
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.DonateClothsActivity$8 */
    class C05448 implements ErrorListener {
        C05448() {
        }

        public void onErrorResponse(VolleyError volleyError) {
            DonateClothsActivity.this.progressBar.setVisibility(8);
        }
    }

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.activity_donate_cloths);
        this.progressBar = (ProgressBar) findViewById(C0354R.id.donate_cloths_p_bar);
        this.toolbar = (Toolbar) findViewById(C0354R.id.donate_cloths_toolbar);
        setSupportActionBar(this.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle((CharSequence) "Donate Clothes");
        this.toolbar.setNavigationOnClickListener(new C02891());
        this.day_pickup_spinner = (Spinner) findViewById(C0354R.id.spinner_select_date);
        this.time_pickup_spinner = (Spinner) findViewById(C0354R.id.spinner_select_time);
        bundle = PreferenceManager.getDefaultSharedPreferences(this);
        this.latitude = Double.valueOf(bundle.getString("lat", null));
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("lat_homescreen");
        stringBuilder.append(this.latitude.toString());
        printStream.print(stringBuilder.toString());
        this.longitude = Double.valueOf(bundle.getString("lng", null));
        printStream = System.out;
        stringBuilder = new StringBuilder();
        stringBuilder.append("lon_homescreen");
        stringBuilder.append(this.longitude.toString());
        printStream.print(stringBuilder.toString());
        this.clientId = bundle.getString("loginuserId", null);
        this.phone_no = bundle.getString("userMobileNumber", null);
        this.flat_door = bundle.getString("flat_door", null);
        this.apt_str = bundle.getString("apt_str", null);
        this.address = bundle.getString("address", null);
        this.Next = (Button) findViewById(C0354R.id.next_btn_donet_cloths);
        this.Next.setOnClickListener(new C02902());
        pickUpDate();
        this.day_pickup_spinner.setOnItemSelectedListener(new C02913());
    }

    private void pickUpDate() {
        HttpsTrustManager.allowAllSSL();
        Request c06236 = new StringRequest(1, "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=services_pick_date", new C05414(), new C05425()) {
            protected Map<String, String> getParams() throws AuthFailureError {
                return new HashMap();
            }
        };
        c06236.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(c06236);
    }

    private void pickupTimeApi(String str) {
        HttpsTrustManager.allowAllSSL();
        Log.e("pickupday", str);
        final String str2 = str;
        Request c06249 = new StringRequest(1, "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=services_time_slot", new C05437(), new C05448()) {
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> hashMap = new HashMap();
                hashMap.put("lat", String.valueOf(DonateClothsActivity.this.latitude));
                hashMap.put("lng", String.valueOf(DonateClothsActivity.this.longitude));
                hashMap.put("p_day", str2);
                return hashMap;
            }
        };
        c06249.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(c06249);
        this.progressBar.setVisibility(0);
    }

    private void donateCloths() {
        HttpsTrustManager.allowAllSSL();
        Log.d("Donatecloths ", "starting");
        Request anonymousClass12 = new StringRequest(1, TAG_DONATE_CLOTHS_URL, new Listener<String>() {
            public void onResponse(java.lang.String r4) {
                /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
                /*
                r3 = this;
                r0 = "Donate cloths ";
                android.util.Log.d(r0, r4);
                r0 = com.dhobiwala.Activity.DonateClothsActivity.this;
                r0 = r0.progressBar;
                r1 = 8;
                r0.setVisibility(r1);
                r0 = new org.json.JSONObject;	 Catch:{ Exception -> 0x0055 }
                r0.<init>(r4);	 Catch:{ Exception -> 0x0055 }
                r4 = "success";	 Catch:{ Exception -> 0x0055 }
                r0.getString(r4);	 Catch:{ Exception -> 0x0055 }
                r4 = "msg";	 Catch:{ Exception -> 0x0055 }
                r4 = r0.has(r4);	 Catch:{ Exception -> 0x0055 }
                if (r4 == 0) goto L_0x0055;	 Catch:{ Exception -> 0x0055 }
            L_0x0022:
                r4 = new android.app.Dialog;	 Catch:{ Exception -> 0x0055 }
                r1 = com.dhobiwala.Activity.DonateClothsActivity.this;	 Catch:{ Exception -> 0x0055 }
                r4.<init>(r1);	 Catch:{ Exception -> 0x0055 }
                r1 = 2131492915; // 0x7f0c0033 float:1.8609295E38 double:1.0530974237E-314;	 Catch:{ Exception -> 0x0055 }
                r4.setContentView(r1);	 Catch:{ Exception -> 0x0055 }
                r1 = 2131296726; // 0x7f0901d6 float:1.8211377E38 double:1.0530004934E-314;	 Catch:{ Exception -> 0x0055 }
                r1 = r4.findViewById(r1);	 Catch:{ Exception -> 0x0055 }
                r1 = (android.widget.TextView) r1;	 Catch:{ Exception -> 0x0055 }
                r2 = "msg";	 Catch:{ Exception -> 0x0055 }
                r0 = r0.getString(r2);	 Catch:{ Exception -> 0x0055 }
                r1.setText(r0);	 Catch:{ Exception -> 0x0055 }
                r0 = 2131296386; // 0x7f090082 float:1.8210687E38 double:1.0530003254E-314;	 Catch:{ Exception -> 0x0055 }
                r0 = r4.findViewById(r0);	 Catch:{ Exception -> 0x0055 }
                r0 = (android.widget.Button) r0;	 Catch:{ Exception -> 0x0055 }
                r1 = new com.dhobiwala.Activity.DonateClothsActivity$10$1;	 Catch:{ Exception -> 0x0055 }
                r1.<init>(r4);	 Catch:{ Exception -> 0x0055 }
                r0.setOnClickListener(r1);	 Catch:{ Exception -> 0x0055 }
                r4.show();	 Catch:{ Exception -> 0x0055 }
            L_0x0055:
                return;
                */
                throw new UnsupportedOperationException("Method not decompiled: com.dhobiwala.Activity.DonateClothsActivity.10.onResponse(java.lang.String):void");
            }
        }, new ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                DonateClothsActivity.this.progressBar.setVisibility(8);
            }
        }) {
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> hashMap = new HashMap();
                hashMap.put(OrderConfirmationActivity.KEY_STORE_ID, DonateClothsActivity.this.storeId);
                hashMap.put(OrderConfirmationActivity.KEY_CITY_ID, DonateClothsActivity.this.cityId);
                hashMap.put("client_id", DonateClothsActivity.this.clientId);
                hashMap.put("phone", DonateClothsActivity.this.phone_no);
                hashMap.put("p_date", DonateClothsActivity.this.StringpickupDate);
                hashMap.put(OrderConfirmationActivity.KEY_PICKUP_TIME_SLOT, DonateClothsActivity.this.StringpickupTime);
                hashMap.put("lat", String.valueOf(DonateClothsActivity.this.latitude));
                hashMap.put("lng", String.valueOf(DonateClothsActivity.this.longitude));
                hashMap.put("flat_door", DonateClothsActivity.this.flat_door);
                hashMap.put("apt_str", DonateClothsActivity.this.apt_str);
                hashMap.put("address", DonateClothsActivity.this.address);
                return hashMap;
            }
        };
        anonymousClass12.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(anonymousClass12);
        this.progressBar.setVisibility(0);
    }
}
