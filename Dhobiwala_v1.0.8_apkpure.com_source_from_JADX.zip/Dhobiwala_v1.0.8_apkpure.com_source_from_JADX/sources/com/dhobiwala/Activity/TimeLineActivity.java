package com.dhobiwala.Activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dhobiwala.Adapter.TimeLineAdapter;
import com.dhobiwala.C0354R;
import com.dhobiwala.Models.Orientation;
import com.dhobiwala.Utils.HttpsTrustManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public class TimeLineActivity extends AppCompatActivity {
    public static final String KEY_ORDER_TRACKING_DATE_TIME = "date_time";
    public static final String KEY_ORDER_TRACKING_DESCRIPTION = "description";
    public static final String KEY_ORDER_TRACKING_STATUS = "status";
    public static final String TAG_ORDER_TRACKING_ORDER_ID = "order_id";
    public static final String TAG_ORDER_TRACKING_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=order_tracking";
    private Orientation mOrientation;
    private RecyclerView mRecyclerView;
    private TimeLineAdapter mTimeLineAdapter;
    private boolean mWithLinePadding;
    private String orderId;
    protected HashMap<String, String> orderStatusDataMap = null;
    protected ArrayList<HashMap<String, String>> orderTrackingDataList;

    /* renamed from: com.dhobiwala.Activity.TimeLineActivity$1 */
    class C03301 implements OnClickListener {
        C03301() {
        }

        public void onClick(View view) {
            TimeLineActivity.this.onBackPressed();
        }
    }

    /* renamed from: com.dhobiwala.Activity.TimeLineActivity$2 */
    class C05662 implements Listener<String> {
        C05662() {
        }

        public void onResponse(String str) {
            try {
                TimeLineActivity.this.orderTrackingDataList = new ArrayList();
                JSONObject jSONObject = new JSONObject(str);
                jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                str = jSONObject.getJSONArray("status_list");
                for (int i = 0; i < str.length(); i++) {
                    TimeLineActivity.this.orderStatusDataMap = new HashMap();
                    JSONObject jSONObject2 = str.getJSONObject(i);
                    TimeLineActivity.this.orderStatusDataMap.put("description", jSONObject2.getString("description"));
                    TimeLineActivity.this.orderStatusDataMap.put(TimeLineActivity.KEY_ORDER_TRACKING_DATE_TIME, jSONObject2.getString(TimeLineActivity.KEY_ORDER_TRACKING_DATE_TIME));
                    TimeLineActivity.this.orderStatusDataMap.put("status", jSONObject2.getString("status"));
                    TimeLineActivity.this.orderTrackingDataList.add(TimeLineActivity.this.orderStatusDataMap);
                }
            } catch (String str2) {
                str2.printStackTrace();
            }
            if (TimeLineActivity.this.orderStatusDataMap != null) {
                TimeLineActivity.this.mTimeLineAdapter = new TimeLineAdapter(TimeLineActivity.this.orderTrackingDataList, TimeLineActivity.this.mOrientation, TimeLineActivity.this.mWithLinePadding);
                TimeLineActivity.this.mRecyclerView.setAdapter(TimeLineActivity.this.mTimeLineAdapter);
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.TimeLineActivity$3 */
    class C05673 implements ErrorListener {
        public void onErrorResponse(VolleyError volleyError) {
        }

        C05673() {
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.activity_timeline);
        Toolbar toolbar = (Toolbar) findViewById(C0354R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle((CharSequence) "ORDER STATUS");
        toolbar.setNavigationOnClickListener(new C03301());
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        this.mOrientation = (Orientation) getIntent().getSerializableExtra(MyOrderDetailsActivity.EXTRA_ORIENTATION);
        this.mWithLinePadding = getIntent().getBooleanExtra(MyOrderDetailsActivity.EXTRA_WITH_LINE_PADDING, false);
        this.mRecyclerView = (RecyclerView) findViewById(C0354R.id.recyclerView);
        this.mRecyclerView.setLayoutManager(getLinearLayoutManager());
        this.mRecyclerView.setHasFixedSize(true);
        this.orderId = getIntent().getStringExtra("orderId");
        getMyOrders();
    }

    private LinearLayoutManager getLinearLayoutManager() {
        return new LinearLayoutManager(this, 1, false);
    }

    private void getMyOrders() {
        HttpsTrustManager.allowAllSSL();
        Request c06334 = new StringRequest(1, TAG_ORDER_TRACKING_URL, new C05662(), new C05673()) {
            protected Map<String, String> getParams() {
                Map<String, String> hashMap = new HashMap();
                hashMap.put("order_id", TimeLineActivity.this.orderId);
                return hashMap;
            }
        };
        c06334.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(c06334);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        return true;
    }

    protected void onSaveInstanceState(Bundle bundle) {
        if (this.mOrientation != null) {
            bundle.putSerializable(MyOrderDetailsActivity.EXTRA_ORIENTATION, this.mOrientation);
        }
        super.onSaveInstanceState(bundle);
    }

    protected void onRestoreInstanceState(Bundle bundle) {
        if (bundle != null && bundle.containsKey(MyOrderDetailsActivity.EXTRA_ORIENTATION)) {
            this.mOrientation = (Orientation) bundle.getSerializable(MyOrderDetailsActivity.EXTRA_ORIENTATION);
        }
        super.onRestoreInstanceState(bundle);
    }
}
