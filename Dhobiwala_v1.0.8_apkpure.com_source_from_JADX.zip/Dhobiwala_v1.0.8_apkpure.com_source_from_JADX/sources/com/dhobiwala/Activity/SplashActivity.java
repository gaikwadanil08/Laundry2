package com.dhobiwala.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import com.dhobiwala.C0354R;

public class SplashActivity extends AppCompatActivity {
    Animation splash_animation;
    ImageView splash_img;
    ImageView splash_txt;

    /* renamed from: com.dhobiwala.Activity.SplashActivity$1 */
    class C03241 extends Thread {
        C03241() {
        }

        public void run() {
            Intent intent;
            try {
                C03241.sleep(3000);
                intent = new Intent(SplashActivity.this, IntroSlideScreen.class);
            } catch (InterruptedException e) {
                e.printStackTrace();
                intent = new Intent(SplashActivity.this, IntroSlideScreen.class);
            } catch (Throwable th) {
                Intent intent2 = new Intent(SplashActivity.this, IntroSlideScreen.class);
                intent2.setFlags(335544320);
                SplashActivity.this.startActivity(intent2);
                SplashActivity.this.finish();
            }
            intent.setFlags(335544320);
            SplashActivity.this.startActivity(intent);
            SplashActivity.this.finish();
        }
    }

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.activity_splash_screen);
        this.splash_img = (ImageView) findViewById(C0354R.id.splash_image1);
        this.splash_txt = (ImageView) findViewById(C0354R.id.splash_image2);
        this.splash_animation = AnimationUtils.loadAnimation(this, C0354R.anim.push_down_in);
        this.splash_img.startAnimation(this.splash_animation);
        this.splash_animation = AnimationUtils.loadAnimation(this, C0354R.anim.slide_down_right);
        this.splash_txt.startAnimation(this.splash_animation);
        Splash();
    }

    public void Splash() {
        new C03241().start();
    }

    protected void onPause() {
        super.onPause();
        finish();
    }

    protected void onResume() {
        super.onResume();
    }
}
