package com.dhobiwala.Activity;

import android.annotation.SuppressLint;
import android.app.IntentService;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.support.v4.os.ResultReceiver;
import android.text.TextUtils;
import android.util.Log;
import com.dhobiwala.C0354R;
import com.dhobiwala.Utils.AppUtils.LocationConstants;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FetchAddressIntentService extends IntentService {
    private static final String TAG = "FetchAddressIS";
    protected ResultReceiver mReceiver;

    public FetchAddressIntentService() {
        super(TAG);
    }

    protected void onHandleIntent(Intent intent) {
        Address address;
        Iterable arrayList;
        int i;
        String str = "";
        this.mReceiver = (ResultReceiver) intent.getParcelableExtra(LocationConstants.RECEIVER);
        if (this.mReceiver == null) {
            Log.wtf(TAG, "No receiver received. There is nowhere to send the results.");
            return;
        }
        Location location = (Location) intent.getParcelableExtra(LocationConstants.LOCATION_DATA_EXTRA);
        if (location == null) {
            intent = getString(C0354R.string.no_location_data_provided);
            Log.wtf(TAG, intent);
            deliverResultToReceiver(1, intent, null);
            return;
        }
        List fromLocation;
        try {
            fromLocation = new Geocoder(this, Locale.getDefault()).getFromLocation(location.getLatitude(), location.getLongitude(), 1);
        } catch (Intent intent2) {
            str = getString(C0354R.string.service_not_available);
            Log.e(TAG, str, intent2);
            fromLocation = null;
            if (fromLocation != null) {
                if (fromLocation.size() == null) {
                    address = (Address) fromLocation.get(0);
                    arrayList = new ArrayList();
                    for (i = 0; i < address.getMaxAddressLineIndex(); i++) {
                        arrayList.add(address.getAddressLine(i));
                    }
                    deliverResultToReceiver(0, TextUtils.join(System.getProperty("line.separator"), arrayList), address);
                }
            }
            if (str.isEmpty() != null) {
                str = getString(C0354R.string.no_address_found);
                Log.e(TAG, str);
            }
            deliverResultToReceiver(1, str, null);
        } catch (Throwable e) {
            String string = getString(C0354R.string.invalid_lat_long_used);
            String str2 = TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string);
            stringBuilder.append(". Latitude = ");
            stringBuilder.append(location.getLatitude());
            stringBuilder.append(", Longitude = ");
            stringBuilder.append(location.getLongitude());
            Log.e(str2, stringBuilder.toString(), e);
            str = string;
            fromLocation = null;
            if (fromLocation != null) {
                if (fromLocation.size() == null) {
                    address = (Address) fromLocation.get(0);
                    arrayList = new ArrayList();
                    for (i = 0; i < address.getMaxAddressLineIndex(); i++) {
                        arrayList.add(address.getAddressLine(i));
                    }
                    deliverResultToReceiver(0, TextUtils.join(System.getProperty("line.separator"), arrayList), address);
                }
            }
            if (str.isEmpty() != null) {
                str = getString(C0354R.string.no_address_found);
                Log.e(TAG, str);
            }
            deliverResultToReceiver(1, str, null);
        }
        if (fromLocation != null) {
            if (fromLocation.size() == null) {
                address = (Address) fromLocation.get(0);
                arrayList = new ArrayList();
                for (i = 0; i < address.getMaxAddressLineIndex(); i++) {
                    arrayList.add(address.getAddressLine(i));
                }
                deliverResultToReceiver(0, TextUtils.join(System.getProperty("line.separator"), arrayList), address);
            }
        }
        if (str.isEmpty() != null) {
            str = getString(C0354R.string.no_address_found);
            Log.e(TAG, str);
        }
        deliverResultToReceiver(1, str, null);
    }

    @SuppressLint({"RestrictedApi"})
    private void deliverResultToReceiver(int i, String str, Address address) {
        try {
            Bundle bundle = new Bundle();
            bundle.putString(LocationConstants.RESULT_DATA_KEY, str);
            bundle.putString(LocationConstants.LOCATION_DATA_AREA, address.getSubLocality());
            bundle.putString(LocationConstants.LOCATION_DATA_CITY, address.getLocality());
            bundle.putString(LocationConstants.LOCATION_DATA_STREET, address.getAddressLine(0));
            this.mReceiver.send(i, bundle);
        } catch (int i2) {
            i2.printStackTrace();
        }
    }
}
