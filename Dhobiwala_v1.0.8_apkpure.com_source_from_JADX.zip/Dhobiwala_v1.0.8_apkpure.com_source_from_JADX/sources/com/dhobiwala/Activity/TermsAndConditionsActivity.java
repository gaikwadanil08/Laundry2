package com.dhobiwala.Activity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.net.http.SslError;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.dhobiwala.C0354R;

public class TermsAndConditionsActivity extends AppCompatActivity {
    private static final String TAG_TERMS_AND_CONDITIONS_URL = "https://www.dhobiwala.com/terms.php";
    private Toolbar toolbar;
    private WebView webView;

    /* renamed from: com.dhobiwala.Activity.TermsAndConditionsActivity$1 */
    class C03251 implements OnClickListener {
        C03251() {
        }

        public void onClick(View view) {
            TermsAndConditionsActivity.this.onBackPressed();
        }
    }

    /* renamed from: com.dhobiwala.Activity.TermsAndConditionsActivity$2 */
    class C03262 implements OnClickListener {
        C03262() {
        }

        public void onClick(View view) {
            TermsAndConditionsActivity.this.finish();
        }
    }

    /* renamed from: com.dhobiwala.Activity.TermsAndConditionsActivity$3 */
    class C03293 extends WebViewClient {
        C03293() {
        }

        public void onReceivedSslError(WebView webView, final SslErrorHandler sslErrorHandler, SslError sslError) {
            webView = new Builder(TermsAndConditionsActivity.this);
            webView.setMessage((CharSequence) "By proceeding, You will be redirected to Dhobiwala Terms and Conditions");
            webView.setPositiveButton((CharSequence) "continue", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    sslErrorHandler.proceed();
                }
            });
            webView.setNegativeButton((CharSequence) "cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    sslErrorHandler.cancel();
                }
            });
            webView.create().show();
        }
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.activity_terms_conditions);
        this.toolbar = (Toolbar) findViewById(C0354R.id.terms_conditions_toolbar);
        setSupportActionBar(this.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        this.toolbar.setNavigationOnClickListener(new C03251());
        getSupportActionBar().setTitle((CharSequence) "Terms & Conditions");
        this.toolbar.setNavigationOnClickListener(new C03262());
        this.webView = (WebView) findViewById(C0354R.id.webView1);
        this.webView.getSettings().setJavaScriptEnabled(true);
        this.webView.getSettings().setDisplayZoomControls(true);
        this.webView.setWebViewClient(new C03293());
        this.webView.loadUrl(TAG_TERMS_AND_CONDITIONS_URL);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
