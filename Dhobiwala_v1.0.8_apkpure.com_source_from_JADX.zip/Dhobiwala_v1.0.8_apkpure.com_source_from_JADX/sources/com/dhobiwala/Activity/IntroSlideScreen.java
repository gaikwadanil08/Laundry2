package com.dhobiwala.Activity;

import android.content.Intent;
import android.os.Build.VERSION;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.dhobiwala.C0354R;

public class IntroSlideScreen extends AppCompatActivity {
    public static final int PERMISSIONS_MULTIPLE_REQUEST = 123;
    private Button btnNext;
    private Button btnSkip;
    private TextView[] dots;
    private LinearLayout dotsLayout;
    private int[] layouts;
    private MyViewPagerAdapter myViewPagerAdapter;
    private PrefManagerForIntroScreen prefManagerForIntroScreen;
    private ViewPager viewPager;
    OnPageChangeListener viewPagerPageChangeListener = new C05503();

    /* renamed from: com.dhobiwala.Activity.IntroSlideScreen$1 */
    class C03031 implements OnClickListener {
        C03031() {
        }

        public void onClick(View view) {
            IntroSlideScreen.this.launchHomeScreen();
        }
    }

    /* renamed from: com.dhobiwala.Activity.IntroSlideScreen$2 */
    class C03042 implements OnClickListener {
        C03042() {
        }

        public void onClick(View view) {
            view = IntroSlideScreen.this.getItem(1);
            if (view < IntroSlideScreen.this.layouts.length) {
                IntroSlideScreen.this.viewPager.setCurrentItem(view);
            } else {
                IntroSlideScreen.this.launchHomeScreen();
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.IntroSlideScreen$4 */
    class C03054 implements OnClickListener {
        C03054() {
        }

        @RequiresApi(api = 23)
        public void onClick(View view) {
            IntroSlideScreen.this.requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.CALL_PHONE", "android.permission.ACCESS_FINE_LOCATION", "android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.SEND_SMS"}, 123);
        }
    }

    /* renamed from: com.dhobiwala.Activity.IntroSlideScreen$3 */
    class C05503 implements OnPageChangeListener {
        public void onPageScrollStateChanged(int i) {
        }

        public void onPageScrolled(int i, float f, int i2) {
        }

        C05503() {
        }

        public void onPageSelected(int i) {
            IntroSlideScreen.this.addBottomDots(i);
            if (i == IntroSlideScreen.this.layouts.length - 1) {
                IntroSlideScreen.this.btnNext.setText(IntroSlideScreen.this.getString(C0354R.string.start));
                IntroSlideScreen.this.btnSkip.setVisibility(8);
                return;
            }
            IntroSlideScreen.this.btnNext.setText(IntroSlideScreen.this.getString(C0354R.string.next));
            IntroSlideScreen.this.btnSkip.setVisibility(0);
        }
    }

    public class MyViewPagerAdapter extends PagerAdapter {
        private LayoutInflater layoutInflater;

        public boolean isViewFromObject(View view, Object obj) {
            return view == obj;
        }

        public Object instantiateItem(ViewGroup viewGroup, int i) {
            this.layoutInflater = (LayoutInflater) IntroSlideScreen.this.getSystemService("layout_inflater");
            i = this.layoutInflater.inflate(IntroSlideScreen.this.layouts[i], viewGroup, false);
            viewGroup.addView(i);
            return i;
        }

        public int getCount() {
            return IntroSlideScreen.this.layouts.length;
        }

        public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
            viewGroup.removeView((View) obj);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected void onCreate(android.os.Bundle r2) {
        /*
        r1 = this;
        super.onCreate(r2);
        r2 = new com.dhobiwala.Activity.PrefManagerForIntroScreen;
        r2.<init>(r1);
        r1.prefManagerForIntroScreen = r2;
        r2 = r1.prefManagerForIntroScreen;
        r2 = r2.isFirstTimeLaunch();
        if (r2 != 0) goto L_0x0018;
    L_0x0012:
        r1.launchHomeScreen();
        r1.finish();
    L_0x0018:
        r2 = android.os.Build.VERSION.SDK_INT;
        r0 = 21;
        if (r2 < r0) goto L_0x002b;
    L_0x001e:
        r2 = r1.getWindow();
        r2 = r2.getDecorView();
        r0 = 1280; // 0x500 float:1.794E-42 double:6.324E-321;
        r2.setSystemUiVisibility(r0);
    L_0x002b:
        r2 = 2131492896; // 0x7f0c0020 float:1.8609257E38 double:1.0530974143E-314;
        r1.setContentView(r2);
        r1.checkAndroidVersion();
        r2 = 2131296774; // 0x7f090206 float:1.8211474E38 double:1.053000517E-314;
        r2 = r1.findViewById(r2);
        r2 = (android.support.v4.view.ViewPager) r2;
        r1.viewPager = r2;
        r2 = 2131296473; // 0x7f0900d9 float:1.8210864E38 double:1.0530003684E-314;
        r2 = r1.findViewById(r2);
        r2 = (android.widget.LinearLayout) r2;
        r1.dotsLayout = r2;
        r2 = 2131296311; // 0x7f090037 float:1.8210535E38 double:1.0530002884E-314;
        r2 = r1.findViewById(r2);
        r2 = (android.widget.Button) r2;
        r1.btnSkip = r2;
        r2 = 2131296309; // 0x7f090035 float:1.8210531E38 double:1.0530002874E-314;
        r2 = r1.findViewById(r2);
        r2 = (android.widget.Button) r2;
        r1.btnNext = r2;
        r2 = 2;
        r2 = new int[r2];
        r2 = {2131492987, 2131492988};
        r1.layouts = r2;
        r2 = 0;
        r1.addBottomDots(r2);
        r2 = new com.dhobiwala.Activity.IntroSlideScreen$MyViewPagerAdapter;
        r2.<init>();
        r1.myViewPagerAdapter = r2;
        r2 = r1.viewPager;
        r0 = r1.myViewPagerAdapter;
        r2.setAdapter(r0);
        r2 = r1.viewPager;
        r0 = r1.viewPagerPageChangeListener;
        r2.addOnPageChangeListener(r0);
        r2 = r1.btnSkip;
        r0 = new com.dhobiwala.Activity.IntroSlideScreen$1;
        r0.<init>();
        r2.setOnClickListener(r0);
        r2 = r1.btnNext;
        r0 = new com.dhobiwala.Activity.IntroSlideScreen$2;
        r0.<init>();
        r2.setOnClickListener(r0);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.dhobiwala.Activity.IntroSlideScreen.onCreate(android.os.Bundle):void");
    }

    private void addBottomDots(int i) {
        this.dots = new TextView[this.layouts.length];
        int[] intArray = getResources().getIntArray(C0354R.array.array_dot_active);
        int[] intArray2 = getResources().getIntArray(C0354R.array.array_dot_inactive);
        this.dotsLayout.removeAllViews();
        for (int i2 = 0; i2 < this.dots.length; i2++) {
            this.dots[i2] = new TextView(this);
            this.dots[i2].setText(Html.fromHtml("&#8226;"));
            this.dots[i2].setTextSize(35.0f);
            this.dots[i2].setTextColor(intArray2[i]);
            this.dotsLayout.addView(this.dots[i2]);
        }
        if (this.dots.length > 0) {
            this.dots[i].setTextColor(intArray[i]);
        }
    }

    private int getItem(int i) {
        return this.viewPager.getCurrentItem() + i;
    }

    private void launchHomeScreen() {
        this.prefManagerForIntroScreen.setFirstTimeLaunch(false);
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    private void checkAndroidVersion() {
        if (VERSION.SDK_INT >= 23) {
            checkPermission();
        }
    }

    @RequiresApi(api = 23)
    private void checkPermission() {
        if (((((ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") + ContextCompat.checkSelfPermission(this, "android.permission.CALL_PHONE")) + ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION")) + ContextCompat.checkSelfPermission(this, "android.permission.READ_SMS")) + ContextCompat.checkSelfPermission(this, "android.permission.RECEIVE_SMS")) + ContextCompat.checkSelfPermission(this, "android.permission.SEND_SMS") != 0) {
            if (!(ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.READ_EXTERNAL_STORAGE") || ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.CALL_PHONE") || ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.ACCESS_FINE_LOCATION") || ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.READ_SMS") || ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.RECEIVE_SMS"))) {
                if (!ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.SEND_SMS")) {
                    requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.CALL_PHONE", "android.permission.ACCESS_FINE_LOCATION", "android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.SEND_SMS"}, 123);
                    return;
                }
            }
            Snackbar.make(findViewById(16908290), (CharSequence) "Please Grant Permissions to upload profile photo", -2).setAction((CharSequence) "ENABLE", new C03054()).show();
        }
    }

    @RequiresApi(api = 23)
    public void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        if (i == 123) {
            if (iArr.length > 0) {
                int i2 = iArr[0] == 0 ? 1 : 0;
                int i3 = iArr[1] == 0 ? 1 : 0;
                int i4 = iArr[2] == 0 ? 1 : 0;
                int i5 = iArr[3] == 0 ? 1 : 0;
                int i6 = iArr[4] == 0 ? 1 : 0;
                iArr = iArr[5] == null ? 1 : null;
                if (i2 == 0 || i3 == 0 || i4 == 0 || i5 == 0 || i6 == 0 || iArr == null) {
                    requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.CALL_PHONE", "android.permission.ACCESS_FINE_LOCATION", "android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.SEND_SMS"}, 123);
                }
            }
        }
    }
}
