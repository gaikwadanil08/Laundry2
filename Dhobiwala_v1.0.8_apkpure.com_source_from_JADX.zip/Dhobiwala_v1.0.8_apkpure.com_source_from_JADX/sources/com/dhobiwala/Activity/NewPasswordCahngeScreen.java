package com.dhobiwala.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dhobiwala.C0354R;
import com.dhobiwala.Utils.HttpsTrustManager;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class NewPasswordCahngeScreen extends AppCompatActivity implements OnClickListener {
    public static final String KEY_UPDATE_PASSWORD_MOBILE = "mobile";
    public static final String KEY_UPDATE_PASSWORD_NEW_PASSWORD = "password";
    private static final String TAG_RESET_PWD_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=reset_password";
    private String StrConfirmNewPwd;
    private String StrNewPwd;
    private String StrforgotPwdMobile;
    private Button backBtnUpdatePwd;
    private EditText confirmNewPwdEdittext;
    private EditText newPwdEdittext;
    private Button updatePwdSubmitBtn;

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.new_password_change_screen);
        this.newPwdEdittext = (EditText) findViewById(C0354R.id.update_new_pwd_et);
        this.confirmNewPwdEdittext = (EditText) findViewById(C0354R.id.cnfrm_update_new_pwd_et);
        this.updatePwdSubmitBtn = (Button) findViewById(C0354R.id.update_pwd_submit_btn);
        this.backBtnUpdatePwd = (Button) findViewById(C0354R.id.back_btn_update_pwd);
        this.updatePwdSubmitBtn.setOnClickListener(this);
        this.backBtnUpdatePwd.setOnClickListener(this);
        this.StrforgotPwdMobile = getIntent().getStringExtra("forgotPasswordMobile");
    }

    private void changeNewPassword() {
        HttpsTrustManager.allowAllSSL();
        final ProgressDialog show = ProgressDialog.show(this, "Password updating", "Please wait...", false, false);
        Request c06293 = new StringRequest(1, TAG_RESET_PWD_URL, new Listener<String>() {
            public void onResponse(String str) {
                CharSequence string;
                show.dismiss();
                String str2 = "";
                String str3 = "";
                try {
                    JSONObject jSONObject = new JSONObject(str);
                    str = jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                    try {
                        string = jSONObject.getString("msg");
                    } catch (JSONException e) {
                        JSONException jSONException = e;
                        str2 = str;
                        str = jSONException;
                        str.printStackTrace();
                        str = str2;
                        string = str3;
                        if (str.equalsIgnoreCase("true") != null) {
                            show.dismiss();
                            Toast.makeText(NewPasswordCahngeScreen.this, string, 0).show();
                        }
                        str = new Intent(NewPasswordCahngeScreen.this, LoginActivity.class);
                        str.setFlags(67108864);
                        str.setFlags(32768);
                        str.putExtra("forgotPasswordMobile", NewPasswordCahngeScreen.this.StrforgotPwdMobile);
                        NewPasswordCahngeScreen.this.startActivity(str);
                        NewPasswordCahngeScreen.this.finish();
                        Toast.makeText(NewPasswordCahngeScreen.this, string, 0).show();
                        return;
                    }
                } catch (JSONException e2) {
                    str = e2;
                    str.printStackTrace();
                    str = str2;
                    string = str3;
                    if (str.equalsIgnoreCase("true") != null) {
                        str = new Intent(NewPasswordCahngeScreen.this, LoginActivity.class);
                        str.setFlags(67108864);
                        str.setFlags(32768);
                        str.putExtra("forgotPasswordMobile", NewPasswordCahngeScreen.this.StrforgotPwdMobile);
                        NewPasswordCahngeScreen.this.startActivity(str);
                        NewPasswordCahngeScreen.this.finish();
                        Toast.makeText(NewPasswordCahngeScreen.this, string, 0).show();
                        return;
                    }
                    show.dismiss();
                    Toast.makeText(NewPasswordCahngeScreen.this, string, 0).show();
                }
                if (str.equalsIgnoreCase("true") != null) {
                    str = new Intent(NewPasswordCahngeScreen.this, LoginActivity.class);
                    str.setFlags(67108864);
                    str.setFlags(32768);
                    str.putExtra("forgotPasswordMobile", NewPasswordCahngeScreen.this.StrforgotPwdMobile);
                    NewPasswordCahngeScreen.this.startActivity(str);
                    NewPasswordCahngeScreen.this.finish();
                    Toast.makeText(NewPasswordCahngeScreen.this, string, 0).show();
                    return;
                }
                show.dismiss();
                Toast.makeText(NewPasswordCahngeScreen.this, string, 0).show();
            }
        }, new ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                show.dismiss();
                Toast.makeText(NewPasswordCahngeScreen.this, "Password update is unsuccessful", 1).show();
            }
        }) {
            protected Map<String, String> getParams() {
                Map<String, String> hashMap = new HashMap();
                hashMap.put("mobile", NewPasswordCahngeScreen.this.StrforgotPwdMobile);
                hashMap.put("password", NewPasswordCahngeScreen.this.StrNewPwd);
                return hashMap;
            }
        };
        c06293.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(c06293);
    }

    public void onClick(View view) {
        if (view == this.updatePwdSubmitBtn) {
            this.StrNewPwd = this.newPwdEdittext.getText().toString().trim();
            this.StrConfirmNewPwd = this.confirmNewPwdEdittext.getText().toString().trim();
            if (this.StrNewPwd.equals(this.StrConfirmNewPwd)) {
                changeNewPassword();
            } else {
                this.confirmNewPwdEdittext.setError("Password Mismatch");
            }
        }
        if (view == this.backBtnUpdatePwd) {
            startActivity(new Intent(this, LoginActivity.class));
        }
    }
}
