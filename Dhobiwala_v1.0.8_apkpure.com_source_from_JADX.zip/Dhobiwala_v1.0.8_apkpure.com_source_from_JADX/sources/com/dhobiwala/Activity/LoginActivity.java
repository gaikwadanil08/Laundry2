package com.dhobiwala.Activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.InputFilter.LengthFilter;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dhobiwala.C0354R;
import com.dhobiwala.Firebase.SharedPrefManager;
import com.dhobiwala.Utils.HttpsTrustManager;
import com.google.android.gms.drive.DriveFile;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity implements OnClickListener {
    public static final String EMAIL_SHARED_PREF = "user_id";
    private static final String KEY_MOBILE_LOGIN = "email_mobile";
    public static final String KEY_OTP_MOBILE = "mobile";
    private static final String KEY_PWD = "password";
    public static final String LOGGEDIN_SHARED_PREF = "loggedin";
    public static final String SHARED_PREF_NAME = "myloginapp";
    private static final String TAG_FORGOT_PWD_OTP_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=reset_otp";
    private static final String TAG_LOGIN_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=login_user";
    private Button LoginBtn;
    private Button RegisterBtn;
    private Button forgotPasswordBtn;
    private String forgotPasswordMobile;
    private EditText forgotPwdEt;
    private boolean isNetworkAvailable;
    private boolean loggedIn = false;
    private EditText loginEmailEt;
    private EditText loginPwdEt;
    private ProgressBar progressBar;
    private TextView termsConditionsText;
    private String userLoginEmail;
    private String userLoginPwd;

    /* renamed from: com.dhobiwala.Activity.LoginActivity$1 */
    class C03061 implements OnClickListener {
        C03061() {
        }

        public void onClick(View view) {
            LoginActivity.this.startActivity(new Intent(LoginActivity.this, TermsAndConditionsActivity.class));
        }
    }

    /* renamed from: com.dhobiwala.Activity.LoginActivity$2 */
    class C03072 implements OnClickListener {
        C03072() {
        }

        public void onClick(View view) {
            if (view == LoginActivity.this.LoginBtn) {
                LoginActivity.this.userLoginEmail = LoginActivity.this.loginEmailEt.getText().toString();
                LoginActivity.this.userLoginPwd = LoginActivity.this.loginPwdEt.getText().toString();
                if (TextUtils.isEmpty(LoginActivity.this.userLoginEmail) != null) {
                    LoginActivity.this.loginEmailEt.setError("Please enter your email ID");
                    LoginActivity.this.loginEmailEt.requestFocus();
                } else if (TextUtils.isEmpty(LoginActivity.this.userLoginPwd) != null) {
                    LoginActivity.this.loginPwdEt.setError("Please enter your password");
                    LoginActivity.this.loginPwdEt.requestFocus();
                } else if (LoginActivity.this.isNetworkAvailable != null) {
                    LoginActivity.this.userLogin();
                }
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.LoginActivity$3 */
    class C03083 implements OnClickListener {
        C03083() {
        }

        public void onClick(View view) {
            LoginActivity.this.startActivity(new Intent(LoginActivity.this, SignUpActivity.class));
        }
    }

    /* renamed from: com.dhobiwala.Activity.LoginActivity$4 */
    class C03104 implements DialogInterface.OnClickListener {

        /* renamed from: com.dhobiwala.Activity.LoginActivity$4$1 */
        class C03091 implements DialogInterface.OnClickListener {
            C03091() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        }

        C03104() {
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            LoginActivity.this.forgotPasswordMobile = LoginActivity.this.forgotPwdEt.getText().toString().trim();
            if (LoginActivity.this.forgotPwdEt.getText().toString().equals("") != null) {
                i = new Builder(LoginActivity.this);
                i.setTitle((CharSequence) "Error");
                i.setMessage((CharSequence) "The Mobile Number you have entered is incorrect.\nPlease try again!");
                i.setPositiveButton((CharSequence) "OK", null);
                i.setNegativeButton((CharSequence) "Retry", new C03091());
                i.create().show();
                return;
            }
            LoginActivity.this.getMobileForgetpwd();
        }
    }

    /* renamed from: com.dhobiwala.Activity.LoginActivity$5 */
    class C03115 implements DialogInterface.OnClickListener {
        C03115() {
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            dialogInterface.cancel();
        }
    }

    /* renamed from: com.dhobiwala.Activity.LoginActivity$6 */
    class C05516 implements Listener<String> {
        C05516() {
        }

        public void onResponse(String str) {
            JSONException e;
            String str2 = "";
            String str3 = "";
            try {
                JSONObject jSONObject = new JSONObject(str);
                str = jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                try {
                    CharSequence string = jSONObject.getString("msg");
                    if (str.equalsIgnoreCase("false")) {
                        Toast.makeText(LoginActivity.this, string, 0).show();
                    }
                    str2 = jSONObject.getString("otp");
                } catch (JSONException e2) {
                    e = e2;
                    e.printStackTrace();
                    str2 = str3;
                    if (str.equalsIgnoreCase("true") != null) {
                        str = new Intent(LoginActivity.this, ForgotPasswordOtpScreen.class);
                        str.putExtra("forgotPasswordMobile", LoginActivity.this.forgotPasswordMobile);
                        str.putExtra("changePasswordOtp", str2);
                        LoginActivity.this.startActivity(str);
                    }
                    LoginActivity.this.progressBar.setVisibility(8);
                }
            } catch (String str4) {
                String str5 = str2;
                e = str4;
                str4 = str5;
                e.printStackTrace();
                str2 = str3;
                if (str4.equalsIgnoreCase("true") != null) {
                    str4 = new Intent(LoginActivity.this, ForgotPasswordOtpScreen.class);
                    str4.putExtra("forgotPasswordMobile", LoginActivity.this.forgotPasswordMobile);
                    str4.putExtra("changePasswordOtp", str2);
                    LoginActivity.this.startActivity(str4);
                }
                LoginActivity.this.progressBar.setVisibility(8);
            }
            if (str4.equalsIgnoreCase("true") != null) {
                str4 = new Intent(LoginActivity.this, ForgotPasswordOtpScreen.class);
                str4.putExtra("forgotPasswordMobile", LoginActivity.this.forgotPasswordMobile);
                str4.putExtra("changePasswordOtp", str2);
                LoginActivity.this.startActivity(str4);
            }
            LoginActivity.this.progressBar.setVisibility(8);
        }
    }

    /* renamed from: com.dhobiwala.Activity.LoginActivity$7 */
    class C05527 implements ErrorListener {
        C05527() {
        }

        public void onErrorResponse(VolleyError volleyError) {
            LoginActivity.this.progressBar.setVisibility(8);
            Toast.makeText(LoginActivity.this, "Invalid Mobile Number", 1).show();
        }
    }

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.activity_login);
        SharedPrefManager.getInstance(this).getDeviceToken();
        this.termsConditionsText = (TextView) findViewById(C0354R.id.terms_conditions_text);
        bundle = new SpannableString("Terms and Conditions");
        bundle.setSpan(new UnderlineSpan(), 0, bundle.length(), 0);
        this.termsConditionsText.setText(bundle);
        this.termsConditionsText.setOnClickListener(new C03061());
        this.isNetworkAvailable = NetworkConnectionCheck.isNetworkAvailable(this);
        this.progressBar = (ProgressBar) findViewById(C0354R.id.pbarOtplogin);
        this.loginEmailEt = (EditText) findViewById(C0354R.id.login_email);
        this.loginPwdEt = (EditText) findViewById(C0354R.id.login_pwd);
        this.LoginBtn = (Button) findViewById(C0354R.id.btn_login);
        this.LoginBtn.setOnClickListener(new C03072());
        this.RegisterBtn = (Button) findViewById(C0354R.id.btn_register);
        this.RegisterBtn.setOnClickListener(new C03083());
        this.forgotPasswordBtn = (Button) findViewById(C0354R.id.btn_forgot_password);
        this.forgotPasswordBtn.setOnClickListener(this);
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
    }

    public void onClick(View view) {
        if (view.getId() == C0354R.id.btn_forgot_password) {
            this.forgotPwdEt = new EditText(this);
            this.forgotPwdEt.setInputType(3);
            this.forgotPwdEt.setFilters(new InputFilter[]{new LengthFilter(10)});
            view = new Builder(this);
            view.setMessage((CharSequence) "Enter your Mobile Number");
            view.setView(this.forgotPwdEt);
            view.setCancelable(false);
            view.setPositiveButton((CharSequence) "Reset Password", new C03104());
            view.setNegativeButton((CharSequence) "Cancel", new C03115());
            view.create().show();
        }
    }

    private void getMobileForgetpwd() {
        HttpsTrustManager.allowAllSSL();
        Request c06268 = new StringRequest(1, TAG_FORGOT_PWD_OTP_URL, new C05516(), new C05527()) {
            protected Map<String, String> getParams() {
                Map<String, String> hashMap = new HashMap();
                hashMap.put("mobile", LoginActivity.this.forgotPasswordMobile);
                return hashMap;
            }
        };
        c06268.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(c06268);
        this.progressBar.setVisibility(0);
    }

    private void userLogin() {
        HttpsTrustManager.allowAllSSL();
        final ProgressDialog show = ProgressDialog.show(this, "Logging", "Please wait...", false, false);
        Request anonymousClass11 = new StringRequest(1, TAG_LOGIN_URL, new Listener<String>() {
            public void onResponse(String str) {
                String string;
                JSONException e;
                String str2;
                String str3;
                String str4;
                String str5;
                Object obj;
                Object obj2;
                String str6;
                String str7;
                show.dismiss();
                Log.e("Response:", str.toString());
                String str8 = null;
                try {
                    JSONObject jSONObject = new JSONObject(str);
                    str = jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                    try {
                        string = jSONObject.getString("user_id");
                    } catch (JSONException e2) {
                        e = e2;
                        string = null;
                        str2 = string;
                        str3 = str2;
                        str4 = str3;
                        str5 = str4;
                        obj = str5;
                        obj2 = obj;
                        str6 = obj2;
                        str7 = str6;
                        e.printStackTrace();
                        if (str.trim().equalsIgnoreCase("true") == null) {
                            Toast.makeText(LoginActivity.this, "Invalid Credentials", 1).show();
                            show.dismiss();
                        } else {
                            str = LoginActivity.this.getSharedPreferences("myloginapp", 0).edit();
                            str.putBoolean("loggedin", true);
                            str.commit();
                            str = new Intent(LoginActivity.this, HomeScreenActivity.class);
                            str.setFlags(DriveFile.MODE_READ_ONLY);
                            str.setFlags(32768);
                            str.setFlags(67108864);
                            LoginActivity.this.startActivity(str);
                            Toast.makeText(LoginActivity.this, "Login Successful", 0).show();
                            str = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                            str.edit().putString("loginuserId", string).apply();
                            str.edit().putString("fName", str2).apply();
                            str.edit().putString("lName", str3).apply();
                            str.edit().putString("userEmail", str4).apply();
                            str.edit().putString("userMobileNumber", str5).apply();
                            str.edit().putString("flat_door", str6).apply();
                            str.edit().putString("apt_str", str7).apply();
                            str.edit().putString("address", str8).apply();
                            str.edit().putString("lat", String.valueOf(obj)).apply();
                            str.edit().putString("lng", String.valueOf(obj2)).apply();
                        }
                        LoginActivity.this.progressBar.setVisibility(8);
                    }
                    try {
                        str2 = jSONObject.getString("f_name");
                        try {
                            str3 = jSONObject.getString("l_name");
                            try {
                                str4 = jSONObject.getString("email");
                            } catch (JSONException e3) {
                                e = e3;
                                str4 = null;
                                str5 = str4;
                                obj = str5;
                                obj2 = obj;
                                str6 = obj2;
                                str7 = str6;
                                e.printStackTrace();
                                if (str.trim().equalsIgnoreCase("true") == null) {
                                    str = LoginActivity.this.getSharedPreferences("myloginapp", 0).edit();
                                    str.putBoolean("loggedin", true);
                                    str.commit();
                                    str = new Intent(LoginActivity.this, HomeScreenActivity.class);
                                    str.setFlags(DriveFile.MODE_READ_ONLY);
                                    str.setFlags(32768);
                                    str.setFlags(67108864);
                                    LoginActivity.this.startActivity(str);
                                    Toast.makeText(LoginActivity.this, "Login Successful", 0).show();
                                    str = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                                    str.edit().putString("loginuserId", string).apply();
                                    str.edit().putString("fName", str2).apply();
                                    str.edit().putString("lName", str3).apply();
                                    str.edit().putString("userEmail", str4).apply();
                                    str.edit().putString("userMobileNumber", str5).apply();
                                    str.edit().putString("flat_door", str6).apply();
                                    str.edit().putString("apt_str", str7).apply();
                                    str.edit().putString("address", str8).apply();
                                    str.edit().putString("lat", String.valueOf(obj)).apply();
                                    str.edit().putString("lng", String.valueOf(obj2)).apply();
                                } else {
                                    Toast.makeText(LoginActivity.this, "Invalid Credentials", 1).show();
                                    show.dismiss();
                                }
                                LoginActivity.this.progressBar.setVisibility(8);
                            }
                        } catch (JSONException e4) {
                            e = e4;
                            str3 = null;
                            str4 = str3;
                            str5 = str4;
                            obj = str5;
                            obj2 = obj;
                            str6 = obj2;
                            str7 = str6;
                            e.printStackTrace();
                            if (str.trim().equalsIgnoreCase("true") == null) {
                                Toast.makeText(LoginActivity.this, "Invalid Credentials", 1).show();
                                show.dismiss();
                            } else {
                                str = LoginActivity.this.getSharedPreferences("myloginapp", 0).edit();
                                str.putBoolean("loggedin", true);
                                str.commit();
                                str = new Intent(LoginActivity.this, HomeScreenActivity.class);
                                str.setFlags(DriveFile.MODE_READ_ONLY);
                                str.setFlags(32768);
                                str.setFlags(67108864);
                                LoginActivity.this.startActivity(str);
                                Toast.makeText(LoginActivity.this, "Login Successful", 0).show();
                                str = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                                str.edit().putString("loginuserId", string).apply();
                                str.edit().putString("fName", str2).apply();
                                str.edit().putString("lName", str3).apply();
                                str.edit().putString("userEmail", str4).apply();
                                str.edit().putString("userMobileNumber", str5).apply();
                                str.edit().putString("flat_door", str6).apply();
                                str.edit().putString("apt_str", str7).apply();
                                str.edit().putString("address", str8).apply();
                                str.edit().putString("lat", String.valueOf(obj)).apply();
                                str.edit().putString("lng", String.valueOf(obj2)).apply();
                            }
                            LoginActivity.this.progressBar.setVisibility(8);
                        }
                        try {
                            str5 = jSONObject.getString("mobile");
                            try {
                                obj = Double.valueOf(jSONObject.getString("lat"));
                            } catch (JSONException e5) {
                                e = e5;
                                obj = null;
                                obj2 = obj;
                                str6 = obj2;
                                str7 = str6;
                                e.printStackTrace();
                                if (str.trim().equalsIgnoreCase("true") == null) {
                                    str = LoginActivity.this.getSharedPreferences("myloginapp", 0).edit();
                                    str.putBoolean("loggedin", true);
                                    str.commit();
                                    str = new Intent(LoginActivity.this, HomeScreenActivity.class);
                                    str.setFlags(DriveFile.MODE_READ_ONLY);
                                    str.setFlags(32768);
                                    str.setFlags(67108864);
                                    LoginActivity.this.startActivity(str);
                                    Toast.makeText(LoginActivity.this, "Login Successful", 0).show();
                                    str = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                                    str.edit().putString("loginuserId", string).apply();
                                    str.edit().putString("fName", str2).apply();
                                    str.edit().putString("lName", str3).apply();
                                    str.edit().putString("userEmail", str4).apply();
                                    str.edit().putString("userMobileNumber", str5).apply();
                                    str.edit().putString("flat_door", str6).apply();
                                    str.edit().putString("apt_str", str7).apply();
                                    str.edit().putString("address", str8).apply();
                                    str.edit().putString("lat", String.valueOf(obj)).apply();
                                    str.edit().putString("lng", String.valueOf(obj2)).apply();
                                } else {
                                    Toast.makeText(LoginActivity.this, "Invalid Credentials", 1).show();
                                    show.dismiss();
                                }
                                LoginActivity.this.progressBar.setVisibility(8);
                            }
                        } catch (JSONException e6) {
                            e = e6;
                            str5 = null;
                            obj = str5;
                            obj2 = obj;
                            str6 = obj2;
                            str7 = str6;
                            e.printStackTrace();
                            if (str.trim().equalsIgnoreCase("true") == null) {
                                str = LoginActivity.this.getSharedPreferences("myloginapp", 0).edit();
                                str.putBoolean("loggedin", true);
                                str.commit();
                                str = new Intent(LoginActivity.this, HomeScreenActivity.class);
                                str.setFlags(DriveFile.MODE_READ_ONLY);
                                str.setFlags(32768);
                                str.setFlags(67108864);
                                LoginActivity.this.startActivity(str);
                                Toast.makeText(LoginActivity.this, "Login Successful", 0).show();
                                str = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                                str.edit().putString("loginuserId", string).apply();
                                str.edit().putString("fName", str2).apply();
                                str.edit().putString("lName", str3).apply();
                                str.edit().putString("userEmail", str4).apply();
                                str.edit().putString("userMobileNumber", str5).apply();
                                str.edit().putString("flat_door", str6).apply();
                                str.edit().putString("apt_str", str7).apply();
                                str.edit().putString("address", str8).apply();
                                str.edit().putString("lat", String.valueOf(obj)).apply();
                                str.edit().putString("lng", String.valueOf(obj2)).apply();
                            } else {
                                Toast.makeText(LoginActivity.this, "Invalid Credentials", 1).show();
                                show.dismiss();
                            }
                            LoginActivity.this.progressBar.setVisibility(8);
                        }
                        try {
                            obj2 = Double.valueOf(jSONObject.getString("lng"));
                            try {
                                str6 = jSONObject.getString("flat_door");
                            } catch (JSONException e7) {
                                e = e7;
                                str6 = null;
                                str7 = str6;
                                e.printStackTrace();
                                if (str.trim().equalsIgnoreCase("true") == null) {
                                    str = LoginActivity.this.getSharedPreferences("myloginapp", 0).edit();
                                    str.putBoolean("loggedin", true);
                                    str.commit();
                                    str = new Intent(LoginActivity.this, HomeScreenActivity.class);
                                    str.setFlags(DriveFile.MODE_READ_ONLY);
                                    str.setFlags(32768);
                                    str.setFlags(67108864);
                                    LoginActivity.this.startActivity(str);
                                    Toast.makeText(LoginActivity.this, "Login Successful", 0).show();
                                    str = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                                    str.edit().putString("loginuserId", string).apply();
                                    str.edit().putString("fName", str2).apply();
                                    str.edit().putString("lName", str3).apply();
                                    str.edit().putString("userEmail", str4).apply();
                                    str.edit().putString("userMobileNumber", str5).apply();
                                    str.edit().putString("flat_door", str6).apply();
                                    str.edit().putString("apt_str", str7).apply();
                                    str.edit().putString("address", str8).apply();
                                    str.edit().putString("lat", String.valueOf(obj)).apply();
                                    str.edit().putString("lng", String.valueOf(obj2)).apply();
                                } else {
                                    Toast.makeText(LoginActivity.this, "Invalid Credentials", 1).show();
                                    show.dismiss();
                                }
                                LoginActivity.this.progressBar.setVisibility(8);
                            }
                            try {
                                str7 = jSONObject.getString("apt_str");
                                try {
                                    str8 = jSONObject.getString("address");
                                } catch (JSONException e8) {
                                    e = e8;
                                    e.printStackTrace();
                                    if (str.trim().equalsIgnoreCase("true") == null) {
                                        Toast.makeText(LoginActivity.this, "Invalid Credentials", 1).show();
                                        show.dismiss();
                                    } else {
                                        str = LoginActivity.this.getSharedPreferences("myloginapp", 0).edit();
                                        str.putBoolean("loggedin", true);
                                        str.commit();
                                        str = new Intent(LoginActivity.this, HomeScreenActivity.class);
                                        str.setFlags(DriveFile.MODE_READ_ONLY);
                                        str.setFlags(32768);
                                        str.setFlags(67108864);
                                        LoginActivity.this.startActivity(str);
                                        Toast.makeText(LoginActivity.this, "Login Successful", 0).show();
                                        str = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                                        str.edit().putString("loginuserId", string).apply();
                                        str.edit().putString("fName", str2).apply();
                                        str.edit().putString("lName", str3).apply();
                                        str.edit().putString("userEmail", str4).apply();
                                        str.edit().putString("userMobileNumber", str5).apply();
                                        str.edit().putString("flat_door", str6).apply();
                                        str.edit().putString("apt_str", str7).apply();
                                        str.edit().putString("address", str8).apply();
                                        str.edit().putString("lat", String.valueOf(obj)).apply();
                                        str.edit().putString("lng", String.valueOf(obj2)).apply();
                                    }
                                    LoginActivity.this.progressBar.setVisibility(8);
                                }
                            } catch (JSONException e9) {
                                e = e9;
                                str7 = null;
                                e.printStackTrace();
                                if (str.trim().equalsIgnoreCase("true") == null) {
                                    Toast.makeText(LoginActivity.this, "Invalid Credentials", 1).show();
                                    show.dismiss();
                                } else {
                                    str = LoginActivity.this.getSharedPreferences("myloginapp", 0).edit();
                                    str.putBoolean("loggedin", true);
                                    str.commit();
                                    str = new Intent(LoginActivity.this, HomeScreenActivity.class);
                                    str.setFlags(DriveFile.MODE_READ_ONLY);
                                    str.setFlags(32768);
                                    str.setFlags(67108864);
                                    LoginActivity.this.startActivity(str);
                                    Toast.makeText(LoginActivity.this, "Login Successful", 0).show();
                                    str = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                                    str.edit().putString("loginuserId", string).apply();
                                    str.edit().putString("fName", str2).apply();
                                    str.edit().putString("lName", str3).apply();
                                    str.edit().putString("userEmail", str4).apply();
                                    str.edit().putString("userMobileNumber", str5).apply();
                                    str.edit().putString("flat_door", str6).apply();
                                    str.edit().putString("apt_str", str7).apply();
                                    str.edit().putString("address", str8).apply();
                                    str.edit().putString("lat", String.valueOf(obj)).apply();
                                    str.edit().putString("lng", String.valueOf(obj2)).apply();
                                }
                                LoginActivity.this.progressBar.setVisibility(8);
                            }
                        } catch (JSONException e10) {
                            e = e10;
                            obj2 = null;
                            str6 = obj2;
                            str7 = str6;
                            e.printStackTrace();
                            if (str.trim().equalsIgnoreCase("true") == null) {
                                str = LoginActivity.this.getSharedPreferences("myloginapp", 0).edit();
                                str.putBoolean("loggedin", true);
                                str.commit();
                                str = new Intent(LoginActivity.this, HomeScreenActivity.class);
                                str.setFlags(DriveFile.MODE_READ_ONLY);
                                str.setFlags(32768);
                                str.setFlags(67108864);
                                LoginActivity.this.startActivity(str);
                                Toast.makeText(LoginActivity.this, "Login Successful", 0).show();
                                str = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                                str.edit().putString("loginuserId", string).apply();
                                str.edit().putString("fName", str2).apply();
                                str.edit().putString("lName", str3).apply();
                                str.edit().putString("userEmail", str4).apply();
                                str.edit().putString("userMobileNumber", str5).apply();
                                str.edit().putString("flat_door", str6).apply();
                                str.edit().putString("apt_str", str7).apply();
                                str.edit().putString("address", str8).apply();
                                str.edit().putString("lat", String.valueOf(obj)).apply();
                                str.edit().putString("lng", String.valueOf(obj2)).apply();
                            } else {
                                Toast.makeText(LoginActivity.this, "Invalid Credentials", 1).show();
                                show.dismiss();
                            }
                            LoginActivity.this.progressBar.setVisibility(8);
                        }
                    } catch (JSONException e11) {
                        e = e11;
                        str2 = null;
                        str3 = str2;
                        str4 = str3;
                        str5 = str4;
                        obj = str5;
                        obj2 = obj;
                        str6 = obj2;
                        str7 = str6;
                        e.printStackTrace();
                        if (str.trim().equalsIgnoreCase("true") == null) {
                            Toast.makeText(LoginActivity.this, "Invalid Credentials", 1).show();
                            show.dismiss();
                        } else {
                            str = LoginActivity.this.getSharedPreferences("myloginapp", 0).edit();
                            str.putBoolean("loggedin", true);
                            str.commit();
                            str = new Intent(LoginActivity.this, HomeScreenActivity.class);
                            str.setFlags(DriveFile.MODE_READ_ONLY);
                            str.setFlags(32768);
                            str.setFlags(67108864);
                            LoginActivity.this.startActivity(str);
                            Toast.makeText(LoginActivity.this, "Login Successful", 0).show();
                            str = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                            str.edit().putString("loginuserId", string).apply();
                            str.edit().putString("fName", str2).apply();
                            str.edit().putString("lName", str3).apply();
                            str.edit().putString("userEmail", str4).apply();
                            str.edit().putString("userMobileNumber", str5).apply();
                            str.edit().putString("flat_door", str6).apply();
                            str.edit().putString("apt_str", str7).apply();
                            str.edit().putString("address", str8).apply();
                            str.edit().putString("lat", String.valueOf(obj)).apply();
                            str.edit().putString("lng", String.valueOf(obj2)).apply();
                        }
                        LoginActivity.this.progressBar.setVisibility(8);
                    }
                } catch (JSONException e12) {
                    e = e12;
                    str = null;
                    string = str;
                    str2 = string;
                    str3 = str2;
                    str4 = str3;
                    str5 = str4;
                    obj = str5;
                    obj2 = obj;
                    str6 = obj2;
                    str7 = str6;
                    e.printStackTrace();
                    if (str.trim().equalsIgnoreCase("true") == null) {
                        Toast.makeText(LoginActivity.this, "Invalid Credentials", 1).show();
                        show.dismiss();
                    } else {
                        str = LoginActivity.this.getSharedPreferences("myloginapp", 0).edit();
                        str.putBoolean("loggedin", true);
                        str.commit();
                        str = new Intent(LoginActivity.this, HomeScreenActivity.class);
                        str.setFlags(DriveFile.MODE_READ_ONLY);
                        str.setFlags(32768);
                        str.setFlags(67108864);
                        LoginActivity.this.startActivity(str);
                        Toast.makeText(LoginActivity.this, "Login Successful", 0).show();
                        str = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                        str.edit().putString("loginuserId", string).apply();
                        str.edit().putString("fName", str2).apply();
                        str.edit().putString("lName", str3).apply();
                        str.edit().putString("userEmail", str4).apply();
                        str.edit().putString("userMobileNumber", str5).apply();
                        str.edit().putString("flat_door", str6).apply();
                        str.edit().putString("apt_str", str7).apply();
                        str.edit().putString("address", str8).apply();
                        str.edit().putString("lat", String.valueOf(obj)).apply();
                        str.edit().putString("lng", String.valueOf(obj2)).apply();
                    }
                    LoginActivity.this.progressBar.setVisibility(8);
                }
                if (str.trim().equalsIgnoreCase("true") == null) {
                    str = LoginActivity.this.getSharedPreferences("myloginapp", 0).edit();
                    str.putBoolean("loggedin", true);
                    str.commit();
                    str = new Intent(LoginActivity.this, HomeScreenActivity.class);
                    str.setFlags(DriveFile.MODE_READ_ONLY);
                    str.setFlags(32768);
                    str.setFlags(67108864);
                    LoginActivity.this.startActivity(str);
                    Toast.makeText(LoginActivity.this, "Login Successful", 0).show();
                    str = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                    str.edit().putString("loginuserId", string).apply();
                    str.edit().putString("fName", str2).apply();
                    str.edit().putString("lName", str3).apply();
                    str.edit().putString("userEmail", str4).apply();
                    str.edit().putString("userMobileNumber", str5).apply();
                    str.edit().putString("flat_door", str6).apply();
                    str.edit().putString("apt_str", str7).apply();
                    str.edit().putString("address", str8).apply();
                    str.edit().putString("lat", String.valueOf(obj)).apply();
                    str.edit().putString("lng", String.valueOf(obj2)).apply();
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid Credentials", 1).show();
                    show.dismiss();
                }
                LoginActivity.this.progressBar.setVisibility(8);
            }
        }, new ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                show.dismiss();
                LoginActivity.this.progressBar.setVisibility(8);
            }
        }) {
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> hashMap = new HashMap();
                hashMap.put(LoginActivity.KEY_MOBILE_LOGIN, LoginActivity.this.userLoginEmail);
                hashMap.put("password", LoginActivity.this.userLoginPwd);
                return hashMap;
            }
        };
        anonymousClass11.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(anonymousClass11);
        this.progressBar.setVisibility(0);
    }

    protected void onResume() {
        super.onResume();
        this.loggedIn = getSharedPreferences("myloginapp", 0).getBoolean("loggedin", false);
        if (this.loggedIn) {
            Intent intent = new Intent(this, HomeScreenActivity.class);
            intent.addFlags(DriveFile.MODE_READ_ONLY);
            intent.addFlags(32768);
            startActivity(intent);
        }
    }
}
