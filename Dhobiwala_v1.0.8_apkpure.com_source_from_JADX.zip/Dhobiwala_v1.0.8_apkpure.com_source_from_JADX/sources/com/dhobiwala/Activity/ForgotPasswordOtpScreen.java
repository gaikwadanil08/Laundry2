package com.dhobiwala.Activity;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import com.dhobiwala.C0354R;

public class ForgotPasswordOtpScreen extends AppCompatActivity implements OnClickListener {
    private EditText ForgotenteredOtpEdittext;
    private Button back_btn_submit_otp;
    private String enteredOtp;
    private String forgotPasswordMobile;
    private String forgotPasswordOtp;
    private boolean isNetworkAvailable;
    private ProgressDialog loading;
    private ProgressBar progressBar;
    private BroadcastReceiver receiver = new C02972();
    private Button submitOtpButton;
    private Toolbar toolbar;

    /* renamed from: com.dhobiwala.Activity.ForgotPasswordOtpScreen$1 */
    class C02961 implements TextWatcher {
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        C02961() {
        }

        public void afterTextChanged(Editable editable) {
            if (ForgotPasswordOtpScreen.this.ForgotenteredOtpEdittext.getText().toString().trim().equalsIgnoreCase(ForgotPasswordOtpScreen.this.forgotPasswordOtp) != null) {
                editable = new Intent(ForgotPasswordOtpScreen.this, NewPasswordCahngeScreen.class);
                editable.putExtra("forgotPasswordMobile", ForgotPasswordOtpScreen.this.forgotPasswordMobile);
                editable.setFlags(67108864);
                ForgotPasswordOtpScreen.this.startActivity(editable);
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.ForgotPasswordOtpScreen$2 */
    class C02972 extends BroadcastReceiver {
        C02972() {
        }

        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equalsIgnoreCase("otp1") != null) {
                ForgotPasswordOtpScreen.this.ForgotenteredOtpEdittext.setText(intent.getStringExtra("message1"));
            }
        }
    }

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.activity_forgot_pwd_otp_screen);
        this.isNetworkAvailable = NetworkConnectionCheck.isNetworkAvailable(this);
        this.progressBar = (ProgressBar) findViewById(C0354R.id.forgot_pwd_screen_p_bar);
        this.progressBar.setVisibility(4);
        this.ForgotenteredOtpEdittext = (EditText) findViewById(C0354R.id.update_new_pwd_et);
        this.submitOtpButton = (Button) findViewById(C0354R.id.forgot_pwd_submit_otp_button);
        this.back_btn_submit_otp = (Button) findViewById(C0354R.id.back_btn_submit_otp);
        this.submitOtpButton.setOnClickListener(this);
        this.back_btn_submit_otp.setOnClickListener(this);
        bundle = getIntent();
        this.forgotPasswordMobile = bundle.getStringExtra("forgotPasswordMobile");
        this.forgotPasswordOtp = bundle.getStringExtra("changePasswordOtp");
        this.ForgotenteredOtpEdittext.addTextChangedListener(new C02961());
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onClick(View view) {
        if (view == this.submitOtpButton) {
            this.enteredOtp = this.ForgotenteredOtpEdittext.getText().toString().trim();
            if (this.enteredOtp.equalsIgnoreCase(this.forgotPasswordOtp)) {
                Intent intent = new Intent(this, NewPasswordCahngeScreen.class);
                intent.putExtra("forgotPasswordMobile", this.forgotPasswordMobile);
                intent.setFlags(67108864);
                startActivity(intent);
            } else {
                this.ForgotenteredOtpEdittext.setError("Enter valid OTP");
            }
        }
        if (view == this.back_btn_submit_otp) {
            startActivity(new Intent(this, LoginActivity.class));
        }
    }

    public void onResume() {
        LocalBroadcastManager.getInstance(this).registerReceiver(this.receiver, new IntentFilter("otp1"));
        super.onResume();
    }

    public void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(this.receiver);
    }
}
