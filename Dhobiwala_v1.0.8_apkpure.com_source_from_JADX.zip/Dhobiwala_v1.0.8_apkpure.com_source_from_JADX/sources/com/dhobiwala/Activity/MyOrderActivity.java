package com.dhobiwala.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ProgressBar;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dhobiwala.Adapter.MyOrdersAdapter;
import com.dhobiwala.C0354R;
import com.dhobiwala.Utils.HttpsTrustManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public class MyOrderActivity extends AppCompatActivity {
    public static final String KEY_MY_ORDERS_ARRAY = "order";
    public static final String KEY_MY_ORDERS_CLIENT_ID = "client_id";
    public static final String KEY_MY_ORDERS_DATE = "order_date";
    public static final String KEY_MY_ORDERS_ID = "order_id";
    public static final String KEY_MY_ORDERS_PICKUP_DATE = "p_date";
    public static final String KEY_MY_ORDERS_PICKUP_TIME = "p_time";
    public static final String KEY_MY_ORDERS_SERVICES = "services";
    public static final String KEY_MY_ORDERS_STATUS = "status";
    public static final String KEY_MY_ORDERS_SUCCESS_MESSAGE = "success";
    public static final String TAG_MY_ORDERS_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=my_order";
    private String clientId;
    JSONArray jsonArray;
    JSONObject jsonObject;
    private String message;
    private RecyclerView myOrderRecyclerview;
    private MyOrdersAdapter myOrdersAdapter;
    protected ArrayList<HashMap<String, String>> myOrdersArrayList;
    protected HashMap<String, String> myOrdersData = null;
    private String orderDate;
    private String orderId;
    private String pickupDate;
    private String pickupTime;
    private ProgressBar progressBar;
    private String services;
    private String status;
    private Toolbar toolbar;

    /* renamed from: com.dhobiwala.Activity.MyOrderActivity$1 */
    class C03121 implements OnClickListener {
        C03121() {
        }

        public void onClick(View view) {
            view = new Intent(MyOrderActivity.this, HomeScreenActivity.class);
            view.setFlags(67108864);
            MyOrderActivity.this.startActivity(view);
        }
    }

    /* renamed from: com.dhobiwala.Activity.MyOrderActivity$2 */
    class C05542 implements Listener<String> {
        C05542() {
        }

        public void onResponse(String str) {
            MyOrderActivity.this.progressBar.setVisibility(8);
            try {
                MyOrderActivity.this.myOrdersArrayList = new ArrayList();
                MyOrderActivity.this.jsonObject = new JSONObject(str);
                MyOrderActivity.this.message = MyOrderActivity.this.jsonObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                MyOrderActivity.this.jsonArray = MyOrderActivity.this.jsonObject.getJSONArray(MyOrderActivity.KEY_MY_ORDERS_ARRAY);
                for (str = null; str < MyOrderActivity.this.jsonArray.length(); str++) {
                    MyOrderActivity.this.myOrdersData = new HashMap();
                    MyOrderActivity.this.jsonObject = MyOrderActivity.this.jsonArray.getJSONObject(str);
                    MyOrderActivity.this.myOrdersData.put("order_id", MyOrderActivity.this.jsonObject.getString("order_id"));
                    MyOrderActivity.this.myOrdersData.put(MyOrderActivity.KEY_MY_ORDERS_DATE, MyOrderActivity.this.jsonObject.getString(MyOrderActivity.KEY_MY_ORDERS_DATE));
                    MyOrderActivity.this.myOrdersData.put("status", MyOrderActivity.this.jsonObject.getString("status"));
                    MyOrderActivity.this.myOrdersData.put(MyOrderActivity.KEY_MY_ORDERS_SERVICES, MyOrderActivity.this.jsonObject.getString(MyOrderActivity.KEY_MY_ORDERS_SERVICES));
                    MyOrderActivity.this.myOrdersData.put("p_date", MyOrderActivity.this.jsonObject.getString("p_date"));
                    MyOrderActivity.this.myOrdersData.put(MyOrderActivity.KEY_MY_ORDERS_PICKUP_TIME, MyOrderActivity.this.jsonObject.getString(MyOrderActivity.KEY_MY_ORDERS_PICKUP_TIME));
                    MyOrderActivity.this.myOrdersArrayList.add(MyOrderActivity.this.myOrdersData);
                }
            } catch (String str2) {
                str2.printStackTrace();
            }
            if (MyOrderActivity.this.myOrdersData != null) {
                MyOrderActivity.this.myOrdersAdapter = new MyOrdersAdapter(MyOrderActivity.this, MyOrderActivity.this.myOrdersArrayList);
                MyOrderActivity.this.myOrderRecyclerview.setAdapter(MyOrderActivity.this.myOrdersAdapter);
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.MyOrderActivity$3 */
    class C05553 implements ErrorListener {
        public void onErrorResponse(VolleyError volleyError) {
        }

        C05553() {
        }
    }

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.activity_my_order);
        this.progressBar = (ProgressBar) findViewById(C0354R.id.my_order_p_bar);
        this.toolbar = (Toolbar) findViewById(C0354R.id.my_order_toolbar);
        setSupportActionBar(this.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle((CharSequence) "My Orders");
        this.toolbar.setNavigationOnClickListener(new C03121());
        this.clientId = PreferenceManager.getDefaultSharedPreferences(this).getString("loginuserId", null);
        this.myOrderRecyclerview = (RecyclerView) findViewById(C0354R.id.my_order_recyclerview);
        this.myOrderRecyclerview.setLayoutManager(new LinearLayoutManager(this));
        getMyOrders();
    }

    private void getMyOrders() {
        HttpsTrustManager.allowAllSSL();
        Request c06274 = new StringRequest(1, TAG_MY_ORDERS_URL, new C05542(), new C05553()) {
            protected Map<String, String> getParams() {
                Map<String, String> hashMap = new HashMap();
                hashMap.put("client_id", MyOrderActivity.this.clientId);
                return hashMap;
            }
        };
        c06274.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(c06274);
        this.progressBar.setVisibility(0);
    }
}
