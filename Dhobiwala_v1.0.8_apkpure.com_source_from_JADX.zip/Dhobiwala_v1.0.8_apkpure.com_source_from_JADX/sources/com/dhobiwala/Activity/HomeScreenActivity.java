package com.dhobiwala.Activity;

import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.design.widget.NavigationView.OnNavigationItemSelectedListener;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dhobiwala.Activity.RecyclerItemClickListener.OnItemClickListener;
import com.dhobiwala.Adapter.ServiceScreenAdapter;
import com.dhobiwala.Adapter.SwipePagerAdapter;
import com.dhobiwala.C0354R;
import com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate;
import com.dhobiwala.Fragment.RatecardFragment;
import com.dhobiwala.Fragment.SupportFragment;
import com.dhobiwala.Models.ServicesData;
import com.dhobiwala.Utils.HttpsTrustManager;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import org.json.JSONObject;
import org.jsoup.Jsoup;

public class HomeScreenActivity extends AppCompatActivity implements OnClickListener {
    private static final int GPS_ENABLE_REQUEST = 4097;
    private static final float MIN_DISTANCE = 1000.0f;
    private static final long MIN_TIME = 400;
    public static final String TAG_HOME_SCREEN_SERVICE_LIST_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=service_list";
    private String ServiceNameString;
    private String ServiceTextviewName = " ";
    private String address;
    private String apt_str;
    int backButtonCount = 0;
    private Button bookPickupBtn;
    private Button btnSubmit;
    String currentVersion;
    Dialog dialog;
    private String fName;
    private String flat_door;
    FragmentManager fragmentManager;
    private Button header_profile_btn;
    private DividerItemDecoration horizontalDeviderDecoration;
    private String lName;
    private long lastBackPressTime = 0;
    String latestVersion;
    private Double latitude;
    private Double longitude;
    private ActionBarDrawerToggle mActionBarDrawerToggle;
    private DrawerLayout mDrawerLayout;
    private GridLayoutManager mGridLayoutManager;
    private Handler mHandler;
    private LocationManager mLocationManager;
    private ArrayList<ServicesData> mServicesData;
    private String message;
    private NavigationView naviDrawer;
    private RelativeLayout network_relatiive;
    int position = 0;
    private SharedPreferences prefs;
    private ProgressBar progressBar;
    private RatingBar ratingBar;
    private Runnable runnable = new C02993();
    private RecyclerView serviceRecyclerView;
    private ServiceScreenAdapter serviceScreenAdapter;
    private SwipePagerAdapter spa;
    private Toast toast;
    private Toolbar toolbar;
    private TextView txtRatingValue;
    private String userEmail;
    private String userMobileNumber;
    private TextView userProfileEmailTextview;
    private TextView userProfileFirstNameTextview;
    private TextView userProfileLastNameTextview;
    private TextView userProfileMobileTextview;
    private ViewPager viewPager;

    /* renamed from: com.dhobiwala.Activity.HomeScreenActivity$1 */
    class C02981 implements OnClickListener {
        C02981() {
        }

        public void onClick(View view) {
            if (view == HomeScreenActivity.this.header_profile_btn) {
                view = new Intent(HomeScreenActivity.this, UserProfileActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("fName", HomeScreenActivity.this.fName);
                bundle.putString("lName", HomeScreenActivity.this.lName);
                bundle.putString("userEmail", HomeScreenActivity.this.userEmail);
                bundle.putString("userMobileNumber", HomeScreenActivity.this.userMobileNumber);
                bundle.putString("flat_door", HomeScreenActivity.this.flat_door);
                bundle.putString("apt_str", HomeScreenActivity.this.apt_str);
                bundle.putString("address", HomeScreenActivity.this.address);
                bundle.putString("lat", String.valueOf(HomeScreenActivity.this.latitude));
                bundle.putString("lng", String.valueOf(HomeScreenActivity.this.longitude));
                view.putExtras(bundle);
                HomeScreenActivity.this.startActivity(view);
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.HomeScreenActivity$3 */
    class C02993 implements Runnable {
        C02993() {
        }

        public void run() {
            if (HomeScreenActivity.this.position >= 4) {
                HomeScreenActivity.this.position = 0;
            } else {
                HomeScreenActivity.this.position++;
            }
            HomeScreenActivity.this.viewPager.setCurrentItem(HomeScreenActivity.this.position, true);
            HomeScreenActivity.this.mHandler.postDelayed(HomeScreenActivity.this.runnable, 2000);
        }
    }

    /* renamed from: com.dhobiwala.Activity.HomeScreenActivity$9 */
    class C03029 implements DialogInterface.OnClickListener {
        C03029() {
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            dialogInterface = HomeScreenActivity.this.getSharedPreferences("myloginapp", 0).edit();
            dialogInterface.putBoolean("loggedin", false);
            dialogInterface.putString("user_id", "");
            dialogInterface.apply();
            dialogInterface = new Intent(HomeScreenActivity.this, LoginActivity.class);
            dialogInterface.setFlags(67108864);
            HomeScreenActivity.this.startActivity(dialogInterface);
            HomeScreenActivity.this.finish();
        }
    }

    private class GetLatestVersion extends AsyncTask<String, String, JSONObject> {
        private ProgressDialog progressDialog;

        private GetLatestVersion() {
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected JSONObject doInBackground(String... strArr) {
            try {
                strArr = Jsoup.connect("https://play.google.com/store/apps/details?id=com.dhobiwala&hl=en").get();
                HomeScreenActivity.this.latestVersion = strArr.getElementsByAttributeValue("itemprop", "softwareVersion").first().text();
            } catch (String[] strArr2) {
                strArr2.printStackTrace();
            }
            return new JSONObject();
        }

        protected void onPostExecute(JSONObject jSONObject) {
            if (HomeScreenActivity.this.latestVersion == null) {
                super.onPostExecute(jSONObject);
            } else if (HomeScreenActivity.this.currentVersion.equalsIgnoreCase(HomeScreenActivity.this.latestVersion) == null && HomeScreenActivity.this.isFinishing() == null) {
                HomeScreenActivity.this.showUpdateDialog();
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.HomeScreenActivity$2 */
    class C05462 implements OnItemClickListener {
        C05462() {
        }

        public void onItemClick(View view, int i) {
            try {
                HomeScreenActivity.this.serviceScreenAdapter.setSelected(i);
            } catch (View view2) {
                view2.printStackTrace();
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.HomeScreenActivity$4 */
    class C05474 implements Listener<String> {
        C05474() {
        }

        public void onResponse(String str) {
            HomeScreenActivity.this.progressBar.setVisibility(8);
            Log.e("Services_response", str.toString());
            List arrayList = new ArrayList();
            try {
                JSONObject jSONObject = new JSONObject(str);
                Log.d("Jsonobject response", jSONObject.toString());
                Log.d("Success msg", jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE));
                str = jSONObject.getJSONArray("service_list");
                Log.d("JsonArray response", str.toString());
                for (int i = 0; i < str.length(); i++) {
                    ServicesData servicesData = new ServicesData();
                    JSONObject jSONObject2 = str.getJSONObject(i);
                    servicesData.setServiceid(jSONObject2.getString(OrderConfirmationActivity.KEY_SERVICES_ID).trim());
                    servicesData.setServicename(jSONObject2.getString("service_name").trim());
                    servicesData.setServiceimgs(jSONObject2.getString("service_image"));
                    arrayList.add(servicesData);
                }
                HomeScreenActivity.this.serviceScreenAdapter = new ServiceScreenAdapter((ArrayList) arrayList, HomeScreenActivity.this.getApplicationContext());
                HomeScreenActivity.this.serviceRecyclerView.setAdapter(HomeScreenActivity.this.serviceScreenAdapter);
            } catch (String str2) {
                str2.printStackTrace();
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.HomeScreenActivity$5 */
    class C05485 implements ErrorListener {
        C05485() {
        }

        public void onErrorResponse(VolleyError volleyError) {
            HomeScreenActivity.this.progressBar.setVisibility(8);
        }
    }

    /* renamed from: com.dhobiwala.Activity.HomeScreenActivity$8 */
    class C05498 implements OnNavigationItemSelectedListener {
        C05498() {
        }

        public boolean onNavigationItemSelected(MenuItem menuItem) {
            HomeScreenActivity.this.selectDrawerItem(menuItem);
            return true;
        }
    }

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.activity_home_screen);
        getCurrentVersion();
        this.network_relatiive = (RelativeLayout) findViewById(C0354R.id.network_error_relative_layout);
        this.progressBar = (ProgressBar) findViewById(C0354R.id.loading_progress_bar);
        this.progressBar.setVisibility(8);
        this.toolbar = (Toolbar) findViewById(C0354R.id.home_screen_toolbar);
        setSupportActionBar(this.toolbar);
        this.prefs = PreferenceManager.getDefaultSharedPreferences(this);
        this.fName = this.prefs.getString("fName", null);
        this.lName = this.prefs.getString("lName", null);
        this.userEmail = this.prefs.getString("userEmail", null);
        this.userMobileNumber = this.prefs.getString("userMobileNumber", null);
        this.flat_door = this.prefs.getString("flat_door", null);
        this.apt_str = this.prefs.getString("apt_str", null);
        this.address = this.prefs.getString("address", null);
        this.latitude = Double.valueOf(this.prefs.getString("lat", null));
        bundle = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("lat_homescreen");
        stringBuilder.append(this.latitude.toString());
        bundle.print(stringBuilder.toString());
        this.longitude = Double.valueOf(this.prefs.getString("lng", null));
        bundle = System.out;
        stringBuilder = new StringBuilder();
        stringBuilder.append("lon_homescreen");
        stringBuilder.append(this.longitude.toString());
        bundle.print(stringBuilder.toString());
        this.mDrawerLayout = (DrawerLayout) findViewById(C0354R.id.drawer_layout);
        this.mActionBarDrawerToggle = setupDrawerToggle();
        this.mDrawerLayout.addDrawerListener(this.mActionBarDrawerToggle);
        this.mDrawerLayout = (DrawerLayout) findViewById(C0354R.id.drawer_layout);
        this.naviDrawer = (NavigationView) findViewById(C0354R.id.nav_menu);
        this.header_profile_btn = (Button) this.naviDrawer.getHeaderView(0).findViewById(C0354R.id.header_update_btn);
        this.header_profile_btn.setOnClickListener(new C02981());
        this.userProfileFirstNameTextview = (TextView) this.naviDrawer.getHeaderView(0).findViewById(C0354R.id.nav_profile_first_name);
        this.userProfileLastNameTextview = (TextView) this.naviDrawer.getHeaderView(0).findViewById(C0354R.id.nav_profile_last_name);
        this.userProfileEmailTextview = (TextView) this.naviDrawer.getHeaderView(0).findViewById(C0354R.id.nav_profile_email);
        this.userProfileMobileTextview = (TextView) this.naviDrawer.getHeaderView(0).findViewById(C0354R.id.nav_profile_Mobile);
        this.userProfileFirstNameTextview.setText(this.fName);
        this.userProfileLastNameTextview.setText(this.lName);
        this.userProfileEmailTextview.setText(this.userEmail);
        this.userProfileMobileTextview.setText(this.userMobileNumber);
        setupDrawerContent(this.naviDrawer);
        this.mActionBarDrawerToggle.syncState();
        this.bookPickupBtn = (Button) findViewById(C0354R.id.Book_pickup_btn);
        this.bookPickupBtn.setOnClickListener(this);
        this.viewPager = (ViewPager) findViewById(C0354R.id.view_pager_home_screen);
        this.spa = new SwipePagerAdapter(this);
        this.viewPager.setAdapter(this.spa);
        this.mHandler = new Handler();
        this.serviceRecyclerView = (RecyclerView) findViewById(C0354R.id.horizontal_recycler_view);
        this.mGridLayoutManager = new GridLayoutManager(this, 3);
        this.serviceRecyclerView.setLayoutManager(this.mGridLayoutManager);
        this.serviceRecyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), new C05462()));
        servicesdetails();
    }

    public void onPause() {
        if (this.mHandler != null) {
            this.mHandler.removeCallbacks(this.runnable);
        }
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.mHandler.postDelayed(this.runnable, 2000);
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        if (i == 4097) {
            if (this.mLocationManager == null) {
                this.mLocationManager = (LocationManager) getSystemService(Param.LOCATION);
            }
            super.onActivityResult(i, i2, intent);
        }
    }

    public void onClick(View view) {
        this.ServiceNameString = this.prefs.getString("RecyclerviewService", "");
        if (view != this.bookPickupBtn) {
            return;
        }
        if (this.ServiceNameString.equals("") != null) {
            Toast.makeText(this, "Select Service", 1).show();
            return;
        }
        view = new Bundle();
        FragmentManager fragmentManager = getFragmentManager();
        DialogFragmentForPickupTimeAndDate dialogFragmentForPickupTimeAndDate = new DialogFragmentForPickupTimeAndDate();
        view.putString("RecyclerviewService", this.ServiceNameString);
        dialogFragmentForPickupTimeAndDate.setArguments(view);
        dialogFragmentForPickupTimeAndDate.show(fragmentManager, "something");
    }

    private void servicesdetails() {
        HttpsTrustManager.allowAllSSL();
        Request c06256 = new StringRequest(1, TAG_HOME_SCREEN_SERVICE_LIST_URL, new C05474(), new C05485()) {
            protected Map<String, String> getParams() {
                return new HashMap();
            }
        };
        c06256.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(c06256);
        this.progressBar.setVisibility(0);
    }

    public void onStart() {
        super.onStart();
        final Handler handler = new Handler();
        new Timer().schedule(new TimerTask() {

            /* renamed from: com.dhobiwala.Activity.HomeScreenActivity$7$1 */
            class C03001 implements Runnable {
                C03001() {
                }

                public void run() {
                    /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
                    /*
                    r2 = this;
                    r0 = com.dhobiwala.Activity.HomeScreenActivity.C03017.this;	 Catch:{ Exception -> 0x000b }
                    r0 = com.dhobiwala.Activity.HomeScreenActivity.this;	 Catch:{ Exception -> 0x000b }
                    r1 = com.dhobiwala.Activity.HomeScreenActivity.C03017.this;	 Catch:{ Exception -> 0x000b }
                    r1 = com.dhobiwala.Activity.HomeScreenActivity.this;	 Catch:{ Exception -> 0x000b }
                    r0.isOnline(r1);	 Catch:{ Exception -> 0x000b }
                L_0x000b:
                    return;
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.dhobiwala.Activity.HomeScreenActivity.7.1.run():void");
                }
            }

            public void run() {
                handler.post(new C03001());
            }
        }, 0, 1000);
    }

    public boolean isOnline(Context context) {
        context = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("NET INFO==");
        stringBuilder.append(context);
        printStream.println(stringBuilder.toString());
        if (context != null) {
            this.network_relatiive.setVisibility(4);
            this.bookPickupBtn.setEnabled(true);
            this.bookPickupBtn.setBackgroundColor(Color.rgb(238, 70, 75));
        } else {
            this.network_relatiive.setVisibility(0);
            this.bookPickupBtn.setBackgroundColor(Color.rgb(255, 228, 225));
            this.bookPickupBtn.setEnabled(false);
        }
        if (context == null || context.isConnectedOrConnecting() == null) {
            return false;
        }
        return true;
    }

    private void setupDrawerContent(NavigationView navigationView) {
        navigationView.setNavigationItemSelectedListener(new C05498());
    }

    private ActionBarDrawerToggle setupDrawerToggle() {
        return new ActionBarDrawerToggle(this, this.mDrawerLayout, this.toolbar, C0354R.string.drawer_open, C0354R.string.drawer_close);
    }

    public void selectDrawerItem(MenuItem menuItem) {
        Class cls;
        Fragment fragment;
        this.bookPickupBtn.setVisibility(8);
        switch (menuItem.getItemId()) {
            case C0354R.id.nav_donate_cloths_fragment:
                menuItem = new Intent(this, DonateClothsActivity.class);
                menuItem.setFlags(67108864);
                startActivity(menuItem);
                return;
            case C0354R.id.nav_logout_fragment:
                this.bookPickupBtn.setVisibility(0);
                logout();
                return;
            case C0354R.id.nav_my_order_fragment:
                menuItem = new Intent(this, MyOrderActivity.class);
                menuItem.setFlags(67108864);
                startActivity(menuItem);
                return;
            case C0354R.id.nav_rate_card_fragment:
                cls = RatecardFragment.class;
                break;
            case C0354R.id.nav_refer_a_friend_fragment:
                menuItem = new Intent("android.intent.action.SEND");
                menuItem.setType("text/plain");
                menuItem.putExtra("android.intent.extra.SUBJECT", "Welcome to Dhobiwala");
                menuItem.putExtra("android.intent.extra.TEXT", "https://goo.gl/cBQtTX");
                startActivity(Intent.createChooser(menuItem, "Share with"));
                return;
            case C0354R.id.nav_schedule_pick_fragment:
                menuItem = new Intent(this, HomeScreenActivity.class);
                menuItem.setFlags(67108864);
                startActivity(menuItem);
                return;
            case C0354R.id.nav_support_fragment:
                cls = SupportFragment.class;
                break;
            case C0354R.id.nav_terms_of_use_fragment:
                this.bookPickupBtn.setVisibility(0);
                menuItem = new Intent(this, TermsAndConditionsActivity.class);
                menuItem.setFlags(67141632);
                startActivity(menuItem);
                return;
            default:
                menuItem = new Intent(this, HomeScreenActivity.class);
                menuItem.setFlags(67108864);
                startActivity(menuItem);
                return;
        }
        try {
            fragment = (Fragment) cls.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
            fragment = null;
        }
        this.fragmentManager = getFragmentManager();
        getFragmentManager().popBackStack(null, 1);
        getFragmentManager().beginTransaction().replace(C0354R.id.fragment_content, fragment).addToBackStack(null).commit();
        menuItem.setChecked(true);
        setTitle(menuItem.getTitle());
        this.mDrawerLayout.closeDrawers();
    }

    protected void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        this.mActionBarDrawerToggle.syncState();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.mActionBarDrawerToggle.onConfigurationChanged(configuration);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            this.mDrawerLayout.openDrawer(8388611);
            onBackPressed();
            return true;
        } else if (this.mActionBarDrawerToggle.onOptionsItemSelected(menuItem)) {
            return true;
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
    }

    public void onBackPressed() {
        this.bookPickupBtn.setVisibility(0);
        this.toolbar.setTitle((int) C0354R.string.app_name);
        if (this.mDrawerLayout.isDrawerOpen(8388611)) {
            this.mDrawerLayout.closeDrawer(8388611);
        } else {
            super.onBackPressed();
        }
    }

    private void logout() {
        Builder builder = new Builder(this);
        builder.setMessage((CharSequence) "Are you sure you want to logout?");
        builder.setPositiveButton((CharSequence) "Yes", new C03029());
        builder.setNegativeButton((CharSequence) "No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.create().show();
    }

    private void getCurrentVersion() {
        PackageInfo packageInfo;
        try {
            packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (NameNotFoundException e) {
            e.printStackTrace();
            packageInfo = null;
        }
        this.currentVersion = packageInfo.versionName;
        new GetLatestVersion().execute(new String[0]);
    }

    private void showUpdateDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.setCancelable(false);
        dialog.setContentView(C0354R.layout.custom_alert);
        ((Button) dialog.findViewById(C0354R.id.dialogButtonOK)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                HomeScreenActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.dhobiwala")));
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
