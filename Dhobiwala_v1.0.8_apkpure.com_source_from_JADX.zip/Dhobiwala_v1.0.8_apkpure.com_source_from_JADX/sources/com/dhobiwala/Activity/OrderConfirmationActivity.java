package com.dhobiwala.Activity;

import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dhobiwala.C0354R;
import com.dhobiwala.Fragment.CongratulationDialogFragment;
import com.dhobiwala.Utils.HttpsTrustManager;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class OrderConfirmationActivity extends AppCompatActivity implements OnClickListener {
    public static final String KEY_CITY_ID = "city_id";
    public static final String KEY_CLIENT_ID = "client_id";
    public static final String KEY_CLINT_ID = "client_id";
    public static final String KEY_COUPON_CODE = "coupon_code";
    public static final String KEY_DELIVERY_ADDRESS = "address";
    public static final String KEY_DELIVERY_APARTMENT_STREET = "apt_str";
    public static final String KEY_DELIVERY_FLAT_DOOR = "flat_door";
    public static final String KEY_LATITUDE = "lat";
    public static final String KEY_LONGITUDE = "lng";
    public static final String KEY_PHONE = "phone";
    public static final String KEY_PICKUP_DATE = "p_date";
    public static final String KEY_PICKUP_TIME_SLOT = "p_time_slot";
    public static final String KEY_SERVICES = "service";
    public static final String KEY_SERVICES_ID = "service_id";
    public static final String KEY_STORE_ID = "store_id";
    public static final String TAG_COUPON_CODE_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=apply_coupon";
    public static final String TAG_SERVICE_SCREEN_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=new_order";
    TextView AddressTV;
    TextView Apt_streetTV;
    TextView Flat_doorTV;
    private String FullName;
    TextView Full_nameTV;
    private String StringServiceName;
    private String StringServiceNameId;
    private String StringService_TvpickUpDay;
    private String StringService_TvpickupTime;
    private String TimeSlotId;
    private String address;
    private String apt_str;
    private String cityId;
    private String clientId;
    private Button continueBtn;
    private String couponCodeStr;
    private String fName;
    private String flat_door;
    private String lName;
    private String lat;
    private String lng;
    private TextView pickup_date_tv_get;
    private TextView pickup_time_tv_get;
    private int position;
    private SharedPreferences prefs;
    private ProgressBar progressBar;
    private TextView promoCodeApplyBtn;
    private EditText promocodeEt;
    private TextView service_tv;
    private String storeId;
    private String userMobileNumber;

    /* renamed from: com.dhobiwala.Activity.OrderConfirmationActivity$7 */
    class C03207 implements DialogInterface.OnClickListener {
        C03207() {
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            OrderConfirmationActivity.this.continueBtn.setBackgroundColor(Color.rgb(255, 228, 225));
            OrderConfirmationActivity.this.continueBtn.setEnabled(0);
            OrderConfirmationActivity.this.userOrderDetails(OrderConfirmationActivity.this.couponCodeStr);
        }
    }

    /* renamed from: com.dhobiwala.Activity.OrderConfirmationActivity$1 */
    class C05601 implements Listener<String> {

        /* renamed from: com.dhobiwala.Activity.OrderConfirmationActivity$1$1 */
        class C03191 implements DialogInterface.OnClickListener {
            C03191() {
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }

        C05601() {
        }

        public void onResponse(String str) {
            CharSequence string;
            Builder builder;
            Log.e("coupon_code_res:", str.toString());
            String str2 = "";
            String str3 = "";
            OrderConfirmationActivity.this.progressBar.setVisibility(8);
            try {
                JSONObject jSONObject = new JSONObject(str);
                str = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("jsonobj_response");
                stringBuilder.append(jSONObject);
                str.println(stringBuilder.toString());
                str = jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                try {
                    string = jSONObject.getString("msg");
                } catch (JSONException e) {
                    JSONException jSONException = e;
                    str2 = str;
                    str = jSONException;
                    str.printStackTrace();
                    str = str2;
                    string = str3;
                    if (str.equalsIgnoreCase("true")) {
                        builder = new Builder(OrderConfirmationActivity.this);
                        builder.setMessage(string);
                        builder.setCancelable(false);
                        builder.setPositiveButton((CharSequence) "ok", new C03191());
                        builder.create().show();
                    }
                    if (str.equalsIgnoreCase("false") != null) {
                        OrderConfirmationActivity.this.progressBar.setVisibility(8);
                        Toast.makeText(OrderConfirmationActivity.this, string, 1).show();
                    }
                    OrderConfirmationActivity.this.progressBar.setVisibility(8);
                }
            } catch (JSONException e2) {
                str = e2;
                str.printStackTrace();
                str = str2;
                string = str3;
                if (str.equalsIgnoreCase("true")) {
                    builder = new Builder(OrderConfirmationActivity.this);
                    builder.setMessage(string);
                    builder.setCancelable(false);
                    builder.setPositiveButton((CharSequence) "ok", new C03191());
                    builder.create().show();
                }
                if (str.equalsIgnoreCase("false") != null) {
                    OrderConfirmationActivity.this.progressBar.setVisibility(8);
                    Toast.makeText(OrderConfirmationActivity.this, string, 1).show();
                }
                OrderConfirmationActivity.this.progressBar.setVisibility(8);
            }
            if (str.equalsIgnoreCase("true")) {
                builder = new Builder(OrderConfirmationActivity.this);
                builder.setMessage(string);
                builder.setCancelable(false);
                builder.setPositiveButton((CharSequence) "ok", new C03191());
                builder.create().show();
            }
            if (str.equalsIgnoreCase("false") != null) {
                OrderConfirmationActivity.this.progressBar.setVisibility(8);
                Toast.makeText(OrderConfirmationActivity.this, string, 1).show();
            }
            OrderConfirmationActivity.this.progressBar.setVisibility(8);
        }
    }

    /* renamed from: com.dhobiwala.Activity.OrderConfirmationActivity$2 */
    class C05612 implements ErrorListener {
        public void onErrorResponse(VolleyError volleyError) {
        }

        C05612() {
        }
    }

    /* renamed from: com.dhobiwala.Activity.OrderConfirmationActivity$4 */
    class C05624 implements Listener<String> {
        C05624() {
        }

        public void onResponse(String str) {
            CharSequence string;
            FragmentManager fragmentManager;
            CongratulationDialogFragment congratulationDialogFragment;
            Bundle bundle;
            Log.e("Order_response:", str.toString());
            String str2 = "";
            String str3 = "";
            String str4 = "";
            OrderConfirmationActivity.this.progressBar.setVisibility(8);
            try {
                JSONObject jSONObject = new JSONObject(str);
                str = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("jsonobj_response");
                stringBuilder.append(jSONObject);
                str.println(stringBuilder.toString());
                str = jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                try {
                    string = jSONObject.getString("msg");
                } catch (JSONException e) {
                    JSONException jSONException = e;
                    str2 = str;
                    str = jSONException;
                    str.printStackTrace();
                    str = str2;
                    string = str3;
                    str3 = str4;
                    if (str.equalsIgnoreCase("true")) {
                        fragmentManager = OrderConfirmationActivity.this.getFragmentManager();
                        congratulationDialogFragment = new CongratulationDialogFragment();
                        bundle = new Bundle();
                        bundle.putString("orderId", str3);
                        congratulationDialogFragment.setArguments(bundle);
                        congratulationDialogFragment.show(fragmentManager, " Dialog Fragment");
                    }
                    if (str.equalsIgnoreCase("false") != null) {
                        OrderConfirmationActivity.this.progressBar.setVisibility(8);
                        Toast.makeText(OrderConfirmationActivity.this, string, 1).show();
                    }
                    OrderConfirmationActivity.this.progressBar.setVisibility(8);
                }
                try {
                    str3 = jSONObject.getString("order_id");
                } catch (JSONException e2) {
                    CharSequence charSequence = string;
                    str2 = str;
                    str = e2;
                    str3 = charSequence;
                    str.printStackTrace();
                    str = str2;
                    string = str3;
                    str3 = str4;
                    if (str.equalsIgnoreCase("true")) {
                        fragmentManager = OrderConfirmationActivity.this.getFragmentManager();
                        congratulationDialogFragment = new CongratulationDialogFragment();
                        bundle = new Bundle();
                        bundle.putString("orderId", str3);
                        congratulationDialogFragment.setArguments(bundle);
                        congratulationDialogFragment.show(fragmentManager, " Dialog Fragment");
                    }
                    if (str.equalsIgnoreCase("false") != null) {
                        OrderConfirmationActivity.this.progressBar.setVisibility(8);
                        Toast.makeText(OrderConfirmationActivity.this, string, 1).show();
                    }
                    OrderConfirmationActivity.this.progressBar.setVisibility(8);
                }
            } catch (JSONException e3) {
                str = e3;
                str.printStackTrace();
                str = str2;
                string = str3;
                str3 = str4;
                if (str.equalsIgnoreCase("true")) {
                    fragmentManager = OrderConfirmationActivity.this.getFragmentManager();
                    congratulationDialogFragment = new CongratulationDialogFragment();
                    bundle = new Bundle();
                    bundle.putString("orderId", str3);
                    congratulationDialogFragment.setArguments(bundle);
                    congratulationDialogFragment.show(fragmentManager, " Dialog Fragment");
                }
                if (str.equalsIgnoreCase("false") != null) {
                    OrderConfirmationActivity.this.progressBar.setVisibility(8);
                    Toast.makeText(OrderConfirmationActivity.this, string, 1).show();
                }
                OrderConfirmationActivity.this.progressBar.setVisibility(8);
            }
            if (str.equalsIgnoreCase("true")) {
                fragmentManager = OrderConfirmationActivity.this.getFragmentManager();
                congratulationDialogFragment = new CongratulationDialogFragment();
                bundle = new Bundle();
                bundle.putString("orderId", str3);
                congratulationDialogFragment.setArguments(bundle);
                congratulationDialogFragment.show(fragmentManager, " Dialog Fragment");
            }
            if (str.equalsIgnoreCase("false") != null) {
                OrderConfirmationActivity.this.progressBar.setVisibility(8);
                Toast.makeText(OrderConfirmationActivity.this, string, 1).show();
            }
            OrderConfirmationActivity.this.progressBar.setVisibility(8);
        }
    }

    /* renamed from: com.dhobiwala.Activity.OrderConfirmationActivity$5 */
    class C05635 implements ErrorListener {
        public void onErrorResponse(VolleyError volleyError) {
        }

        C05635() {
        }
    }

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.order_confirmation_activity);
        this.Full_nameTV = (TextView) findViewById(C0354R.id.delivery_full_name);
        this.Flat_doorTV = (TextView) findViewById(C0354R.id.delivery_flat_door);
        this.Apt_streetTV = (TextView) findViewById(C0354R.id.delivery_apt_str);
        this.AddressTV = (TextView) findViewById(C0354R.id.delivery_address);
        this.progressBar = (ProgressBar) findViewById(C0354R.id.order_confrm_pbar);
        setSupportActionBar((Toolbar) findViewById(C0354R.id.toolbar_wash_and_iron));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle((CharSequence) "ORDER CONFIRMATION");
        this.pickup_date_tv_get = (TextView) findViewById(C0354R.id.Select_date);
        this.pickup_time_tv_get = (TextView) findViewById(C0354R.id.select_time);
        this.service_tv = (TextView) findViewById(C0354R.id.getTv);
        this.promocodeEt = (EditText) findViewById(C0354R.id.promocode_editText);
        this.promoCodeApplyBtn = (TextView) findViewById(C0354R.id.promocode_apply_btn);
        this.promoCodeApplyBtn.setOnClickListener(this);
        this.prefs = PreferenceManager.getDefaultSharedPreferences(this);
        this.StringServiceName = this.prefs.getString("RecyclerviewService", null);
        this.StringServiceNameId = this.prefs.getString("RecyclerviewServiceId", null);
        bundle = getIntent();
        this.StringService_TvpickUpDay = bundle.getStringExtra("pickupDate");
        this.StringService_TvpickupTime = bundle.getStringExtra("pickupTime");
        this.storeId = bundle.getStringExtra("storeId");
        this.TimeSlotId = bundle.getStringExtra("time_slot_id");
        this.cityId = bundle.getStringExtra("cityId");
        this.pickup_date_tv_get.setText(this.StringService_TvpickUpDay);
        this.pickup_time_tv_get.setText(this.StringService_TvpickupTime);
        this.service_tv.setText(this.StringServiceName);
        this.promocodeEt.setText(this.couponCodeStr);
        bundle = PreferenceManager.getDefaultSharedPreferences(this);
        this.clientId = bundle.getString("loginuserId", null);
        this.fName = bundle.getString("fName", null);
        this.lName = bundle.getString("lName", null);
        this.userMobileNumber = bundle.getString("userMobileNumber", null);
        this.lat = bundle.getString("lat", null);
        this.lng = bundle.getString("lng", null);
        this.flat_door = bundle.getString("flat_door", null);
        this.apt_str = bundle.getString("apt_str", null);
        this.address = bundle.getString("address", null);
        bundle = new StringBuilder();
        bundle.append(this.fName);
        bundle.append(" ");
        bundle.append(this.lName);
        this.FullName = bundle.toString();
        this.Full_nameTV.setText(this.FullName);
        this.Flat_doorTV.setText(this.flat_door);
        this.Apt_streetTV.setText(this.apt_str);
        this.AddressTV.setText(this.address);
        this.continueBtn = (Button) findViewById(C0354R.id.order_confirmation_continue_btn);
        this.continueBtn.setOnClickListener(this);
        this.continueBtn.setEnabled(true);
        this.continueBtn.setBackgroundColor(Color.rgb(238, 70, 75));
    }

    private void couponCode() {
        HttpsTrustManager.allowAllSSL();
        Request c06303 = new StringRequest(1, TAG_COUPON_CODE_URL, new C05601(), new C05612()) {
            protected Map<String, String> getParams() {
                Map<String, String> hashMap = new HashMap();
                hashMap.put(OrderConfirmationActivity.KEY_COUPON_CODE, OrderConfirmationActivity.this.couponCodeStr);
                hashMap.put("client_id", OrderConfirmationActivity.this.clientId);
                return hashMap;
            }
        };
        c06303.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(c06303);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void userOrderDetails(String str) {
        HttpsTrustManager.allowAllSSL();
        final String str2 = str;
        Request c06316 = new StringRequest(1, TAG_SERVICE_SCREEN_URL, new C05624(), new C05635()) {
            protected Map<String, String> getParams() {
                Map<String, String> hashMap = new HashMap();
                hashMap.put(OrderConfirmationActivity.KEY_STORE_ID, OrderConfirmationActivity.this.storeId);
                hashMap.put(OrderConfirmationActivity.KEY_CITY_ID, OrderConfirmationActivity.this.cityId);
                hashMap.put("client_id", OrderConfirmationActivity.this.clientId);
                hashMap.put("phone", OrderConfirmationActivity.this.userMobileNumber);
                hashMap.put("service", OrderConfirmationActivity.this.StringServiceName);
                hashMap.put(OrderConfirmationActivity.KEY_SERVICES_ID, OrderConfirmationActivity.this.StringServiceNameId);
                hashMap.put("p_date", OrderConfirmationActivity.this.StringService_TvpickUpDay);
                hashMap.put(OrderConfirmationActivity.KEY_PICKUP_TIME_SLOT, OrderConfirmationActivity.this.TimeSlotId);
                hashMap.put("lat", OrderConfirmationActivity.this.lat);
                hashMap.put("lng", OrderConfirmationActivity.this.lng);
                hashMap.put("flat_door", OrderConfirmationActivity.this.flat_door);
                hashMap.put("apt_str", OrderConfirmationActivity.this.apt_str);
                hashMap.put("address", OrderConfirmationActivity.this.address);
                hashMap.put(OrderConfirmationActivity.KEY_COUPON_CODE, str2);
                return hashMap;
            }
        };
        c06316.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(c06316);
        this.progressBar.setVisibility(0);
    }

    public void onClick(View view) {
        if (view == this.continueBtn) {
            this.couponCodeStr = this.promocodeEt.getText().toString();
            Builder builder = new Builder(this);
            builder.setMessage((CharSequence) " -> To pay GST 18% EXTRA\n -> To pay Pickup and Delivery charges as applicable\n -> To permit Dhobiwala to tag my clothes with a tag pin which will create a pin hole in the garment");
            builder.setTitle((CharSequence) "I agree to the following terms:");
            builder.setCancelable(true);
            builder.setPositiveButton((CharSequence) "confirm", new C03207());
            builder.create().show();
        }
        if (view == this.promoCodeApplyBtn) {
            this.couponCodeStr = this.promocodeEt.getText().toString();
            couponCode();
        }
    }
}
