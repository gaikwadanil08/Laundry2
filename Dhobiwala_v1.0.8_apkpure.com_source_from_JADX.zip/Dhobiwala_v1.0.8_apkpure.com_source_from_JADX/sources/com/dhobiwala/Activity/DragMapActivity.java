package com.dhobiwala.Activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.support.v4.os.ResultReceiver;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import com.dhobiwala.C0354R;
import com.dhobiwala.Utils.AppUtils;
import com.dhobiwala.Utils.AppUtils.LocationConstants;
import com.google.android.gms.cast.framework.media.NotificationOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnCameraChangeListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;

public class DragMapActivity extends AppCompatActivity implements OnMapReadyCallback, ConnectionCallbacks, OnConnectionFailedListener, LocationListener {
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private static final int REQUEST_CODE_AUTOCOMPLETE = 1;
    private static String TAG = "MAP LOCATION";
    private Double latitude;
    private Double longitude;
    protected String mAddressOutput;
    protected String mAreaOutput;
    public LatLng mCenterLatLong;
    protected String mCityOutput;
    Context mContext;
    private GoogleApiClient mGoogleApiClient;
    TextView mLocationAddress;
    private GoogleMap mMap;
    private AddressResultReceiver mResultReceiver;
    protected String mStateOutput;
    Toolbar mToolbar;

    /* renamed from: com.dhobiwala.Activity.DragMapActivity$1 */
    class C02941 implements OnClickListener {
        C02941() {
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            DragMapActivity.this.startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
        }
    }

    /* renamed from: com.dhobiwala.Activity.DragMapActivity$2 */
    class C02952 implements OnClickListener {
        public void onClick(DialogInterface dialogInterface, int i) {
        }

        C02952() {
        }
    }

    /* renamed from: com.dhobiwala.Activity.DragMapActivity$3 */
    class C05453 implements OnCameraChangeListener {
        C05453() {
        }

        public void onCameraChange(CameraPosition cameraPosition) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(cameraPosition);
            stringBuilder.append("");
            Log.d("Camera postion change", stringBuilder.toString());
            DragMapActivity.this.mCenterLatLong = cameraPosition.target;
            DragMapActivity.this.mMap.clear();
            try {
                cameraPosition = new Location("");
                cameraPosition.setLatitude(DragMapActivity.this.mCenterLatLong.latitude);
                cameraPosition.setLongitude(DragMapActivity.this.mCenterLatLong.longitude);
                DragMapActivity.this.startIntentService(cameraPosition);
                DragMapActivity.this.latitude = Double.valueOf(DragMapActivity.this.mCenterLatLong.latitude);
                DragMapActivity.this.longitude = Double.valueOf(DragMapActivity.this.mCenterLatLong.longitude);
            } catch (CameraPosition cameraPosition2) {
                cameraPosition2.printStackTrace();
            }
        }
    }

    class AddressResultReceiver extends ResultReceiver {
        @SuppressLint({"RestrictedApi"})
        public AddressResultReceiver(Handler handler) {
            super(handler);
        }

        protected void onReceiveResult(int i, Bundle bundle) {
            DragMapActivity.this.mAddressOutput = bundle.getString(LocationConstants.LOCATION_DATA_STREET);
            DragMapActivity.this.mAreaOutput = bundle.getString(LocationConstants.LOCATION_DATA_AREA);
            DragMapActivity.this.mCityOutput = bundle.getString(LocationConstants.LOCATION_DATA_CITY);
            DragMapActivity.this.mStateOutput = bundle.getString(LocationConstants.LOCATION_DATA_STREET);
            DragMapActivity.this.displayAddressOutput();
        }
    }

    public void onConnectionFailed(ConnectionResult connectionResult) {
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.activity_drag_map);
        this.mContext = this;
        SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(C0354R.id.drag_Map);
        this.mLocationAddress = (TextView) findViewById(C0354R.id.Address);
        this.mToolbar = (Toolbar) findViewById(C0354R.id.toolbar_drag_map);
        setSupportActionBar(this.mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(C0354R.string.app_name));
        supportMapFragment.getMapAsync(this);
        this.mResultReceiver = new AddressResultReceiver(new Handler());
        if (checkPlayServices() != null) {
            if (AppUtils.isLocationEnabled(this.mContext) == null) {
                bundle = new Builder(this.mContext);
                bundle.setMessage("Location not enabled!");
                bundle.setPositiveButton("Open location settings", new C02941());
                bundle.setNegativeButton("Cancel", new C02952());
                bundle.show();
            }
            buildGoogleApiClient();
            return;
        }
        Toast.makeText(this.mContext, "Location not supported in this device", 0).show();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(C0354R.menu.done_button_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
        } else if (itemId == C0354R.id.action_menu_done) {
            if (this.mCenterLatLong != null) {
                menuItem = new Intent();
                menuItem.putExtra("AddressOutputFromMap", this.mAddressOutput);
                menuItem.putExtra("mapLatitude", this.latitude);
                menuItem.putExtra("mapLongitude", this.longitude);
                setResult(-1, menuItem);
                finish();
            } else {
                Toast.makeText(this.mContext, "Please Wait...", 0).show();
            }
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onMapReady(GoogleMap googleMap) {
        this.mMap = googleMap;
        this.mMap.setOnCameraChangeListener(new C05453());
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") != null && ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == null) {
        }
    }

    public void onConnected(Bundle bundle) {
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == null || ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == null) {
            bundle = LocationServices.FusedLocationApi.getLastLocation(this.mGoogleApiClient);
            if (bundle != null) {
                changeMap(bundle);
                Log.d(TAG, "ON connected");
            } else {
                try {
                    LocationServices.FusedLocationApi.removeLocationUpdates(this.mGoogleApiClient, this);
                } catch (Bundle bundle2) {
                    bundle2.printStackTrace();
                }
            }
            try {
                bundle2 = new LocationRequest();
                bundle2.setInterval(NotificationOptions.SKIP_STEP_TEN_SECONDS_IN_MS);
                bundle2.setFastestInterval(5000);
                bundle2.setPriority(105);
                LocationServices.FusedLocationApi.requestLocationUpdates(this.mGoogleApiClient, bundle2, this);
            } catch (Bundle bundle22) {
                bundle22.printStackTrace();
            }
        }
    }

    public void onConnectionSuspended(int i) {
        Log.i(TAG, "Connection suspended");
        this.mGoogleApiClient.connect();
    }

    public void onLocationChanged(Location location) {
        if (location != null) {
            try {
                changeMap(location);
            } catch (Location location2) {
                location2.printStackTrace();
                return;
            }
        }
        LocationServices.FusedLocationApi.removeLocationUpdates(this.mGoogleApiClient, this);
    }

    protected synchronized void buildGoogleApiClient() {
        this.mGoogleApiClient = new GoogleApiClient.Builder(this).addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API).build();
        Log.d("Build map", "");
    }

    protected void onStart() {
        super.onStart();
        try {
            Log.d("Connect map", "ssssss");
            this.mGoogleApiClient.connect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void onStop() {
        super.onStop();
        if (this.mGoogleApiClient != null && this.mGoogleApiClient.isConnected()) {
            this.mGoogleApiClient.disconnect();
        }
    }

    private boolean checkPlayServices() {
        int isGooglePlayServicesAvailable = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (isGooglePlayServicesAvailable == 0) {
            return true;
        }
        if (GooglePlayServicesUtil.isUserRecoverableError(isGooglePlayServicesAvailable)) {
            GooglePlayServicesUtil.getErrorDialog(isGooglePlayServicesAvailable, this, 9000).show();
        }
        return false;
    }

    private void changeMap(Location location) {
        String str = TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Reaching map");
        stringBuilder.append(this.mMap);
        Log.d(str, stringBuilder.toString());
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
            if (this.mMap != null) {
                this.mMap.getUiSettings().setZoomControlsEnabled(false);
                CameraPosition build = new CameraPosition.Builder().target(new LatLng(location.getLatitude(), location.getLongitude())).zoom(15.0f).tilt(70.0f).build();
                this.mMap.getUiSettings().setMyLocationButtonEnabled(true);
                this.mMap.animateCamera(CameraUpdateFactory.newCameraPosition(build));
                this.mMap.setMyLocationEnabled(true);
                startIntentService(location);
                location = TAG;
                stringBuilder = new StringBuilder();
                stringBuilder.append("CameraPosition map");
                stringBuilder.append(build.toString());
                Log.d(location, stringBuilder.toString());
            } else {
                Toast.makeText(getApplicationContext(), "Sorry! unable to create maps", 0).show();
            }
        }
    }

    protected void displayAddressOutput() {
        try {
            if (this.mAreaOutput != null) {
                this.mLocationAddress.setText(this.mAddressOutput);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void startIntentService(Location location) {
        Intent intent = new Intent(this, FetchAddressIntentService.class);
        intent.putExtra(LocationConstants.RECEIVER, this.mResultReceiver);
        intent.putExtra(LocationConstants.LOCATION_DATA_EXTRA, location);
        startService(intent);
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1) {
            if (i2 == -1) {
                i = new CameraPosition.Builder().target(PlaceAutocomplete.getPlace(this.mContext, intent).getLatLng()).zoom(1097859072).tilt(1116471296).build();
                if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
                    this.mMap.setMyLocationEnabled(true);
                    this.mMap.animateCamera(CameraUpdateFactory.newCameraPosition(i));
                }
            }
        } else if (i2 == 2) {
            PlaceAutocomplete.getStatus(this.mContext, intent);
        }
    }
}
