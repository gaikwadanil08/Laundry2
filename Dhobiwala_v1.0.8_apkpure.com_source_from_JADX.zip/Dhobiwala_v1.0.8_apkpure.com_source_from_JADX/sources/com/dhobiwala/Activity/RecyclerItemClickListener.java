package com.dhobiwala.Activity;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.OnItemTouchListener;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;

public class RecyclerItemClickListener implements OnItemTouchListener {
    GestureDetector mGestureDetector;
    private OnItemClickListener mListener;

    /* renamed from: com.dhobiwala.Activity.RecyclerItemClickListener$1 */
    class C03211 extends SimpleOnGestureListener {
        public boolean onSingleTapUp(MotionEvent motionEvent) {
            return true;
        }

        C03211() {
        }
    }

    public interface OnItemClickListener {
        void onItemClick(View view, int i);
    }

    public void onRequestDisallowInterceptTouchEvent(boolean z) {
    }

    public void onTouchEvent(RecyclerView recyclerView, MotionEvent motionEvent) {
    }

    public RecyclerItemClickListener(Context context, OnItemClickListener onItemClickListener) {
        this.mListener = onItemClickListener;
        this.mGestureDetector = new GestureDetector(context, new C03211());
    }

    public boolean onInterceptTouchEvent(RecyclerView recyclerView, MotionEvent motionEvent) {
        View findChildViewUnder = recyclerView.findChildViewUnder(motionEvent.getX(), motionEvent.getY());
        if (findChildViewUnder == null || this.mListener == null || this.mGestureDetector.onTouchEvent(motionEvent) == null) {
            return null;
        }
        this.mListener.onItemClick(findChildViewUnder, recyclerView.getChildPosition(findChildViewUnder));
        return true;
    }
}
