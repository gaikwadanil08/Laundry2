package com.dhobiwala.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dhobiwala.C0354R;
import com.dhobiwala.ImageLoader;
import com.dhobiwala.Utils.HttpsTrustManager;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public class UserProfileActivity extends AppCompatActivity implements OnClickListener {
    public static final String KEY_ADDRESS = "address";
    public static final String KEY_APT_STR = "apt_str";
    public static final String KEY_CLINT_ID = "client_id";
    public static final String KEY_FLAT_DOOR = "flat_door";
    public static final String KEY_F_NAME = "f_name";
    public static final String KEY_LAT = "lat";
    public static final String KEY_LNG = "lng";
    public static final String KEY_L_NAME = "l_name";
    private static final String TAG_UPDATE_USER_PROFILE_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=update_address";
    private int REQUEST_CAMERA = 0;
    private int SELECT_FILE = 1;
    Bitmap bm;
    private String client_id;
    private EditText editTextProfileFirstName;
    private EditText editTextProfileLastName;
    private EditText edittextProfileApartmentName;
    private EditText edittextProfileFlatNo;
    private ImageLoader imageLoader;
    private boolean isInternetAvailable;
    private SharedPreferences prefs;
    private String profileAddressString;
    private String profileApartmentStreetString;
    private Button profileEditButton;
    private String profileEmailIDString;
    private String profileFirstNameString;
    private String profileFlatDoorString;
    private String profileFullNameString;
    private String profileImage;
    private String profileImageString;
    private String profileLastNameString;
    private String profileMobileString;
    private Button profileSaveButton;
    private Double profilelatitude;
    private Double profilelongitude;
    ProgressBar progressBar;
    private TextView textviewProfileEmail;
    private TextView textviewProfileFullName;
    private TextView textviewProfileMobileNo;
    private Toolbar toolbar;
    private String updatedAddressStr;
    private String updatedAptStreetStr;
    private String updatedFlatDoorStr;
    private String updatedFnameStr;
    private double updatedLatitude;
    private String updatedLnameStr;
    private double updatedLongitude;
    private String userChoosenTask;
    private TextView userProfileAddress;

    /* renamed from: com.dhobiwala.Activity.UserProfileActivity$1 */
    class C03311 implements OnClickListener {
        C03311() {
        }

        public void onClick(View view) {
            UserProfileActivity.this.updatedFnameStr = UserProfileActivity.this.editTextProfileFirstName.getText().toString();
            UserProfileActivity.this.updatedLnameStr = UserProfileActivity.this.editTextProfileLastName.getText().toString();
            UserProfileActivity.this.updatedFlatDoorStr = UserProfileActivity.this.edittextProfileFlatNo.getText().toString();
            UserProfileActivity.this.updatedAptStreetStr = UserProfileActivity.this.edittextProfileApartmentName.getText().toString();
            UserProfileActivity.this.updatedAddressStr = UserProfileActivity.this.userProfileAddress.getText().toString();
            if (TextUtils.isEmpty(UserProfileActivity.this.updatedFnameStr) != null) {
                Toast.makeText(UserProfileActivity.this, "Enter your First Name", 1).show();
            } else if (TextUtils.isEmpty(UserProfileActivity.this.updatedLnameStr) != null) {
                Toast.makeText(UserProfileActivity.this, "Enter your Last Name", 1).show();
            } else if (TextUtils.isEmpty(UserProfileActivity.this.updatedFlatDoorStr) != null) {
                Toast.makeText(UserProfileActivity.this, "Enter your Flat/Door No", 1).show();
            } else if (TextUtils.isEmpty(UserProfileActivity.this.updatedAptStreetStr) != null) {
                Toast.makeText(UserProfileActivity.this, "Enter your Apart/Street Name", 1).show();
            } else if (TextUtils.isEmpty(UserProfileActivity.this.updatedAddressStr) != null) {
                Toast.makeText(UserProfileActivity.this, "Enter your Address", 1).show();
            } else {
                if (UserProfileActivity.this.isInternetAvailable != null) {
                    UserProfileActivity.this.userUpdateProfile();
                }
            }
        }
    }

    /* renamed from: com.dhobiwala.Activity.UserProfileActivity$2 */
    class C03322 implements OnClickListener {
        C03322() {
        }

        public void onClick(View view) {
            UserProfileActivity.this.startActivityForResult(new Intent(UserProfileActivity.this, DragMapActivity.class), 2);
        }
    }

    /* renamed from: com.dhobiwala.Activity.UserProfileActivity$3 */
    class C05683 implements Listener<String> {
        C05683() {
        }

        public void onResponse(String str) {
            String str2 = "";
            PrintStream printStream = System.out;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Response");
            stringBuilder.append(str);
            printStream.println(stringBuilder.toString());
            UserProfileActivity.this.progressBar.setVisibility(8);
            try {
                JSONObject jSONObject = new JSONObject(str);
                str = System.out;
                stringBuilder = new StringBuilder();
                stringBuilder.append("jsonobj response");
                stringBuilder.append(jSONObject);
                str.println(stringBuilder.toString());
                str = jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
            } catch (String str3) {
                str3.printStackTrace();
                str3 = str2;
            }
            if (str3.equalsIgnoreCase("true") != null) {
                str3 = new Intent(UserProfileActivity.this, HomeScreenActivity.class);
                str3.setFlags(67108864);
                UserProfileActivity.this.startActivity(str3);
                str3 = PreferenceManager.getDefaultSharedPreferences(UserProfileActivity.this);
                str3.edit().putString("loginuserId", UserProfileActivity.this.client_id).apply();
                str3.edit().putString("fName", UserProfileActivity.this.updatedFnameStr).apply();
                str3.edit().putString("lName", UserProfileActivity.this.updatedLnameStr).apply();
                str3.edit().putString("flat_door", UserProfileActivity.this.updatedFlatDoorStr).apply();
                str3.edit().putString("apt_str", UserProfileActivity.this.updatedAptStreetStr).apply();
                str3.edit().putString("address", UserProfileActivity.this.updatedAddressStr).apply();
                str3.edit().putString("lat", String.valueOf(UserProfileActivity.this.updatedLatitude)).apply();
                str3.edit().putString("lng", String.valueOf(UserProfileActivity.this.updatedLongitude)).apply();
                return;
            }
            Toast.makeText(UserProfileActivity.this, MediaRouteProviderProtocol.SERVICE_DATA_ERROR, 1).show();
        }
    }

    /* renamed from: com.dhobiwala.Activity.UserProfileActivity$4 */
    class C05694 implements ErrorListener {
        C05694() {
        }

        public void onErrorResponse(VolleyError volleyError) {
            UserProfileActivity.this.progressBar.setVisibility(8);
        }
    }

    public void onClick(View view) {
    }

    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C0354R.layout.activity_user_profile);
        this.progressBar = (ProgressBar) findViewById(C0354R.id.user_profile_p_bar);
        this.imageLoader = new ImageLoader(this);
        this.profileSaveButton = (Button) findViewById(C0354R.id.profile_save_btn);
        this.profileSaveButton.setOnClickListener(new C03311());
        this.isInternetAvailable = NetworkConnectionCheck.isNetworkAvailable(this);
        this.toolbar = (Toolbar) findViewById(C0354R.id.user_profile_toolbar);
        setSupportActionBar(this.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle((CharSequence) "PROFILE");
        this.editTextProfileFirstName = (EditText) findViewById(C0354R.id.profile_first_name);
        this.editTextProfileLastName = (EditText) findViewById(C0354R.id.profile_last_name);
        this.textviewProfileFullName = (TextView) findViewById(C0354R.id.profile_full_name);
        this.textviewProfileEmail = (TextView) findViewById(C0354R.id.profile_email_id);
        this.textviewProfileMobileNo = (TextView) findViewById(C0354R.id.profile_mobile_no);
        this.edittextProfileFlatNo = (EditText) findViewById(C0354R.id.profile_Flat_Door_no);
        this.edittextProfileApartmentName = (EditText) findViewById(C0354R.id.profile_Apt_str_no);
        this.userProfileAddress = (TextView) findViewById(C0354R.id.user_profile_address_from_map_et);
        this.userProfileAddress.setOnClickListener(new C03322());
        this.prefs = PreferenceManager.getDefaultSharedPreferences(this);
        this.client_id = this.prefs.getString("loginuserId", null);
        bundle = getIntent().getExtras();
        this.profileFirstNameString = bundle.getString("fName");
        this.profileLastNameString = bundle.getString("lName");
        this.profileEmailIDString = bundle.getString("userEmail");
        this.profileMobileString = bundle.getString("userMobileNumber");
        this.profileFlatDoorString = bundle.getString("flat_door");
        this.profileApartmentStreetString = bundle.getString("apt_str");
        this.profileAddressString = bundle.getString("address");
        this.updatedLatitude = Double.valueOf(bundle.getString("lat")).doubleValue();
        this.updatedLongitude = Double.parseDouble(bundle.getString("lng"));
        bundle = new StringBuilder();
        bundle.append(this.profileFirstNameString);
        bundle.append(" ");
        bundle.append(this.profileLastNameString);
        this.profileFullNameString = bundle.toString();
        this.editTextProfileFirstName.setText(this.profileFirstNameString);
        this.editTextProfileLastName.setText(this.profileLastNameString);
        this.textviewProfileFullName.setText(this.profileFullNameString);
        this.textviewProfileEmail.setText(this.profileEmailIDString);
        this.textviewProfileMobileNo.setText(this.profileMobileString);
        this.edittextProfileFlatNo.setText(this.profileFlatDoorString);
        this.edittextProfileApartmentName.setText(this.profileApartmentStreetString);
        this.userProfileAddress.setText(this.profileAddressString);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void userUpdateProfile() {
        HttpsTrustManager.allowAllSSL();
        Request c06345 = new StringRequest(1, TAG_UPDATE_USER_PROFILE_URL, new C05683(), new C05694()) {
            protected Map<String, String> getParams() {
                Map<String, String> hashMap = new HashMap();
                hashMap.put("client_id", UserProfileActivity.this.client_id);
                hashMap.put("f_name", UserProfileActivity.this.updatedFnameStr);
                hashMap.put("l_name", UserProfileActivity.this.updatedLnameStr);
                hashMap.put("flat_door", UserProfileActivity.this.updatedFlatDoorStr);
                hashMap.put("apt_str", UserProfileActivity.this.updatedAptStreetStr);
                hashMap.put("address", UserProfileActivity.this.updatedAddressStr);
                hashMap.put("lat", String.valueOf(UserProfileActivity.this.updatedLatitude));
                hashMap.put("lng", String.valueOf(UserProfileActivity.this.updatedLongitude));
                return hashMap;
            }
        };
        c06345.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(this).add(c06345);
        this.progressBar.setVisibility(0);
    }

    protected void onResume() {
        super.onResume();
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 2 && i2 == -1) {
            this.updatedAddressStr = intent.getStringExtra("AddressOutputFromMap");
            this.updatedLatitude = intent.getDoubleExtra("mapLatitude", FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE);
            this.updatedLongitude = intent.getDoubleExtra("mapLongitude", FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE);
            this.userProfileAddress.setText(this.updatedAddressStr);
        }
    }
}
