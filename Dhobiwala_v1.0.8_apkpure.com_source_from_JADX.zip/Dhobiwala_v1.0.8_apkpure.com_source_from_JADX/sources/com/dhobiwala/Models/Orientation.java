package com.dhobiwala.Models;

public enum Orientation {
    VERTICAL,
    HORIZONTAL
}
