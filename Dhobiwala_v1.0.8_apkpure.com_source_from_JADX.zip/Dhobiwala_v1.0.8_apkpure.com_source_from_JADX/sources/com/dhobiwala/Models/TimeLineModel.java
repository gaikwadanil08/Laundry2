package com.dhobiwala.Models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class TimeLineModel implements Parcelable {
    public static final Creator<TimeLineModel> CREATOR = new C03531();
    private String mMessage;

    /* renamed from: com.dhobiwala.Models.TimeLineModel$1 */
    static class C03531 implements Creator<TimeLineModel> {
        C03531() {
        }

        public TimeLineModel createFromParcel(Parcel parcel) {
            return new TimeLineModel(parcel);
        }

        public TimeLineModel[] newArray(int i) {
            return new TimeLineModel[i];
        }
    }

    public int describeContents() {
        return 0;
    }

    public TimeLineModel(String str) {
        this.mMessage = str;
    }

    public String getMessage() {
        return this.mMessage;
    }

    public void semMessage(String str) {
        this.mMessage = str;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.mMessage);
    }

    protected TimeLineModel(Parcel parcel) {
        this.mMessage = parcel.readString();
    }
}
