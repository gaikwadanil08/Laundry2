package com.dhobiwala.Models;

public class ServicesData {
    boolean selected;
    String serviceid = this.serviceid;
    String serviceimgs = this.serviceimgs;
    String servicename = this.servicename;

    public boolean isSelected() {
        return this.selected;
    }

    public void setSelected(boolean z) {
        this.selected = z;
    }

    public String getServicename() {
        return this.servicename;
    }

    public void setServicename(String str) {
        this.servicename = str;
    }

    public String getServiceid() {
        return this.serviceid;
    }

    public void setServiceid(String str) {
        this.serviceid = str;
    }

    public String getServiceimgs() {
        return this.serviceimgs;
    }

    public void setServiceimgs(String str) {
        this.serviceimgs = str;
    }
}
