package com.dhobiwala.Models;

public class RatingAndReviewsData {
    String reviewsDate;
    String reviewsFeedback;
    String reviewsName;
    String reviewsRatingbar = this.reviewsRatingbar;

    public RatingAndReviewsData(String str, String str2, String str3) {
        this.reviewsName = str;
        this.reviewsDate = str2;
        this.reviewsFeedback = str3;
    }

    public String getReviewsName() {
        return this.reviewsName;
    }

    public void setReviewsName(String str) {
        this.reviewsName = str;
    }

    public String getReviewsDate() {
        return this.reviewsDate;
    }

    public void setReviewsDate(String str) {
        this.reviewsDate = str;
    }

    public String getReviewsRatingbar() {
        return this.reviewsRatingbar;
    }

    public void setReviewsRatingbar(String str) {
        this.reviewsRatingbar = str;
    }

    public String getReviewsFeedback() {
        return this.reviewsFeedback;
    }

    public void setReviewsFeedback(String str) {
        this.reviewsFeedback = str;
    }
}
