package com.dhobiwala.Models;

public class OrderDetailsData {
    String garmentnme;
    String qty;
    String servicenme;

    public String getGarmentnme() {
        return this.garmentnme;
    }

    public void setGarmentnme(String str) {
        this.garmentnme = str;
    }

    public String getQty() {
        return this.qty;
    }

    public void setQty(String str) {
        this.qty = str;
    }
}
