package com.dhobiwala.MyDataClass;

public class MyOrderData {
    String orderDate;
    String orderId;
    String orderP_date;
    String orderP_time;
    String orderService;
    String orderStatus;

    public String getOrderId() {
        return this.orderId;
    }

    public String getOrderDate() {
        return this.orderDate;
    }

    public String getOrderStatus() {
        return this.orderStatus;
    }

    public String getOrderService() {
        return this.orderService;
    }

    public String getOrderP_date() {
        return this.orderP_date;
    }

    public String getOrderP_time() {
        return this.orderP_time;
    }

    public MyOrderData(String str, String str2, String str3, String str4, String str5, String str6) {
        this.orderId = str;
        this.orderDate = str2;
        this.orderStatus = str3;
        this.orderService = str4;
        this.orderP_date = str5;
        this.orderP_time = str6;
    }
}
