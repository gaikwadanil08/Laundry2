package com.dhobiwala.MyDataClass;

public class GarmentsData {
    String garmentname;
    String garmentrate;

    public String getGarmentname() {
        return this.garmentname;
    }

    public void setGarmentname(String str) {
        this.garmentname = str;
    }

    public String getGarmentrate() {
        return this.garmentrate;
    }

    public void setGarmentrate(String str) {
        this.garmentrate = str;
    }
}
