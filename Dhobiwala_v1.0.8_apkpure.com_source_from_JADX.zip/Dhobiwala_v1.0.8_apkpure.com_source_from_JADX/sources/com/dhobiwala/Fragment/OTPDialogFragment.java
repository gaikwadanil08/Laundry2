package com.dhobiwala.Fragment;

import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dhobiwala.Activity.HomeScreenActivity;
import com.dhobiwala.Activity.MyOrderActivity;
import com.dhobiwala.C0354R;
import com.dhobiwala.Utils.HttpsTrustManager;
import com.google.android.gms.drive.DriveFile;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class OTPDialogFragment extends DialogFragment {
    public static final String EMAIL_SHARED_PREF = "user_id";
    public static final String KEY_EMAIL = "email";
    private static final String KEY_MOBILE_LOGIN = "email_mobile";
    public static final String KEY_MOBILE_NO = "mobile";
    private static final String KEY_PWD_LOGIN = "password";
    public static final String KEY_REG_OTP_VERIFICATION_ADDRESS = "address";
    public static final String KEY_REG_OTP_VERIFICATION_EMAIL = "email";
    public static final String KEY_REG_OTP_VERIFICATION_FIRST_NAME = "f_name";
    public static final String KEY_REG_OTP_VERIFICATION_FLAT = "flat_door";
    public static final String KEY_REG_OTP_VERIFICATION_LAST_NAME = "l_name";
    public static final String KEY_REG_OTP_VERIFICATION_LATITUDE = "lat";
    public static final String KEY_REG_OTP_VERIFICATION_LONGITUDE = "lng";
    public static final String KEY_REG_OTP_VERIFICATION_MOBILE = "mobile";
    public static final String KEY_REG_OTP_VERIFICATION_PASSWORD = "password";
    public static final String KEY_REG_OTP_VERIFICATION_PINCODE = "pin";
    public static final String KEY_REG_OTP_VERIFICATION_STREET = "apt_str";
    public static final String LOGGEDIN_SHARED_PREF = "loggedin";
    public static final String SHARED_PREF_NAME = "myloginapp";
    private static final String TAG_LOGIN_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=login_user";
    private static final String TAG_REG_OTP_VERIFICATION_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=register";
    private static final String TAG_RESEND_OTP_VERIFICATION_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=register_otp";
    private Double LatitudeStr;
    private Double LongitudeStr;
    private Button approve_btn;
    private Button cancel_btn;
    private EditText enteredOtpEdittext;
    private boolean loggedIn = false;
    ProgressBar progressBar;
    private BroadcastReceiver receiver = new C03485();
    private Button resend_otp_btn;
    private String userAddressFromGoogle;
    private String userFirstName;
    private String userFlatNo;
    private String userLastName;
    private String userMobileNo;
    private String userOTP;
    private String userRegEmail;
    private String userRegPassword;
    private String userStreetName;

    /* renamed from: com.dhobiwala.Fragment.OTPDialogFragment$1 */
    class C03441 implements TextWatcher {
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        C03441() {
        }

        public void afterTextChanged(Editable editable) {
            if (OTPDialogFragment.this.enteredOtpEdittext.getText().toString().trim().equalsIgnoreCase(OTPDialogFragment.this.userOTP) != null) {
                OTPDialogFragment.this.otpValidation();
            }
        }
    }

    /* renamed from: com.dhobiwala.Fragment.OTPDialogFragment$2 */
    class C03452 implements OnClickListener {
        C03452() {
        }

        public void onClick(View view) {
            if (OTPDialogFragment.this.enteredOtpEdittext.getText().toString().trim().equalsIgnoreCase(OTPDialogFragment.this.userOTP) != null) {
                OTPDialogFragment.this.otpValidation();
            } else {
                OTPDialogFragment.this.enteredOtpEdittext.setError("OTP is Invalid");
            }
        }
    }

    /* renamed from: com.dhobiwala.Fragment.OTPDialogFragment$3 */
    class C03463 implements OnClickListener {
        C03463() {
        }

        public void onClick(View view) {
            OTPDialogFragment.this.ResendOTP();
        }
    }

    /* renamed from: com.dhobiwala.Fragment.OTPDialogFragment$4 */
    class C03474 implements OnClickListener {
        C03474() {
        }

        public void onClick(View view) {
            OTPDialogFragment.this.getDialog().dismiss();
        }
    }

    /* renamed from: com.dhobiwala.Fragment.OTPDialogFragment$5 */
    class C03485 extends BroadcastReceiver {
        C03485() {
        }

        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equalsIgnoreCase("otp") != null) {
                OTPDialogFragment.this.enteredOtpEdittext.setText(intent.getStringExtra("message"));
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        bundle = getArguments();
        this.userOTP = bundle.getString("registerOtp");
        this.userFirstName = bundle.getString("userFirstName");
        this.userLastName = bundle.getString("userLastName");
        this.userRegEmail = bundle.getString("userEmail");
        this.userRegPassword = bundle.getString("userPassword");
        this.userMobileNo = bundle.getString("userMobileNo");
        this.userFlatNo = bundle.getString("userFlatNo");
        this.userStreetName = bundle.getString("userStreetName");
        this.userAddressFromGoogle = bundle.getString("userAddressFromMap");
        this.LatitudeStr = Double.valueOf(bundle.getString("latSignUp"));
        this.LongitudeStr = Double.valueOf(bundle.getString("lngSignUp"));
        bundle = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("otp_in_dialog");
        stringBuilder.append(this.userOTP);
        bundle.println(stringBuilder.toString());
    }

    @Nullable
    public View onCreateView(LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(C0354R.layout.activity_otp_verification, null);
        getDialog().getWindow().requestFeature(1);
        this.progressBar = (ProgressBar) layoutInflater.findViewById(C0354R.id.pbarOtp);
        this.enteredOtpEdittext = (EditText) layoutInflater.findViewById(C0354R.id.register_otp_edittext);
        this.approve_btn = (Button) layoutInflater.findViewById(C0354R.id.otp_approve_button);
        this.resend_otp_btn = (Button) layoutInflater.findViewById(C0354R.id.otp_resend_button);
        this.cancel_btn = (Button) layoutInflater.findViewById(C0354R.id.otp_cancel_button);
        this.enteredOtpEdittext.addTextChangedListener(new C03441());
        this.approve_btn.setOnClickListener(new C03452());
        this.resend_otp_btn.setOnClickListener(new C03463());
        this.cancel_btn.setOnClickListener(new C03474());
        return layoutInflater;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        getDialog().getWindow().getAttributes().windowAnimations = C0354R.style.DialogAnimation;
    }

    private void ResendOTP() {
        HttpsTrustManager.allowAllSSL();
        final ProgressDialog show = ProgressDialog.show(getActivity(), "Sending OTP", "Please wait...", false, false);
        Request c06368 = new StringRequest(1, "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=register_otp", new Listener<String>() {
            public void onResponse(String str) {
                show.dismiss();
                OTPDialogFragment.this.progressBar.setVisibility(8);
                Log.e("Resend_OTP:", str.toString());
                try {
                    JSONObject jSONObject = new JSONObject(str);
                    str = System.out;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("jsonobj response");
                    stringBuilder.append(jSONObject);
                    str.println(stringBuilder.toString());
                    str = jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                    OTPDialogFragment.this.userOTP = jSONObject.getString("otp");
                    PrintStream printStream = System.out;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("success_response");
                    stringBuilder.append(str);
                    printStream.println(stringBuilder.toString());
                    str = System.out;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("resend_otp");
                    stringBuilder2.append(OTPDialogFragment.this.userOTP);
                    str.println(stringBuilder2.toString());
                } catch (String str2) {
                    str2.printStackTrace();
                }
            }
        }, new ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                show.dismiss();
            }
        }) {
            protected Map<String, String> getParams() {
                Map<String, String> hashMap = new HashMap();
                hashMap.put("email", OTPDialogFragment.this.userRegEmail);
                hashMap.put("mobile", OTPDialogFragment.this.userMobileNo);
                return hashMap;
            }
        };
        c06368.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(getActivity()).add(c06368);
    }

    private void otpValidation() {
        HttpsTrustManager.allowAllSSL();
        final ProgressDialog show = ProgressDialog.show(getActivity(), "Validating", "Please wait...", false, false);
        Request anonymousClass11 = new StringRequest(1, TAG_REG_OTP_VERIFICATION_URL, new Listener<String>() {
            public void onResponse(String str) {
                show.dismiss();
                String str2 = "";
                Log.e("Registeration_Res_is:", str.toString());
                try {
                    str = new JSONObject(str).getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                } catch (String str3) {
                    str3.printStackTrace();
                    str3 = str2;
                }
                if (str3.equalsIgnoreCase("true") != null) {
                    OTPDialogFragment.this.userLogin();
                    return;
                }
                show.dismiss();
                Toast.makeText(OTPDialogFragment.this.getActivity(), "Invalid OTP, Try agian", 0).show();
            }
        }, new ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                show.dismiss();
            }
        }) {
            protected Map<String, String> getParams() {
                Map<String, String> hashMap = new HashMap();
                hashMap.put("f_name", OTPDialogFragment.this.userFirstName);
                hashMap.put("l_name", OTPDialogFragment.this.userLastName);
                hashMap.put("email", OTPDialogFragment.this.userRegEmail);
                hashMap.put("mobile", OTPDialogFragment.this.userMobileNo);
                hashMap.put("password", OTPDialogFragment.this.userRegPassword);
                hashMap.put("flat_door", OTPDialogFragment.this.userFlatNo);
                hashMap.put("apt_str", OTPDialogFragment.this.userStreetName);
                hashMap.put("address", OTPDialogFragment.this.userAddressFromGoogle);
                hashMap.put("lat", String.valueOf(OTPDialogFragment.this.LatitudeStr));
                hashMap.put("lng", String.valueOf(OTPDialogFragment.this.LongitudeStr));
                return hashMap;
            }
        };
        anonymousClass11.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(getActivity()).add(anonymousClass11);
    }

    private void userLogin() {
        HttpsTrustManager.allowAllSSL();
        Request anonymousClass14 = new StringRequest(1, TAG_LOGIN_URL, new Listener<String>() {
            public void onResponse(String str) {
                String string;
                String string2;
                JSONException e;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                Log.e("Response:", str.toString());
                String str8 = null;
                try {
                    JSONObject jSONObject = new JSONObject(str);
                    str = jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                    try {
                        string = jSONObject.getString("user_id");
                        try {
                            string2 = jSONObject.getString("f_name");
                        } catch (JSONException e2) {
                            e = e2;
                            string2 = null;
                            str2 = string2;
                            str3 = str2;
                            str4 = str3;
                            str5 = str4;
                            str6 = str5;
                            str7 = str6;
                            e.printStackTrace();
                            if (str.trim().equalsIgnoreCase("true") != null) {
                                Toast.makeText(OTPDialogFragment.this.getActivity(), "Invalid Credentials", 1).show();
                            }
                            str = OTPDialogFragment.this.getActivity().getSharedPreferences("myloginapp", 0).edit();
                            str.putBoolean("loggedin", true);
                            str.commit();
                            str = new Intent(OTPDialogFragment.this.getActivity(), HomeScreenActivity.class);
                            str.setFlags(DriveFile.MODE_READ_ONLY);
                            str.setFlags(32768);
                            str.setFlags(67108864);
                            OTPDialogFragment.this.startActivity(str);
                            Toast.makeText(OTPDialogFragment.this.getActivity(), "Login Successful", 0).show();
                            str = PreferenceManager.getDefaultSharedPreferences(OTPDialogFragment.this.getActivity());
                            str.edit().putString("loginuserId", string).apply();
                            str.edit().putString("fName", string2).apply();
                            str.edit().putString("lName", str2).apply();
                            str.edit().putString("userEmail", OTPDialogFragment.this.userRegEmail).apply();
                            str.edit().putString("userMobileNumber", str3).apply();
                            str.edit().putString("lat", str4).apply();
                            str.edit().putString("lng", str5).apply();
                            str.edit().putString("flat_door", str6).apply();
                            str.edit().putString("apt_str", str7).apply();
                            str.edit().putString("address", str8).apply();
                            return;
                        }
                    } catch (JSONException e3) {
                        e = e3;
                        string = null;
                        string2 = string;
                        str2 = string2;
                        str3 = str2;
                        str4 = str3;
                        str5 = str4;
                        str6 = str5;
                        str7 = str6;
                        e.printStackTrace();
                        if (str.trim().equalsIgnoreCase("true") != null) {
                            Toast.makeText(OTPDialogFragment.this.getActivity(), "Invalid Credentials", 1).show();
                        }
                        str = OTPDialogFragment.this.getActivity().getSharedPreferences("myloginapp", 0).edit();
                        str.putBoolean("loggedin", true);
                        str.commit();
                        str = new Intent(OTPDialogFragment.this.getActivity(), HomeScreenActivity.class);
                        str.setFlags(DriveFile.MODE_READ_ONLY);
                        str.setFlags(32768);
                        str.setFlags(67108864);
                        OTPDialogFragment.this.startActivity(str);
                        Toast.makeText(OTPDialogFragment.this.getActivity(), "Login Successful", 0).show();
                        str = PreferenceManager.getDefaultSharedPreferences(OTPDialogFragment.this.getActivity());
                        str.edit().putString("loginuserId", string).apply();
                        str.edit().putString("fName", string2).apply();
                        str.edit().putString("lName", str2).apply();
                        str.edit().putString("userEmail", OTPDialogFragment.this.userRegEmail).apply();
                        str.edit().putString("userMobileNumber", str3).apply();
                        str.edit().putString("lat", str4).apply();
                        str.edit().putString("lng", str5).apply();
                        str.edit().putString("flat_door", str6).apply();
                        str.edit().putString("apt_str", str7).apply();
                        str.edit().putString("address", str8).apply();
                        return;
                    }
                    try {
                        str2 = jSONObject.getString("l_name");
                        try {
                            str3 = jSONObject.getString("mobile");
                            try {
                                str4 = jSONObject.getString("lat");
                            } catch (JSONException e4) {
                                e = e4;
                                str4 = null;
                                str5 = str4;
                                str6 = str5;
                                str7 = str6;
                                e.printStackTrace();
                                if (str.trim().equalsIgnoreCase("true") != null) {
                                    str = OTPDialogFragment.this.getActivity().getSharedPreferences("myloginapp", 0).edit();
                                    str.putBoolean("loggedin", true);
                                    str.commit();
                                    str = new Intent(OTPDialogFragment.this.getActivity(), HomeScreenActivity.class);
                                    str.setFlags(DriveFile.MODE_READ_ONLY);
                                    str.setFlags(32768);
                                    str.setFlags(67108864);
                                    OTPDialogFragment.this.startActivity(str);
                                    Toast.makeText(OTPDialogFragment.this.getActivity(), "Login Successful", 0).show();
                                    str = PreferenceManager.getDefaultSharedPreferences(OTPDialogFragment.this.getActivity());
                                    str.edit().putString("loginuserId", string).apply();
                                    str.edit().putString("fName", string2).apply();
                                    str.edit().putString("lName", str2).apply();
                                    str.edit().putString("userEmail", OTPDialogFragment.this.userRegEmail).apply();
                                    str.edit().putString("userMobileNumber", str3).apply();
                                    str.edit().putString("lat", str4).apply();
                                    str.edit().putString("lng", str5).apply();
                                    str.edit().putString("flat_door", str6).apply();
                                    str.edit().putString("apt_str", str7).apply();
                                    str.edit().putString("address", str8).apply();
                                    return;
                                }
                                Toast.makeText(OTPDialogFragment.this.getActivity(), "Invalid Credentials", 1).show();
                            }
                        } catch (JSONException e5) {
                            e = e5;
                            str3 = null;
                            str4 = str3;
                            str5 = str4;
                            str6 = str5;
                            str7 = str6;
                            e.printStackTrace();
                            if (str.trim().equalsIgnoreCase("true") != null) {
                                Toast.makeText(OTPDialogFragment.this.getActivity(), "Invalid Credentials", 1).show();
                            }
                            str = OTPDialogFragment.this.getActivity().getSharedPreferences("myloginapp", 0).edit();
                            str.putBoolean("loggedin", true);
                            str.commit();
                            str = new Intent(OTPDialogFragment.this.getActivity(), HomeScreenActivity.class);
                            str.setFlags(DriveFile.MODE_READ_ONLY);
                            str.setFlags(32768);
                            str.setFlags(67108864);
                            OTPDialogFragment.this.startActivity(str);
                            Toast.makeText(OTPDialogFragment.this.getActivity(), "Login Successful", 0).show();
                            str = PreferenceManager.getDefaultSharedPreferences(OTPDialogFragment.this.getActivity());
                            str.edit().putString("loginuserId", string).apply();
                            str.edit().putString("fName", string2).apply();
                            str.edit().putString("lName", str2).apply();
                            str.edit().putString("userEmail", OTPDialogFragment.this.userRegEmail).apply();
                            str.edit().putString("userMobileNumber", str3).apply();
                            str.edit().putString("lat", str4).apply();
                            str.edit().putString("lng", str5).apply();
                            str.edit().putString("flat_door", str6).apply();
                            str.edit().putString("apt_str", str7).apply();
                            str.edit().putString("address", str8).apply();
                            return;
                        }
                        try {
                            str5 = jSONObject.getString("lng");
                            try {
                                str6 = jSONObject.getString("flat_door");
                                try {
                                    str7 = jSONObject.getString("apt_str");
                                } catch (JSONException e6) {
                                    e = e6;
                                    str7 = null;
                                    e.printStackTrace();
                                    if (str.trim().equalsIgnoreCase("true") != null) {
                                        str = OTPDialogFragment.this.getActivity().getSharedPreferences("myloginapp", 0).edit();
                                        str.putBoolean("loggedin", true);
                                        str.commit();
                                        str = new Intent(OTPDialogFragment.this.getActivity(), HomeScreenActivity.class);
                                        str.setFlags(DriveFile.MODE_READ_ONLY);
                                        str.setFlags(32768);
                                        str.setFlags(67108864);
                                        OTPDialogFragment.this.startActivity(str);
                                        Toast.makeText(OTPDialogFragment.this.getActivity(), "Login Successful", 0).show();
                                        str = PreferenceManager.getDefaultSharedPreferences(OTPDialogFragment.this.getActivity());
                                        str.edit().putString("loginuserId", string).apply();
                                        str.edit().putString("fName", string2).apply();
                                        str.edit().putString("lName", str2).apply();
                                        str.edit().putString("userEmail", OTPDialogFragment.this.userRegEmail).apply();
                                        str.edit().putString("userMobileNumber", str3).apply();
                                        str.edit().putString("lat", str4).apply();
                                        str.edit().putString("lng", str5).apply();
                                        str.edit().putString("flat_door", str6).apply();
                                        str.edit().putString("apt_str", str7).apply();
                                        str.edit().putString("address", str8).apply();
                                        return;
                                    }
                                    Toast.makeText(OTPDialogFragment.this.getActivity(), "Invalid Credentials", 1).show();
                                }
                            } catch (JSONException e7) {
                                e = e7;
                                str6 = null;
                                str7 = str6;
                                e.printStackTrace();
                                if (str.trim().equalsIgnoreCase("true") != null) {
                                    str = OTPDialogFragment.this.getActivity().getSharedPreferences("myloginapp", 0).edit();
                                    str.putBoolean("loggedin", true);
                                    str.commit();
                                    str = new Intent(OTPDialogFragment.this.getActivity(), HomeScreenActivity.class);
                                    str.setFlags(DriveFile.MODE_READ_ONLY);
                                    str.setFlags(32768);
                                    str.setFlags(67108864);
                                    OTPDialogFragment.this.startActivity(str);
                                    Toast.makeText(OTPDialogFragment.this.getActivity(), "Login Successful", 0).show();
                                    str = PreferenceManager.getDefaultSharedPreferences(OTPDialogFragment.this.getActivity());
                                    str.edit().putString("loginuserId", string).apply();
                                    str.edit().putString("fName", string2).apply();
                                    str.edit().putString("lName", str2).apply();
                                    str.edit().putString("userEmail", OTPDialogFragment.this.userRegEmail).apply();
                                    str.edit().putString("userMobileNumber", str3).apply();
                                    str.edit().putString("lat", str4).apply();
                                    str.edit().putString("lng", str5).apply();
                                    str.edit().putString("flat_door", str6).apply();
                                    str.edit().putString("apt_str", str7).apply();
                                    str.edit().putString("address", str8).apply();
                                    return;
                                }
                                Toast.makeText(OTPDialogFragment.this.getActivity(), "Invalid Credentials", 1).show();
                            }
                            try {
                                str8 = jSONObject.getString("address");
                            } catch (JSONException e8) {
                                e = e8;
                                e.printStackTrace();
                                if (str.trim().equalsIgnoreCase("true") != null) {
                                    str = OTPDialogFragment.this.getActivity().getSharedPreferences("myloginapp", 0).edit();
                                    str.putBoolean("loggedin", true);
                                    str.commit();
                                    str = new Intent(OTPDialogFragment.this.getActivity(), HomeScreenActivity.class);
                                    str.setFlags(DriveFile.MODE_READ_ONLY);
                                    str.setFlags(32768);
                                    str.setFlags(67108864);
                                    OTPDialogFragment.this.startActivity(str);
                                    Toast.makeText(OTPDialogFragment.this.getActivity(), "Login Successful", 0).show();
                                    str = PreferenceManager.getDefaultSharedPreferences(OTPDialogFragment.this.getActivity());
                                    str.edit().putString("loginuserId", string).apply();
                                    str.edit().putString("fName", string2).apply();
                                    str.edit().putString("lName", str2).apply();
                                    str.edit().putString("userEmail", OTPDialogFragment.this.userRegEmail).apply();
                                    str.edit().putString("userMobileNumber", str3).apply();
                                    str.edit().putString("lat", str4).apply();
                                    str.edit().putString("lng", str5).apply();
                                    str.edit().putString("flat_door", str6).apply();
                                    str.edit().putString("apt_str", str7).apply();
                                    str.edit().putString("address", str8).apply();
                                    return;
                                }
                                Toast.makeText(OTPDialogFragment.this.getActivity(), "Invalid Credentials", 1).show();
                            }
                        } catch (JSONException e9) {
                            e = e9;
                            str5 = null;
                            str6 = str5;
                            str7 = str6;
                            e.printStackTrace();
                            if (str.trim().equalsIgnoreCase("true") != null) {
                                str = OTPDialogFragment.this.getActivity().getSharedPreferences("myloginapp", 0).edit();
                                str.putBoolean("loggedin", true);
                                str.commit();
                                str = new Intent(OTPDialogFragment.this.getActivity(), HomeScreenActivity.class);
                                str.setFlags(DriveFile.MODE_READ_ONLY);
                                str.setFlags(32768);
                                str.setFlags(67108864);
                                OTPDialogFragment.this.startActivity(str);
                                Toast.makeText(OTPDialogFragment.this.getActivity(), "Login Successful", 0).show();
                                str = PreferenceManager.getDefaultSharedPreferences(OTPDialogFragment.this.getActivity());
                                str.edit().putString("loginuserId", string).apply();
                                str.edit().putString("fName", string2).apply();
                                str.edit().putString("lName", str2).apply();
                                str.edit().putString("userEmail", OTPDialogFragment.this.userRegEmail).apply();
                                str.edit().putString("userMobileNumber", str3).apply();
                                str.edit().putString("lat", str4).apply();
                                str.edit().putString("lng", str5).apply();
                                str.edit().putString("flat_door", str6).apply();
                                str.edit().putString("apt_str", str7).apply();
                                str.edit().putString("address", str8).apply();
                                return;
                            }
                            Toast.makeText(OTPDialogFragment.this.getActivity(), "Invalid Credentials", 1).show();
                        }
                    } catch (JSONException e10) {
                        e = e10;
                        str2 = null;
                        str3 = str2;
                        str4 = str3;
                        str5 = str4;
                        str6 = str5;
                        str7 = str6;
                        e.printStackTrace();
                        if (str.trim().equalsIgnoreCase("true") != null) {
                            Toast.makeText(OTPDialogFragment.this.getActivity(), "Invalid Credentials", 1).show();
                        }
                        str = OTPDialogFragment.this.getActivity().getSharedPreferences("myloginapp", 0).edit();
                        str.putBoolean("loggedin", true);
                        str.commit();
                        str = new Intent(OTPDialogFragment.this.getActivity(), HomeScreenActivity.class);
                        str.setFlags(DriveFile.MODE_READ_ONLY);
                        str.setFlags(32768);
                        str.setFlags(67108864);
                        OTPDialogFragment.this.startActivity(str);
                        Toast.makeText(OTPDialogFragment.this.getActivity(), "Login Successful", 0).show();
                        str = PreferenceManager.getDefaultSharedPreferences(OTPDialogFragment.this.getActivity());
                        str.edit().putString("loginuserId", string).apply();
                        str.edit().putString("fName", string2).apply();
                        str.edit().putString("lName", str2).apply();
                        str.edit().putString("userEmail", OTPDialogFragment.this.userRegEmail).apply();
                        str.edit().putString("userMobileNumber", str3).apply();
                        str.edit().putString("lat", str4).apply();
                        str.edit().putString("lng", str5).apply();
                        str.edit().putString("flat_door", str6).apply();
                        str.edit().putString("apt_str", str7).apply();
                        str.edit().putString("address", str8).apply();
                        return;
                    }
                } catch (JSONException e11) {
                    e = e11;
                    str = null;
                    string = str;
                    string2 = string;
                    str2 = string2;
                    str3 = str2;
                    str4 = str3;
                    str5 = str4;
                    str6 = str5;
                    str7 = str6;
                    e.printStackTrace();
                    if (str.trim().equalsIgnoreCase("true") != null) {
                        Toast.makeText(OTPDialogFragment.this.getActivity(), "Invalid Credentials", 1).show();
                    }
                    str = OTPDialogFragment.this.getActivity().getSharedPreferences("myloginapp", 0).edit();
                    str.putBoolean("loggedin", true);
                    str.commit();
                    str = new Intent(OTPDialogFragment.this.getActivity(), HomeScreenActivity.class);
                    str.setFlags(DriveFile.MODE_READ_ONLY);
                    str.setFlags(32768);
                    str.setFlags(67108864);
                    OTPDialogFragment.this.startActivity(str);
                    Toast.makeText(OTPDialogFragment.this.getActivity(), "Login Successful", 0).show();
                    str = PreferenceManager.getDefaultSharedPreferences(OTPDialogFragment.this.getActivity());
                    str.edit().putString("loginuserId", string).apply();
                    str.edit().putString("fName", string2).apply();
                    str.edit().putString("lName", str2).apply();
                    str.edit().putString("userEmail", OTPDialogFragment.this.userRegEmail).apply();
                    str.edit().putString("userMobileNumber", str3).apply();
                    str.edit().putString("lat", str4).apply();
                    str.edit().putString("lng", str5).apply();
                    str.edit().putString("flat_door", str6).apply();
                    str.edit().putString("apt_str", str7).apply();
                    str.edit().putString("address", str8).apply();
                    return;
                }
                if (str.trim().equalsIgnoreCase("true") != null) {
                    str = OTPDialogFragment.this.getActivity().getSharedPreferences("myloginapp", 0).edit();
                    str.putBoolean("loggedin", true);
                    str.commit();
                    str = new Intent(OTPDialogFragment.this.getActivity(), HomeScreenActivity.class);
                    str.setFlags(DriveFile.MODE_READ_ONLY);
                    str.setFlags(32768);
                    str.setFlags(67108864);
                    OTPDialogFragment.this.startActivity(str);
                    Toast.makeText(OTPDialogFragment.this.getActivity(), "Login Successful", 0).show();
                    str = PreferenceManager.getDefaultSharedPreferences(OTPDialogFragment.this.getActivity());
                    str.edit().putString("loginuserId", string).apply();
                    str.edit().putString("fName", string2).apply();
                    str.edit().putString("lName", str2).apply();
                    str.edit().putString("userEmail", OTPDialogFragment.this.userRegEmail).apply();
                    str.edit().putString("userMobileNumber", str3).apply();
                    str.edit().putString("lat", str4).apply();
                    str.edit().putString("lng", str5).apply();
                    str.edit().putString("flat_door", str6).apply();
                    str.edit().putString("apt_str", str7).apply();
                    str.edit().putString("address", str8).apply();
                    return;
                }
                Toast.makeText(OTPDialogFragment.this.getActivity(), "Invalid Credentials", 1).show();
            }
        }, new ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
            }
        }) {
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> hashMap = new HashMap();
                hashMap.put(OTPDialogFragment.KEY_MOBILE_LOGIN, OTPDialogFragment.this.userMobileNo);
                hashMap.put("password", OTPDialogFragment.this.userRegPassword);
                return hashMap;
            }
        };
        anonymousClass14.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(getActivity()).add(anonymousClass14);
    }

    public void onResume() {
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(this.receiver, new IntentFilter("otp"));
        this.loggedIn = getActivity().getSharedPreferences("myloginapp", 0).getBoolean("loggedin", false);
        if (this.loggedIn) {
            Intent intent = new Intent(getActivity(), HomeScreenActivity.class);
            intent.addFlags(DriveFile.MODE_READ_ONLY);
            intent.addFlags(32768);
            startActivity(intent);
        }
        super.onResume();
    }

    public void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(this.receiver);
    }
}
