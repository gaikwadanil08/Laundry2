package com.dhobiwala.Fragment;

import android.app.Fragment;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.dhobiwala.C0354R;

public class SupportFragment extends Fragment implements OnClickListener {
    private ImageView emailUs;

    /* renamed from: com.dhobiwala.Fragment.SupportFragment$1 */
    class C03521 implements OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return true;
        }

        C03521() {
        }
    }

    public void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        getActivity().setTitle("Support");
    }

    @Nullable
    public View onCreateView(LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(C0354R.layout.fragment_support, viewGroup, false);
        this.emailUs = (ImageView) layoutInflater.findViewById(C0354R.id.support_email_button);
        layoutInflater.setOnTouchListener(new C03521());
        this.emailUs.setOnClickListener(this);
        return layoutInflater;
    }

    public void onClick(View view) {
        startActivity(Intent.createChooser(new Intent("android.intent.action.SENDTO", Uri.fromParts("mailto", "hello@dhobiwala.com", null)), "Choose an Email client :"));
    }
}
