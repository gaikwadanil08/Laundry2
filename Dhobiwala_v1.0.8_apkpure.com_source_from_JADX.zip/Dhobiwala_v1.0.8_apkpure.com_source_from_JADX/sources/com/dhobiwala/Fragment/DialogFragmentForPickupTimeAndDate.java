package com.dhobiwala.Fragment;

import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dhobiwala.Activity.MyOrderActivity;
import com.dhobiwala.Activity.OrderConfirmationActivity;
import com.dhobiwala.C0354R;
import com.dhobiwala.Utils.HttpsTrustManager;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import org.json.JSONObject;

public class DialogFragmentForPickupTimeAndDate extends DialogFragment {
    public static final String KEY_LAT_HOME_SCREEN = "lat";
    public static final String KEY_LNG_HOME_SCREEN = "lng";
    public static final String KEY_PICKUP_DAY_HOME_SCREEN = "p_day";
    public static final String TAG_PICKUP_DATE_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=services_pick_date";
    public static final String TAG_PICKUP_TIME_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=services_time_slot";
    private Button Next;
    private String ServiceNameString;
    private String ServiceNameStringId;
    private String StringpickupDate;
    private String StringpickupTime;
    String cityId;
    private String cityIdStr;
    private ArrayList<String> daySlotArrayList = new ArrayList();
    private ArrayAdapter<String> day_adapter;
    private Spinner day_pickup_spinner;
    TextView holidayTv;
    private Double latitude;
    private Double longitude;
    String msg;
    private RelativeLayout network_ok_relatiive;
    private RelativeLayout network_relatiive;
    private String pickupDayStr;
    private ProgressBar progressBar;
    String slotId;
    private ArrayList<String> slotIdArrayList;
    String slotIdValueString;
    String storeId;
    private String storeIdStr;
    private String success;
    String timeSlot;
    private ArrayList<String> timeSlotArrayList;
    private ArrayAdapter<String> time_adapter;
    private Spinner time_pickup_spinner;

    /* renamed from: com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate$1 */
    class C03371 implements OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return true;
        }

        C03371() {
        }
    }

    /* renamed from: com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate$2 */
    class C03382 implements OnItemSelectedListener {
        public void onNothingSelected(AdapterView<?> adapterView) {
        }

        C03382() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            DialogFragmentForPickupTimeAndDate.this.pickupDayStr = (String) DialogFragmentForPickupTimeAndDate.this.daySlotArrayList.get(i);
            Log.e("day", DialogFragmentForPickupTimeAndDate.this.pickupDayStr);
            if (DialogFragmentForPickupTimeAndDate.this.pickupDayStr.equalsIgnoreCase("Select Day And Date") != null) {
                DialogFragmentForPickupTimeAndDate.this.time_pickup_spinner.setVisibility(4);
                return;
            }
            DialogFragmentForPickupTimeAndDate.this.time_pickup_spinner.setVisibility(null);
            DialogFragmentForPickupTimeAndDate.this.pickupTimeApi(DialogFragmentForPickupTimeAndDate.this.pickupDayStr);
        }
    }

    /* renamed from: com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate$3 */
    class C03393 implements OnClickListener {
        C03393() {
        }

        public void onClick(View view) {
            try {
                DialogFragmentForPickupTimeAndDate.this.StringpickupDate = DialogFragmentForPickupTimeAndDate.this.day_pickup_spinner.getSelectedItem().toString();
                DialogFragmentForPickupTimeAndDate.this.StringpickupTime = DialogFragmentForPickupTimeAndDate.this.time_pickup_spinner.getSelectedItem().toString();
                if (DialogFragmentForPickupTimeAndDate.this.day_pickup_spinner.getSelectedItem().toString().equalsIgnoreCase("Select Day And Date") != null) {
                    Toast.makeText(DialogFragmentForPickupTimeAndDate.this.getActivity(), "Select Day And Date", 1).show();
                } else if (DialogFragmentForPickupTimeAndDate.this.time_pickup_spinner.getSelectedItem().toString().equalsIgnoreCase("Select Time") != null) {
                    Toast.makeText(DialogFragmentForPickupTimeAndDate.this.getActivity(), "Select Time", 1).show();
                } else {
                    DialogFragmentForPickupTimeAndDate.this.dismiss();
                    view = new Intent(DialogFragmentForPickupTimeAndDate.this.getActivity(), OrderConfirmationActivity.class);
                    view.setFlags(67108864);
                    view.putExtra("RecyclerviewService", DialogFragmentForPickupTimeAndDate.this.ServiceNameString);
                    view.putExtra("RecyclerviewServiceId", DialogFragmentForPickupTimeAndDate.this.ServiceNameStringId);
                    view.putExtra("pickupDate", DialogFragmentForPickupTimeAndDate.this.StringpickupDate);
                    view.putExtra("pickupTime", DialogFragmentForPickupTimeAndDate.this.StringpickupTime);
                    view.putExtra("storeId", DialogFragmentForPickupTimeAndDate.this.storeId);
                    view.putExtra("time_slot_id", DialogFragmentForPickupTimeAndDate.this.slotIdValueString);
                    view.putExtra("cityId", DialogFragmentForPickupTimeAndDate.this.cityId);
                    DialogFragmentForPickupTimeAndDate.this.startActivity(view);
                }
            } catch (View view2) {
                view2.printStackTrace();
            }
        }
    }

    /* renamed from: com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate$5 */
    class C05705 implements Listener<String> {
        C05705() {
        }

        public void onResponse(String str) {
            PrintStream printStream = System.out;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("result");
            stringBuilder.append(str);
            printStream.println(stringBuilder.toString());
            try {
                JSONObject jSONObject = new JSONObject(str);
                Log.d("Jsonobject response", jSONObject.toString());
                Log.d("Success_msg", jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE));
                str = jSONObject.getJSONArray("pick_date_list");
                Log.d("JsonArray_response", str.toString());
                DialogFragmentForPickupTimeAndDate.this.daySlotArrayList.add("Select Day And Date");
                for (int i = 0; i < str.length(); i++) {
                    DialogFragmentForPickupTimeAndDate.this.daySlotArrayList.add(str.getJSONObject(i).getString("pick_date_key").trim());
                    Log.e("result_p_day", String.valueOf(DialogFragmentForPickupTimeAndDate.this.daySlotArrayList));
                }
                DialogFragmentForPickupTimeAndDate.this.day_pickup_spinner.setAdapter(new ArrayAdapter(DialogFragmentForPickupTimeAndDate.this.getActivity(), 17367049, DialogFragmentForPickupTimeAndDate.this.daySlotArrayList));
            } catch (String str2) {
                str2.printStackTrace();
            }
        }
    }

    /* renamed from: com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate$6 */
    class C05716 implements ErrorListener {
        public void onErrorResponse(VolleyError volleyError) {
        }

        C05716() {
        }
    }

    /* renamed from: com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate$8 */
    class C05728 implements Listener<String> {

        /* renamed from: com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate$8$2 */
        class C03432 implements OnItemSelectedListener {
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

            C03432() {
            }

            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                DialogFragmentForPickupTimeAndDate.this.slotIdValueString = (String) DialogFragmentForPickupTimeAndDate.this.slotIdArrayList.get(i);
            }
        }

        C05728() {
        }

        public void onResponse(String str) {
            PrintStream printStream = System.out;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("result");
            stringBuilder.append(str);
            printStream.println(stringBuilder.toString());
            DialogFragmentForPickupTimeAndDate.this.progressBar.setVisibility(8);
            DialogFragmentForPickupTimeAndDate.this.slotIdArrayList = new ArrayList();
            DialogFragmentForPickupTimeAndDate.this.slotIdArrayList.add("0");
            DialogFragmentForPickupTimeAndDate.this.timeSlotArrayList = new ArrayList();
            DialogFragmentForPickupTimeAndDate.this.timeSlotArrayList.add("Select Time");
            try {
                JSONObject jSONObject = new JSONObject(str);
                DialogFragmentForPickupTimeAndDate.this.success = jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE);
                DialogFragmentForPickupTimeAndDate.this.msg = jSONObject.getString("msg");
                if (!(DialogFragmentForPickupTimeAndDate.this.success.equalsIgnoreCase("false") == null || DialogFragmentForPickupTimeAndDate.this.msg.equalsIgnoreCase("Store not found") == null)) {
                    DialogFragmentForPickupTimeAndDate.this.dismiss();
                    str = new Dialog(DialogFragmentForPickupTimeAndDate.this.getActivity());
                    str.setContentView(C0354R.layout.custom_alert_dialog);
                    ((Button) str.findViewById(C0354R.id.dialogButtonOK)).setOnClickListener(new OnClickListener() {
                        public void onClick(View view) {
                            str.dismiss();
                        }
                    });
                    str.show();
                }
                DialogFragmentForPickupTimeAndDate.this.storeId = jSONObject.getString(OrderConfirmationActivity.KEY_STORE_ID);
                DialogFragmentForPickupTimeAndDate.this.cityId = jSONObject.getString(OrderConfirmationActivity.KEY_CITY_ID);
                str = jSONObject.getJSONArray("time_slot_data");
                for (int i = 0; i < str.length(); i++) {
                    JSONObject jSONObject2 = str.getJSONObject(i);
                    DialogFragmentForPickupTimeAndDate.this.slotId = jSONObject2.getString("slot_id");
                    DialogFragmentForPickupTimeAndDate.this.timeSlot = jSONObject2.getString("time_slot");
                    PrintStream printStream2 = System.out;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("Timeslot is");
                    stringBuilder2.append(DialogFragmentForPickupTimeAndDate.this.timeSlot);
                    printStream2.println(stringBuilder2.toString());
                    DialogFragmentForPickupTimeAndDate.this.slotIdArrayList.add(DialogFragmentForPickupTimeAndDate.this.slotId);
                    DialogFragmentForPickupTimeAndDate.this.timeSlotArrayList.add(DialogFragmentForPickupTimeAndDate.this.timeSlot);
                    Log.i("Timeslot arraylist", DialogFragmentForPickupTimeAndDate.this.timeSlotArrayList.toString());
                }
                Log.i("Times arraylist", DialogFragmentForPickupTimeAndDate.this.timeSlotArrayList.toString());
                DialogFragmentForPickupTimeAndDate.this.time_adapter = new ArrayAdapter(DialogFragmentForPickupTimeAndDate.this.getActivity(), C0354R.layout.support_simple_spinner_dropdown_item, DialogFragmentForPickupTimeAndDate.this.timeSlotArrayList);
                if (DialogFragmentForPickupTimeAndDate.this.timeSlotArrayList.size() == null) {
                    DialogFragmentForPickupTimeAndDate.this.time_pickup_spinner.setVisibility(4);
                    Toast.makeText(DialogFragmentForPickupTimeAndDate.this.getActivity(), "No empty time slot on selected date. Select a different date", 1).show();
                }
                DialogFragmentForPickupTimeAndDate.this.time_pickup_spinner.setAdapter(DialogFragmentForPickupTimeAndDate.this.time_adapter);
                DialogFragmentForPickupTimeAndDate.this.time_pickup_spinner.setOnItemSelectedListener(new C03432());
            } catch (String str2) {
                str2.printStackTrace();
            }
        }
    }

    /* renamed from: com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate$9 */
    class C05739 implements ErrorListener {
        C05739() {
        }

        public void onErrorResponse(VolleyError volleyError) {
            DialogFragmentForPickupTimeAndDate.this.progressBar.setVisibility(8);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(C0354R.layout.activity_time_and_date_pickup_dialog_frag, null);
        getDialog().getWindow().requestFeature(1);
        layoutInflater.setOnTouchListener(new C03371());
        this.progressBar = (ProgressBar) layoutInflater.findViewById(C0354R.id.dialog_time_date_p_bar);
        this.network_relatiive = (RelativeLayout) layoutInflater.findViewById(C0354R.id.network_error_relative_layout);
        this.network_ok_relatiive = (RelativeLayout) layoutInflater.findViewById(C0354R.id.network_ok_layout);
        bundle = getArguments();
        this.ServiceNameString = bundle.getString("RecyclerviewService");
        this.ServiceNameStringId = bundle.getString("RecyclerviewServiceId");
        bundle = PreferenceManager.getDefaultSharedPreferences(getActivity());
        this.latitude = Double.valueOf(bundle.getString("lat", null));
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("lat_homescreen");
        stringBuilder.append(this.latitude.toString());
        printStream.print(stringBuilder.toString());
        this.longitude = Double.valueOf(bundle.getString("lng", null));
        viewGroup = System.out;
        bundle = new StringBuilder();
        bundle.append("lon_homescreen");
        bundle.append(this.longitude.toString());
        viewGroup.print(bundle.toString());
        this.day_pickup_spinner = (Spinner) layoutInflater.findViewById(C0354R.id.select_pickup_day_spinner);
        this.time_pickup_spinner = (Spinner) layoutInflater.findViewById(C0354R.id.select_pickup_time_spinner);
        pickUpDate();
        this.day_pickup_spinner.setOnItemSelectedListener(new C03382());
        this.Next = (Button) layoutInflater.findViewById(C0354R.id.next_btn_time_date_spinner);
        this.Next.setOnClickListener(new C03393());
        return layoutInflater;
    }

    public void onStart() {
        super.onStart();
        final Handler handler = new Handler();
        new Timer().schedule(new TimerTask() {

            /* renamed from: com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate$4$1 */
            class C03401 implements Runnable {
                C03401() {
                }

                public void run() {
                    /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
                    /*
                    r2 = this;
                    r0 = com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate.C03414.this;	 Catch:{ Exception -> 0x000f }
                    r0 = com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate.this;	 Catch:{ Exception -> 0x000f }
                    r1 = com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate.C03414.this;	 Catch:{ Exception -> 0x000f }
                    r1 = com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate.this;	 Catch:{ Exception -> 0x000f }
                    r1 = r1.getActivity();	 Catch:{ Exception -> 0x000f }
                    r0.isOnline(r1);	 Catch:{ Exception -> 0x000f }
                L_0x000f:
                    return;
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.dhobiwala.Fragment.DialogFragmentForPickupTimeAndDate.4.1.run():void");
                }
            }

            public void run() {
                handler.post(new C03401());
            }
        }, 0, 1000);
    }

    public boolean isOnline(Context context) {
        context = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("NET INFO==");
        stringBuilder.append(context);
        printStream.println(stringBuilder.toString());
        if (context != null) {
            this.network_relatiive.setVisibility(4);
            this.network_ok_relatiive.setVisibility(0);
        } else {
            this.network_relatiive.setVisibility(0);
            this.network_ok_relatiive.setVisibility(4);
        }
        if (context == null || context.isConnectedOrConnecting() == null) {
            return false;
        }
        return true;
    }

    private void pickUpDate() {
        HttpsTrustManager.allowAllSSL();
        Request c06357 = new StringRequest(1, "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=services_pick_date", new C05705(), new C05716()) {
            protected Map<String, String> getParams() throws AuthFailureError {
                return new HashMap();
            }
        };
        c06357.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(getActivity()).add(c06357);
    }

    private void pickupTimeApi(String str) {
        HttpsTrustManager.allowAllSSL();
        Log.e("pickupday", str);
        final String str2 = str;
        Request anonymousClass10 = new StringRequest(1, "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=services_time_slot", new C05728(), new C05739()) {
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> hashMap = new HashMap();
                hashMap.put("lat", String.valueOf(DialogFragmentForPickupTimeAndDate.this.latitude));
                hashMap.put("lng", String.valueOf(DialogFragmentForPickupTimeAndDate.this.longitude));
                hashMap.put("p_day", str2);
                return hashMap;
            }
        };
        anonymousClass10.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(getActivity()).add(anonymousClass10);
        this.progressBar.setVisibility(0);
    }
}
