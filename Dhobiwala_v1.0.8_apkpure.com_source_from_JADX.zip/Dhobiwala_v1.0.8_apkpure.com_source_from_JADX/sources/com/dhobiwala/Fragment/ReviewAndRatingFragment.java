package com.dhobiwala.Fragment;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.LayoutManager;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.Button;
import com.dhobiwala.Adapter.ReviewsRatingAdapter;
import com.dhobiwala.C0354R;
import com.dhobiwala.Models.RatingAndReviewsData;
import java.util.ArrayList;

public class ReviewAndRatingFragment extends Fragment {
    private ReviewsRatingAdapter adapter;
    private Button allReviewsBtn;
    ArrayList<RatingAndReviewsData> data = new ArrayList();
    private LayoutManager mLinearLayoutManager;
    private RecyclerView ratingRecyclerview;

    /* renamed from: com.dhobiwala.Fragment.ReviewAndRatingFragment$1 */
    class C03501 implements OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return true;
        }

        C03501() {
        }
    }

    /* renamed from: com.dhobiwala.Fragment.ReviewAndRatingFragment$2 */
    class C03512 implements OnClickListener {
        public void onClick(View view) {
        }

        C03512() {
        }
    }

    public void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        getActivity().setTitle("Reviews And Rating");
    }

    @Nullable
    public View onCreateView(LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(C0354R.layout.fragment_reviews_and_rating, viewGroup, false);
        layoutInflater.setOnTouchListener(new C03501());
        this.ratingRecyclerview = (RecyclerView) layoutInflater.findViewById(C0354R.id.reviews_recyclerview);
        this.mLinearLayoutManager = new LinearLayoutManager(getActivity());
        this.ratingRecyclerview.setLayoutManager(this.mLinearLayoutManager);
        this.ratingRecyclerview.setHasFixedSize(true);
        this.allReviewsBtn = (Button) layoutInflater.findViewById(C0354R.id.reviews_btn);
        this.allReviewsBtn.setOnClickListener(new C03512());
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytiuerythufdhgiughiughffuguhguihgffhgfhfgfggfyygfyfggfgfgdfvjdjvdfvd"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytiuerytjhjhffhffjfhfhjgfhefgehfghefghfgdjhgfjffjgfj"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytiuerfdjhfkdhfufhhfhfndfjhgrghrghrehhruhfhuuhuuuhgrrreuhuhergrehfhvdhviudfhueihuhreuihrhkdjhrughreidfuvhdfihyt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytvffvfdgdffsdfdfdvddvdfvgergdiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueyffgrgtrgfvdfgtrtiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnufvfdvfdrgecnueytiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnuefgreeffdfhuhgeigriehytiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueyghfgjehfergknkdauggkjreuigudsvhguerhgdnregrurhguvxhudndvudhregneritiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytiueryt"));
        this.data.add(new RatingAndReviewsData("pratibha jha", " 27-sep-2017", "dgcdgvuvhueifyixeynfnuecnueytiueryt"));
        this.adapter = new ReviewsRatingAdapter(this.data, getActivity());
        this.ratingRecyclerview.setAdapter(this.adapter);
        return layoutInflater;
    }
}
