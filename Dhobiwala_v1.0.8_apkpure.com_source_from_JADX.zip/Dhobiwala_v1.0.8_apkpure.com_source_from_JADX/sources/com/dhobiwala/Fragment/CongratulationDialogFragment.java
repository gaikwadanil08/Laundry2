package com.dhobiwala.Fragment;

import android.app.DialogFragment;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import com.dhobiwala.Activity.HomeScreenActivity;
import com.dhobiwala.C0354R;

public class CongratulationDialogFragment extends DialogFragment {
    private Button confirmFinishBtn;
    Toolbar toolbar;
    TextView tv_congo;

    /* renamed from: com.dhobiwala.Fragment.CongratulationDialogFragment$1 */
    class C03361 implements OnClickListener {
        C03361() {
        }

        public void onClick(View view) {
            view = new Intent(CongratulationDialogFragment.this.getActivity(), HomeScreenActivity.class);
            view.setFlags(67108864);
            CongratulationDialogFragment.this.startActivity(view);
            CongratulationDialogFragment.this.getActivity().finish();
        }
    }

    @Nullable
    public View onCreateView(LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(C0354R.layout.dialog_congratulation, viewGroup, false);
        viewGroup = getArguments().getString("orderId");
        bundle = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("fName", null);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Dear ");
        stringBuilder.append(bundle);
        stringBuilder.append(",Your Order with Order Number ");
        stringBuilder.append(viewGroup);
        stringBuilder.append(" has been successfully placed");
        viewGroup = stringBuilder.toString();
        this.confirmFinishBtn = (Button) layoutInflater.findViewById(C0354R.id.confirm_finish_button);
        this.confirmFinishBtn.setOnClickListener(new C03361());
        this.tv_congo = (TextView) layoutInflater.findViewById(C0354R.id.congo_tv);
        this.tv_congo.setText(viewGroup);
        return layoutInflater;
    }
}
