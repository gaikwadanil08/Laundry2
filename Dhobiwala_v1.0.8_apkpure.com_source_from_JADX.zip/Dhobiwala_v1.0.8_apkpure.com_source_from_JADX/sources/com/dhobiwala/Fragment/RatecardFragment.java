package com.dhobiwala.Fragment;

import android.app.Fragment;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.LayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dhobiwala.Activity.MyOrderActivity;
import com.dhobiwala.Activity.OrderConfirmationActivity;
import com.dhobiwala.Adapter.RateCardAdapter;
import com.dhobiwala.C0354R;
import com.dhobiwala.MyDataClass.GarmentsData;
import com.dhobiwala.Utils.HttpsTrustManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

public class RatecardFragment extends Fragment {
    private static final String TAG_GARMENT_RATE_LIST_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=rate_list";
    private static final String TAG_SERVICE_LIST_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=service_list";
    private String SelectGarment;
    List<GarmentsData> garmentsListdata = new ArrayList();
    private LinearLayout gstLinearlayout;
    private String latstr;
    private String lngstr;
    private ProgressBar pbar;
    private RateCardAdapter rateCardadapter;
    private CardView ratecardCardview;
    private RecyclerView ratecardrv;
    LayoutManager recylerViewLayoutManager;
    private RelativeLayout relative;
    String servceId;
    ArrayList<String> servicesidal = new ArrayList();
    ArrayList<String> servicesnmeal = new ArrayList();
    Spinner spinner;
    private View view;

    /* renamed from: com.dhobiwala.Fragment.RatecardFragment$1 */
    class C03491 implements OnItemSelectedListener {
        public void onNothingSelected(AdapterView<?> adapterView) {
        }

        C03491() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            RatecardFragment.this.servceId = (String) RatecardFragment.this.servicesidal.get(i);
            adapterView = System.out;
            view = new StringBuilder();
            view.append("garmentid");
            view.append(RatecardFragment.this.servceId);
            adapterView.println(view.toString());
            RatecardFragment.this.garmentsListdata.clear();
            if (RatecardFragment.this.servceId.equalsIgnoreCase("0") != null) {
                RatecardFragment.this.ratecardrv.setVisibility(4);
                RatecardFragment.this.ratecardCardview.setVisibility(4);
                RatecardFragment.this.relative.setVisibility(4);
                RatecardFragment.this.gstLinearlayout.setVisibility(4);
                return;
            }
            RatecardFragment.this.ratecardrv.setVisibility(0);
            RatecardFragment.this.ratecardCardview.setVisibility(0);
            RatecardFragment.this.pbar.setVisibility(0);
            RatecardFragment.this.showGarmentDetails();
        }
    }

    /* renamed from: com.dhobiwala.Fragment.RatecardFragment$2 */
    class C05772 implements Listener<String> {
        C05772() {
        }

        public void onResponse(String str) {
            Log.e("Services response", str.toString());
            RatecardFragment.this.pbar.setVisibility(4);
            try {
                JSONObject jSONObject = new JSONObject(str);
                Log.d("Jsonobject response", jSONObject.toString());
                Log.d("Success msg", jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE));
                str = jSONObject.getJSONArray("service_list");
                Log.d("JsonArray response", str.toString());
                RatecardFragment.this.servicesidal.add("0");
                RatecardFragment.this.servicesnmeal.add("Select Services");
                for (int i = 0; i < str.length(); i++) {
                    JSONObject jSONObject2 = str.getJSONObject(i);
                    RatecardFragment.this.servicesidal.add(jSONObject2.getString(OrderConfirmationActivity.KEY_SERVICES_ID).trim());
                    RatecardFragment.this.servicesnmeal.add(jSONObject2.getString("service_name").trim());
                }
                RatecardFragment.this.spinner.setAdapter(new ArrayAdapter(RatecardFragment.this.getActivity(), 17367049, RatecardFragment.this.servicesnmeal));
            } catch (String str2) {
                str2.printStackTrace();
            }
        }
    }

    /* renamed from: com.dhobiwala.Fragment.RatecardFragment$3 */
    class C05783 implements ErrorListener {
        C05783() {
        }

        public void onErrorResponse(VolleyError volleyError) {
            RatecardFragment.this.pbar.setVisibility(4);
        }
    }

    /* renamed from: com.dhobiwala.Fragment.RatecardFragment$5 */
    class C05795 implements Listener<String> {
        C05795() {
        }

        public void onResponse(String str) {
            Log.e("Garments response", str.toString());
            RatecardFragment.this.pbar.setVisibility(4);
            try {
                JSONObject jSONObject = new JSONObject(str);
                Log.d("Jsonobject response", jSONObject.toString());
                Log.d("Success msg", jSONObject.getString(MyOrderActivity.KEY_MY_ORDERS_SUCCESS_MESSAGE));
                str = jSONObject.getJSONArray("rate_list");
                Log.d("JsonArray response", str.toString());
                for (int i = 0; i < str.length(); i++) {
                    GarmentsData garmentsData = new GarmentsData();
                    JSONObject jSONObject2 = str.getJSONObject(i);
                    garmentsData.setGarmentname(jSONObject2.getString("garment_name").trim());
                    garmentsData.setGarmentrate(jSONObject2.getString("garment_rate").trim());
                    RatecardFragment.this.garmentsListdata.add(garmentsData);
                }
                RatecardFragment.this.rateCardadapter = new RateCardAdapter(RatecardFragment.this.garmentsListdata);
                RatecardFragment.this.ratecardrv.setAdapter(RatecardFragment.this.rateCardadapter);
                RatecardFragment.this.relative.setVisibility(0);
                RatecardFragment.this.gstLinearlayout.setVisibility(0);
            } catch (String str2) {
                str2.printStackTrace();
            }
        }
    }

    /* renamed from: com.dhobiwala.Fragment.RatecardFragment$6 */
    class C05806 implements ErrorListener {
        C05806() {
        }

        public void onErrorResponse(VolleyError volleyError) {
            RatecardFragment.this.pbar.setVisibility(4);
        }
    }

    public void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        getActivity().setTitle("Rate Card");
    }

    @Nullable
    public View onCreateView(LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, Bundle bundle) {
        this.view = layoutInflater.inflate(C0354R.layout.fragment_ratecard, viewGroup, false);
        setViews();
        this.ratecardCardview.setVisibility(4);
        setListeners();
        return this.view;
    }

    private void setViews() {
        this.spinner = (Spinner) this.view.findViewById(C0354R.id.spinner);
        this.ratecardrv = (RecyclerView) this.view.findViewById(C0354R.id.ratecard_rv);
        this.ratecardCardview = (CardView) this.view.findViewById(C0354R.id.cardview_ratecard);
        this.recylerViewLayoutManager = new LinearLayoutManager(getActivity(), 1, false);
        this.ratecardrv.setLayoutManager(this.recylerViewLayoutManager);
        this.ratecardrv.setHasFixedSize(true);
        this.relative = (RelativeLayout) this.view.findViewById(C0354R.id.relative);
        this.gstLinearlayout = (LinearLayout) this.view.findViewById(C0354R.id.gst_tv_linear);
        this.relative.setVisibility(4);
        this.gstLinearlayout.setVisibility(4);
        this.pbar = (ProgressBar) this.view.findViewById(C0354R.id.ratecard_pbar);
        this.pbar.setVisibility(4);
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        this.latstr = defaultSharedPreferences.getString("lat", null);
        this.lngstr = defaultSharedPreferences.getString("lng", null);
        servicesdetails();
    }

    private void setListeners() {
        this.spinner.setOnItemSelectedListener(new C03491());
    }

    private void servicesdetails() {
        HttpsTrustManager.allowAllSSL();
        Request c06374 = new StringRequest(1, "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=service_list", new C05772(), new C05783()) {
            protected Map<String, String> getParams() {
                return new HashMap();
            }
        };
        c06374.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(getActivity()).add(c06374);
        this.pbar.setVisibility(0);
    }

    private void showGarmentDetails() {
        HttpsTrustManager.allowAllSSL();
        Request c06387 = new StringRequest(1, TAG_GARMENT_RATE_LIST_URL, new C05795(), new C05806()) {
            protected Map<String, String> getParams() {
                Map<String, String> hashMap = new HashMap();
                hashMap.put(OrderConfirmationActivity.KEY_SERVICES_ID, RatecardFragment.this.servceId);
                hashMap.put("lat", RatecardFragment.this.latstr);
                hashMap.put("lng", RatecardFragment.this.lngstr);
                return hashMap;
            }
        };
        c06387.setRetryPolicy(new DefaultRetryPolicy(60000, 0, 1.0f));
        Volley.newRequestQueue(getActivity()).add(c06387);
    }
}
