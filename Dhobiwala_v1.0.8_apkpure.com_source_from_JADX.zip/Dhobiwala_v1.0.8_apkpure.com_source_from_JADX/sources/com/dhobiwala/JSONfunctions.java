package com.dhobiwala;

import android.util.Log;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

public class JSONfunctions {
    public static JSONObject getJSONfromURL(String str) {
        String str2 = "";
        try {
            str = new DefaultHttpClient().execute(new HttpPost(str)).getEntity().getContent();
        } catch (String str3) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error in http connection ");
            stringBuilder.append(str3.toString());
            Log.e("log_tag", stringBuilder.toString());
            str3 = null;
        }
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(str3, "iso-8859-1"), 8);
            stringBuilder = new StringBuilder();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(readLine);
                stringBuilder2.append("\n");
                stringBuilder.append(stringBuilder2.toString());
            }
            str3.close();
            str3 = stringBuilder.toString();
        } catch (String str32) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Error converting result ");
            stringBuilder.append(str32.toString());
            Log.e("log_tag", stringBuilder.toString());
            str32 = str2;
        }
        try {
            return new JSONObject(str32);
        } catch (String str322) {
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("Error parsing data ");
            stringBuilder3.append(str322.toString());
            Log.e("log_tag", stringBuilder3.toString());
            return null;
        }
    }
}
