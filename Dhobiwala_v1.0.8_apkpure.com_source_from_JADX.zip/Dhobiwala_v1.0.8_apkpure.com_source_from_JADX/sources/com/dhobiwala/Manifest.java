package com.dhobiwala;

public final class Manifest {

    public static final class permission {
        public static final String C2D_MESSAGE = "com.dhobiwala.permission.C2D_MESSAGE";
        public static final String MAPS_RECEIVE = "com.javapapers.currentlocationinmap.permission.MAPS_RECEIVE";
    }
}
