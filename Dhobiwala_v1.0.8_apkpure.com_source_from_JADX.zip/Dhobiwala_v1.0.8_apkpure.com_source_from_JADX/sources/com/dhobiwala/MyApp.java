package com.dhobiwala;

import android.app.Application;

public class MyApp extends Application {
    public void onCreate() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
        /*
        r6 = this;
        super.onCreate();
        r0 = r6.getPackageManager();	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r1 = "com.example.Pooja.dhobiwala";	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r2 = 64;	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r0 = r0.getPackageInfo(r1, r2);	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r0 = r0.signatures;	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r1 = r0.length;	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r2 = 0;	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r3 = r2;	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
    L_0x0014:
        if (r3 >= r1) goto L_0x003a;	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
    L_0x0016:
        r4 = r0[r3];	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r5 = "SHA";	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r5 = java.security.MessageDigest.getInstance(r5);	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r4 = r4.toByteArray();	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r5.update(r4);	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r4 = new java.lang.String;	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r5 = r5.digest();	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r5 = android.util.Base64.encode(r5, r2);	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r4.<init>(r5);	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r5 = "hash key";	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        android.util.Log.e(r5, r4);	 Catch:{ NameNotFoundException -> 0x003a, NameNotFoundException -> 0x003a }
        r3 = r3 + 1;
        goto L_0x0014;
    L_0x003a:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.dhobiwala.MyApp.onCreate():void");
    }
}
