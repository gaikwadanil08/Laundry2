package com.dhobiwala;

public class CommonURLs {
    public static final String ROOT_URL = "https://www.dhobiwala.com/dw_api/api_v1.0/index.php?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=";
    public static final String ROOT_URL_V1 = "https://www.dhobiwala.com/dw_api/api_v1.1/?key=FkeH4uksORdcVTvEAGK5uKzKkoisuDvD&action=";
}
