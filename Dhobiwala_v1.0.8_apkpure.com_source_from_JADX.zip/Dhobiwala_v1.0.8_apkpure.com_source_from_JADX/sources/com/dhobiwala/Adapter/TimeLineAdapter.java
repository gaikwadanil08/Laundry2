package com.dhobiwala.Adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.dhobiwala.Activity.TimeLineActivity;
import com.dhobiwala.C0354R;
import com.dhobiwala.Models.Orientation;
import com.dhobiwala.Utils.VectorDrawableUtils;
import com.github.vipulasri.timelineview.TimelineView;
import java.util.ArrayList;
import java.util.HashMap;

public class TimeLineAdapter extends Adapter<TimeLineViewHolder> {
    private Context mContext;
    private LayoutInflater mLayoutInflater;
    private ArrayList<HashMap<String, String>> mOrderTrackingStatusList;
    private Orientation mOrientation;
    private boolean mWithLinePadding;
    private HashMap<String, String> orderStatusMapResult = new HashMap();

    public class TimeLineViewHolder extends ViewHolder {
        private TextView mDate;
        private TextView mMessage;
        private TimelineView mTimeLineView;

        public TimeLineViewHolder(View view) {
            super(view);
            this.mMessage = (TextView) view.findViewById(C0354R.id.text_timeline_title);
            this.mDate = (TextView) view.findViewById(C0354R.id.text_timeline_date);
            this.mTimeLineView = (TimelineView) view.findViewById(C0354R.id.time_marker);
        }
    }

    public TimeLineAdapter(ArrayList<HashMap<String, String>> arrayList, Orientation orientation, boolean z) {
        this.mOrderTrackingStatusList = arrayList;
        this.mOrientation = orientation;
        this.mWithLinePadding = z;
    }

    public int getItemViewType(int i) {
        return TimelineView.getTimeLineViewType(i, getItemCount());
    }

    public TimeLineViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        this.mContext = viewGroup.getContext();
        this.mLayoutInflater = LayoutInflater.from(this.mContext);
        return new TimeLineViewHolder(this.mLayoutInflater.inflate(C0354R.layout.item_timeline_line_padding, viewGroup, false));
    }

    public void onBindViewHolder(TimeLineViewHolder timeLineViewHolder, int i) {
        this.orderStatusMapResult = (HashMap) this.mOrderTrackingStatusList.get(i);
        if ("true".equalsIgnoreCase((String) this.orderStatusMapResult.get("status")) != 0) {
            timeLineViewHolder.mTimeLineView.setMarker(ContextCompat.getDrawable(this.mContext, C0354R.drawable.ic_marker), ContextCompat.getColor(this.mContext, C0354R.color.color_status_color));
        } else if ("false".equalsIgnoreCase((String) this.orderStatusMapResult.get("status")) != 0) {
            timeLineViewHolder.mTimeLineView.setMarker(ContextCompat.getDrawable(this.mContext, C0354R.drawable.ic_marker), ContextCompat.getColor(this.mContext, C0354R.color.colorPrimary));
        } else {
            timeLineViewHolder.mTimeLineView.setMarker(VectorDrawableUtils.getDrawable(this.mContext, C0354R.drawable.ic_marker_inactive, 17170432));
        }
        timeLineViewHolder.mDate.setText((CharSequence) this.orderStatusMapResult.get(TimeLineActivity.KEY_ORDER_TRACKING_DATE_TIME));
        timeLineViewHolder.mMessage.setText((CharSequence) this.orderStatusMapResult.get("description"));
    }

    public int getItemCount() {
        return this.mOrderTrackingStatusList.size();
    }
}
