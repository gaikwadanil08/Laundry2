package com.dhobiwala.Adapter;

import android.support.v7.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.dhobiwala.C0354R;
import com.dhobiwala.Models.OrderDetailsData;
import java.util.List;

public class OrderDetailsAdapter extends Adapter<ViewHolder> {
    private int lastPosition = -1;
    private List<OrderDetailsData> mOrderDetailsdata;
    private OrderDetailsData oData;

    public class ViewHolder extends android.support.v7.widget.RecyclerView.ViewHolder {
        TextView garmentsName;
        TextView garmentsQty;
        TextView servicesnme;

        public ViewHolder(View view) {
            super(view);
            this.garmentsName = (TextView) view.findViewById(C0354R.id.garments_name);
            this.garmentsQty = (TextView) view.findViewById(C0354R.id.garments_qty);
        }
    }

    public OrderDetailsAdapter(List<OrderDetailsData> list) {
        this.mOrderDetailsdata = list;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(C0354R.layout.garment_details_row, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        this.oData = (OrderDetailsData) this.mOrderDetailsdata.get(i);
        viewHolder.garmentsName.setText(this.oData.getGarmentnme());
        viewHolder.garmentsQty.setText(this.oData.getQty());
    }

    public int getItemCount() {
        return this.mOrderDetailsdata.size();
    }
}
