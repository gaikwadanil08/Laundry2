package com.dhobiwala.Adapter;

import android.support.v7.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.dhobiwala.C0354R;
import com.dhobiwala.MyDataClass.GarmentsData;
import java.util.List;

public class RateCardAdapter extends Adapter<ViewHolder> {
    private List<GarmentsData> mGarmentsdata;
    private GarmentsData oData;

    public class ViewHolder extends android.support.v7.widget.RecyclerView.ViewHolder {
        TextView garmentnmetv;
        TextView garmentratetv;

        public ViewHolder(View view) {
            super(view);
            this.garmentnmetv = (TextView) view.findViewById(C0354R.id.garmentnme);
            this.garmentratetv = (TextView) view.findViewById(C0354R.id.garmentrate);
        }
    }

    public RateCardAdapter(List<GarmentsData> list) {
        this.mGarmentsdata = list;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(C0354R.layout.rate_card_adpater_row, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        this.oData = (GarmentsData) this.mGarmentsdata.get(i);
        viewHolder.garmentnmetv.setText(this.oData.getGarmentname());
        viewHolder.garmentratetv.setText(this.oData.getGarmentrate());
    }

    public int getItemCount() {
        return this.mGarmentsdata.size();
    }
}
