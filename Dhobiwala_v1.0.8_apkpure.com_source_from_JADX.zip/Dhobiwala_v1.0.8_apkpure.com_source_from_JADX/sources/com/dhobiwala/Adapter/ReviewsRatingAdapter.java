package com.dhobiwala.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import com.dhobiwala.C0354R;
import com.dhobiwala.Models.RatingAndReviewsData;
import java.util.ArrayList;

public class ReviewsRatingAdapter extends Adapter<ViewHolder> {
    private Context context;
    private ArrayList<RatingAndReviewsData> data;
    private RatingAndReviewsData oData;

    public class ViewHolder extends android.support.v7.widget.RecyclerView.ViewHolder {
        public TextView reviewsDate;
        public TextView reviewsFeedback;
        public TextView reviewsName;
        public RatingBar reviewsRating;

        public ViewHolder(View view) {
            super(view);
            this.reviewsName = (TextView) view.findViewById(C0354R.id.reviews_name_tv);
            this.reviewsDate = (TextView) view.findViewById(C0354R.id.reviews_date);
            this.reviewsRating = (RatingBar) view.findViewById(C0354R.id.whole_ratingbar);
            this.reviewsFeedback = (TextView) view.findViewById(C0354R.id.reviews_feedback);
        }
    }

    public ReviewsRatingAdapter(ArrayList<RatingAndReviewsData> arrayList, Context context) {
        this.data = arrayList;
        this.context = context;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(C0354R.layout.reviews_row_items, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        this.oData = (RatingAndReviewsData) this.data.get(i);
        viewHolder.reviewsName.setText(this.oData.getReviewsName());
        viewHolder.reviewsDate.setText(this.oData.getReviewsDate());
        viewHolder.reviewsFeedback.setText(this.oData.getReviewsFeedback());
    }

    public int getItemCount() {
        return this.data.size();
    }
}
