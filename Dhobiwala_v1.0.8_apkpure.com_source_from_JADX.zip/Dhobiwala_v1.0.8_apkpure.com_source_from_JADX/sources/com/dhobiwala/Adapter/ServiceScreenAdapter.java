package com.dhobiwala.Adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView.Adapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.dhobiwala.C0354R;
import com.dhobiwala.Models.ServicesData;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class ServiceScreenAdapter extends Adapter<ViewHolder> {
    private String ServiceTextviewName = "";
    private String ServiceTextviewNameId = "";
    private Context context;
    private Editor mEditor;
    private SharedPreferences mPref;
    private ArrayList<ServicesData> mServicedata;

    public class ViewHolder extends android.support.v7.widget.RecyclerView.ViewHolder {
        public CardView list_row;
        public TextView serviceName;
        public ImageView serviceimgIcon;

        public ViewHolder(View view) {
            super(view);
            this.serviceName = (TextView) view.findViewById(C0354R.id.txtView);
            this.serviceimgIcon = (ImageView) view.findViewById(C0354R.id.image);
            this.list_row = (CardView) view.findViewById(C0354R.id.service_screen_row_relative);
        }
    }

    public ServiceScreenAdapter(ArrayList<ServicesData> arrayList, Context context) {
        this.mServicedata = arrayList;
        this.mPref = context.getSharedPreferences("person", 0);
        this.mEditor = this.mPref.edit();
        this.context = context;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(C0354R.layout.home_screen_service_row, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.serviceName.setText(((ServicesData) this.mServicedata.get(i)).getServicename());
        if (((ServicesData) this.mServicedata.get(i)).getServiceimgs().isEmpty()) {
            viewHolder.serviceimgIcon.setImageResource(C0354R.mipmap.download);
        } else {
            Picasso.with(this.context).load(((ServicesData) this.mServicedata.get(i)).getServiceimgs()).into(viewHolder.serviceimgIcon);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(((ServicesData) this.mServicedata.get(i)).isSelected());
        Log.e("selection", stringBuilder.toString());
        if (((ServicesData) this.mServicedata.get(i)).isSelected()) {
            Log.e("data", ((ServicesData) this.mServicedata.get(i)).getServicename());
            this.ServiceTextviewName = ((ServicesData) this.mServicedata.get(i)).getServicename();
            this.ServiceTextviewNameId = ((ServicesData) this.mServicedata.get(i)).getServiceid();
            viewHolder.list_row.setCardBackgroundColor(Color.parseColor("#C0C0C0"));
        } else {
            viewHolder.list_row.setCardBackgroundColor(0);
        }
        viewHolder = PreferenceManager.getDefaultSharedPreferences(this.context);
        viewHolder.edit().putString("RecyclerviewService", this.ServiceTextviewName).apply();
        viewHolder.edit().putString("RecyclerviewServiceId", this.ServiceTextviewNameId).apply();
    }

    public void setSelected(int i) {
        try {
            if (this.mServicedata.size() > 1) {
                ((ServicesData) this.mServicedata.get(this.mPref.getInt("position", 0))).setSelected(false);
                this.mEditor.putInt("position", i);
                this.mEditor.commit();
            }
            ((ServicesData) this.mServicedata.get(i)).setSelected(true);
            notifyDataSetChanged();
        } catch (int i2) {
            i2.printStackTrace();
        }
    }

    public int getItemCount() {
        return this.mServicedata == null ? 0 : this.mServicedata.size();
    }
}
