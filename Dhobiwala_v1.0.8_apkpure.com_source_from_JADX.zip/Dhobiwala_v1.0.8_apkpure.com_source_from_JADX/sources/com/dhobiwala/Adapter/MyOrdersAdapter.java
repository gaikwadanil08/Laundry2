package com.dhobiwala.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;
import com.dhobiwala.Activity.MyOrderActivity;
import com.dhobiwala.Activity.MyOrderDetailsActivity;
import com.dhobiwala.C0354R;
import java.util.ArrayList;
import java.util.HashMap;

public class MyOrdersAdapter extends Adapter<CustomViewHolder> {
    private Context context;
    private ArrayList<HashMap<String, String>> myOrdersList;
    private HashMap<String, String> myOrdersResult = new HashMap();

    public class CustomViewHolder extends ViewHolder {
        private TextView myOrderDateTV;
        private TextView myOrderIdTv;
        private TextView myOrderP_dateTv;
        private TextView myOrderP_timeTv;
        private TextView myOrderServicesTv;
        private TextView myOrderStatusTV;

        public CustomViewHolder(View view) {
            super(view);
            this.myOrderIdTv = (TextView) view.findViewById(C0354R.id.my_order_id);
            this.myOrderDateTV = (TextView) view.findViewById(C0354R.id.my_order_date);
            this.myOrderStatusTV = (TextView) view.findViewById(C0354R.id.my_order_status);
            this.myOrderServicesTv = (TextView) view.findViewById(C0354R.id.my_order_services);
            this.myOrderP_dateTv = (TextView) view.findViewById(C0354R.id.my_order_pickup_date);
            this.myOrderP_timeTv = (TextView) view.findViewById(C0354R.id.my_order_pickup_time);
        }
    }

    public MyOrdersAdapter(Context context, ArrayList<HashMap<String, String>> arrayList) {
        this.context = context;
        this.myOrdersList = arrayList;
    }

    public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new CustomViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(C0354R.layout.my_order_list_item, viewGroup, false));
    }

    public void onBindViewHolder(CustomViewHolder customViewHolder, final int i) {
        this.myOrdersResult = (HashMap) this.myOrdersList.get(i);
        customViewHolder.myOrderIdTv.setText((CharSequence) this.myOrdersResult.get("order_id"));
        customViewHolder.myOrderDateTV.setText((CharSequence) this.myOrdersResult.get(MyOrderActivity.KEY_MY_ORDERS_DATE));
        customViewHolder.myOrderStatusTV.setText((CharSequence) this.myOrdersResult.get("status"));
        customViewHolder.myOrderServicesTv.setText((CharSequence) this.myOrdersResult.get(MyOrderActivity.KEY_MY_ORDERS_SERVICES));
        customViewHolder.myOrderP_dateTv.setText((CharSequence) this.myOrdersResult.get("p_date"));
        customViewHolder.myOrderP_timeTv.setText((CharSequence) this.myOrdersResult.get(MyOrderActivity.KEY_MY_ORDERS_PICKUP_TIME));
        customViewHolder.itemView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyOrdersAdapter.this.myOrdersResult = (HashMap) MyOrdersAdapter.this.myOrdersList.get(i);
                view = new Intent(MyOrdersAdapter.this.context, MyOrderDetailsActivity.class);
                view.putExtra("orderId", (String) ((HashMap) MyOrdersAdapter.this.myOrdersList.get(i)).get("order_id"));
                view.putExtra("orderService", (String) ((HashMap) MyOrdersAdapter.this.myOrdersList.get(i)).get(MyOrderActivity.KEY_MY_ORDERS_SERVICES));
                view.putExtra("orderStatus", (String) ((HashMap) MyOrdersAdapter.this.myOrdersList.get(i)).get("status"));
                MyOrdersAdapter.this.context.startActivity(view);
            }
        });
    }

    public int getItemCount() {
        return this.myOrdersList.size();
    }
}
