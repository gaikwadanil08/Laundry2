package com.dhobiwala.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.dhobiwala.Activity.DonateClothsActivity;
import com.dhobiwala.C0354R;

public class SwipePagerAdapter extends PagerAdapter {
    Context context;
    int[] image_resource = new int[]{C0354R.mipmap.dry_cleaning, C0354R.mipmap.steam_iron_banner, C0354R.mipmap.wash_and_fold_banner, C0354R.mipmap.donate_banner};
    LayoutInflater inflater;

    /* renamed from: com.dhobiwala.Adapter.SwipePagerAdapter$1 */
    class C03341 implements OnClickListener {
        C03341() {
        }

        public void onClick(View view) {
            view = new Intent(SwipePagerAdapter.this.context, DonateClothsActivity.class);
            view.setFlags(67108864);
            SwipePagerAdapter.this.context.startActivity(view);
        }
    }

    public SwipePagerAdapter(Context context) {
        this.context = context;
    }

    public int getCount() {
        return this.image_resource.length;
    }

    public Object instantiateItem(ViewGroup viewGroup, int i) {
        this.inflater = (LayoutInflater) this.context.getSystemService("layout_inflater");
        View inflate = this.inflater.inflate(C0354R.layout.activity_swipe_viewpager, viewGroup, false);
        ImageView imageView = (ImageView) inflate.findViewById(C0354R.id.swipe_imageview);
        imageView.setImageResource(this.image_resource[i]);
        if (i == 3) {
            imageView.setOnClickListener(new C03341());
        }
        viewGroup.addView(inflate);
        return inflate;
    }

    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        viewGroup.removeView((LinearLayout) obj);
    }

    public boolean isViewFromObject(View view, Object obj) {
        return view == ((LinearLayout) obj) ? true : null;
    }
}
