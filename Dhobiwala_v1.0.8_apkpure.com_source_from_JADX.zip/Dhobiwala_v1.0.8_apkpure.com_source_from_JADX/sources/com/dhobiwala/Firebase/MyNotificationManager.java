package com.dhobiwala.Firebase;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.app.NotificationCompat.BigPictureStyle;
import android.support.v4.app.NotificationCompat.Builder;
import android.support.v4.app.NotificationCompat.Style;
import android.text.Html;
import com.dhobiwala.C0354R;
import java.net.HttpURLConnection;
import java.net.URL;

public class MyNotificationManager {
    public static final int ID_BIG_NOTIFICATION = 234;
    public static final int ID_SMALL_NOTIFICATION = 235;
    private Context mCtx;

    public MyNotificationManager(Context context) {
        this.mCtx = context;
    }

    public void showBigNotification(String str, String str2, String str3, Intent intent) {
        intent = PendingIntent.getActivity(this.mCtx, ID_BIG_NOTIFICATION, intent, 134217728);
        Style bigPictureStyle = new BigPictureStyle();
        bigPictureStyle.setBigContentTitle(str);
        bigPictureStyle.setSummaryText(Html.fromHtml(str2).toString());
        bigPictureStyle.bigPicture(getBitmapFromURL(str3));
        str = new Builder(this.mCtx).setSmallIcon(C0354R.mipmap.ic_launcher).setTicker(str).setWhen(0).setAutoCancel(true).setContentIntent(intent).setContentTitle(str).setStyle(bigPictureStyle).setSmallIcon(C0354R.mipmap.ic_launcher).setLargeIcon(BitmapFactory.decodeResource(this.mCtx.getResources(), C0354R.mipmap.ic_launcher)).setContentText(str2).build();
        str.flags |= 16;
        ((NotificationManager) this.mCtx.getSystemService("notification")).notify(ID_BIG_NOTIFICATION, str);
    }

    public void showSmallNotification(String str, String str2, Intent intent) {
        str = new Builder(this.mCtx).setSmallIcon(C0354R.mipmap.ic_launcher).setTicker(str).setWhen(0).setAutoCancel(true).setContentIntent(PendingIntent.getActivity(this.mCtx, ID_SMALL_NOTIFICATION, intent, 134217728)).setContentTitle(str).setSmallIcon(C0354R.mipmap.ic_launcher).setLargeIcon(BitmapFactory.decodeResource(this.mCtx.getResources(), C0354R.mipmap.ic_launcher)).setContentText(str2).build();
        str.flags |= 16;
        ((NotificationManager) this.mCtx.getSystemService("notification")).notify(ID_SMALL_NOTIFICATION, str);
    }

    private Bitmap getBitmapFromURL(String str) {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            httpURLConnection.setDoInput(true);
            httpURLConnection.connect();
            return BitmapFactory.decodeStream(httpURLConnection.getInputStream());
        } catch (String str2) {
            str2.printStackTrace();
            return null;
        }
    }
}
