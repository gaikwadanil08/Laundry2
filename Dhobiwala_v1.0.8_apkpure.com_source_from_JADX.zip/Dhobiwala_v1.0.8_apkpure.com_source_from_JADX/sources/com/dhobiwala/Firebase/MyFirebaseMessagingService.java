package com.dhobiwala.Firebase;

import android.content.Intent;
import android.util.Log;
import com.dhobiwala.Activity.HomeScreenActivity;
import com.google.android.gms.plus.PlusShare;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import org.json.JSONObject;

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private static final String TAG = "MyFirebaseMsgService";

    public void onMessageReceived(RemoteMessage remoteMessage) {
        if (remoteMessage.getData().size() > 0) {
            String str = TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Data Payload: ");
            stringBuilder.append(remoteMessage.getData().toString());
            Log.e(str, stringBuilder.toString());
            try {
                sendPushNotification(new JSONObject(remoteMessage.getData().toString()));
            } catch (RemoteMessage remoteMessage2) {
                str = TAG;
                stringBuilder = new StringBuilder();
                stringBuilder.append("Exception: ");
                stringBuilder.append(remoteMessage2.getMessage());
                Log.e(str, stringBuilder.toString());
            }
        }
    }

    private void sendPushNotification(JSONObject jSONObject) {
        String str = TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Notification JSON ");
        stringBuilder.append(jSONObject.toString());
        Log.e(str, stringBuilder.toString());
        try {
            jSONObject = jSONObject.getJSONObject("data");
            jSONObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE);
            jSONObject.getString("message");
            jSONObject = new MyNotificationManager(getApplicationContext());
            jSONObject = new Intent(getApplicationContext(), HomeScreenActivity.class);
        } catch (JSONObject jSONObject2) {
            str = TAG;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Json Exception: ");
            stringBuilder.append(jSONObject2.getMessage());
            Log.e(str, stringBuilder.toString());
        } catch (JSONObject jSONObject22) {
            str = TAG;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Exception: ");
            stringBuilder.append(jSONObject22.getMessage());
            Log.e(str, stringBuilder.toString());
        }
    }
}
