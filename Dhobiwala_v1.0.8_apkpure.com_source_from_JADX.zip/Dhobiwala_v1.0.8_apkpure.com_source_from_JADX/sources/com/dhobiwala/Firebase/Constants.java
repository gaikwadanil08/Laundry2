package com.dhobiwala.Firebase;

public class Constants {
    public static final String CHANNEL_DESCRIPTION = "www.simplifiedcoding.net";
    public static final String CHANNEL_ID = "my_channel_01";
    public static final String CHANNEL_NAME = "Simplified Coding Notification";
}
