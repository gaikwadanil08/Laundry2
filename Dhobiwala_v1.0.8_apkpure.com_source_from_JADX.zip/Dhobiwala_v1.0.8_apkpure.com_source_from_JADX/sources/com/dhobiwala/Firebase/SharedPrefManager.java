package com.dhobiwala.Firebase;

import android.content.Context;
import android.content.SharedPreferences.Editor;

public class SharedPrefManager {
    private static final String SHARED_PREF_NAME = "FCMSharedPref";
    private static final String TAG_TOKEN = "tagtoken";
    private static Context mCtx;
    private static SharedPrefManager mInstance;

    private SharedPrefManager(Context context) {
        mCtx = context;
    }

    public static synchronized SharedPrefManager getInstance(Context context) {
        synchronized (SharedPrefManager.class) {
            if (mInstance == null) {
                mInstance = new SharedPrefManager(context);
            }
            context = mInstance;
        }
        return context;
    }

    public boolean saveDeviceToken(String str) {
        Editor edit = mCtx.getSharedPreferences(SHARED_PREF_NAME, 0).edit();
        edit.putString(TAG_TOKEN, str);
        edit.apply();
        return true;
    }

    public String getDeviceToken() {
        return mCtx.getSharedPreferences(SHARED_PREF_NAME, 0).getString(TAG_TOKEN, null);
    }
}
