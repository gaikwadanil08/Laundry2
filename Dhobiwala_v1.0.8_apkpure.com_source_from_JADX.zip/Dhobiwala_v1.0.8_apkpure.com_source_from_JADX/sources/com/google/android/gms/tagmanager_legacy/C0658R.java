package com.google.android.gms.tagmanager_legacy;

/* renamed from: com.google.android.gms.tagmanager_legacy.R */
public final class C0658R {
}
