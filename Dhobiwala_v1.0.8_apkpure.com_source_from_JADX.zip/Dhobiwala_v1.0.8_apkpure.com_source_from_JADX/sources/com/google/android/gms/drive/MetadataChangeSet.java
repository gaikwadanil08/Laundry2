package com.google.android.gms.drive;

import android.support.annotation.NonNull;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.drive.metadata.CustomPropertyKey;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.AppVisibleCustomProperties;
import com.google.android.gms.drive.metadata.internal.AppVisibleCustomProperties.zza;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.zzbth;
import com.google.android.gms.internal.zzbtu;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import java.util.Collections;
import java.util.Date;
import java.util.Map;

public final class MetadataChangeSet {
    public static final int CUSTOM_PROPERTY_SIZE_LIMIT_BYTES = 124;
    public static final int INDEXABLE_TEXT_SIZE_LIMIT_BYTES = 131072;
    public static final int MAX_PRIVATE_PROPERTIES_PER_RESOURCE_PER_APP = 30;
    public static final int MAX_PUBLIC_PROPERTIES_PER_RESOURCE = 30;
    public static final int MAX_TOTAL_PROPERTIES_PER_RESOURCE = 100;
    public static final MetadataChangeSet zzgkc = new MetadataChangeSet(MetadataBundle.zzapp());
    private final MetadataBundle zzgkd;

    public static class Builder {
        private final MetadataBundle zzgkd = MetadataBundle.zzapp();
        private zza zzgke;

        private final zza zzaom() {
            if (this.zzgke == null) {
                this.zzgke = new zza();
            }
            return this.zzgke;
        }

        private static int zzgw(String str) {
            return str == null ? 0 : str.getBytes().length;
        }

        private static void zzi(String str, int i, int i2) {
            zzbq.checkArgument(i2 <= i, String.format("%s must be no more than %d bytes, but is %d bytes.", new Object[]{str, Integer.valueOf(i), Integer.valueOf(i2)}));
        }

        public MetadataChangeSet build() {
            if (this.zzgke != null) {
                this.zzgkd.zzc(zzbth.zzgsn, this.zzgke.zzapm());
            }
            return new MetadataChangeSet(this.zzgkd);
        }

        public Builder deleteCustomProperty(CustomPropertyKey customPropertyKey) {
            zzbq.checkNotNull(customPropertyKey, "key");
            zzaom().zza(customPropertyKey, null);
            return this;
        }

        public Builder setCustomProperty(CustomPropertyKey customPropertyKey, String str) {
            zzbq.checkNotNull(customPropertyKey, "key");
            zzbq.checkNotNull(str, Param.VALUE);
            zzi("The total size of key string and value string of a custom property", MetadataChangeSet.CUSTOM_PROPERTY_SIZE_LIMIT_BYTES, zzgw(customPropertyKey.getKey()) + zzgw(str));
            zzaom().zza(customPropertyKey, str);
            return this;
        }

        public Builder setDescription(String str) {
            this.zzgkd.zzc(zzbth.zzgso, str);
            return this;
        }

        public Builder setIndexableText(String str) {
            zzi("Indexable text size", 131072, zzgw(str));
            this.zzgkd.zzc(zzbth.zzgsu, str);
            return this;
        }

        public Builder setLastViewedByMeDate(Date date) {
            this.zzgkd.zzc(zzbtu.zzgue, date);
            return this;
        }

        public Builder setMimeType(@NonNull String str) {
            zzbq.checkNotNull(str);
            this.zzgkd.zzc(zzbth.zzgti, str);
            return this;
        }

        public Builder setPinned(boolean z) {
            this.zzgkd.zzc(zzbth.zzgta, Boolean.valueOf(z));
            return this;
        }

        public Builder setStarred(boolean z) {
            this.zzgkd.zzc(zzbth.zzgtp, Boolean.valueOf(z));
            return this;
        }

        public Builder setTitle(@NonNull String str) {
            zzbq.checkNotNull(str, "Title cannot be null.");
            this.zzgkd.zzc(zzbth.zzgtr, str);
            return this;
        }

        public Builder setViewed() {
            this.zzgkd.zzc(zzbth.zzgth, Boolean.valueOf(true));
            return this;
        }

        @Deprecated
        public Builder setViewed(boolean z) {
            if (z) {
                this.zzgkd.zzc(zzbth.zzgth, Boolean.valueOf(true));
                return this;
            }
            if (this.zzgkd.zzd(zzbth.zzgth)) {
                this.zzgkd.zzc(zzbth.zzgth);
            }
            return this;
        }
    }

    public MetadataChangeSet(MetadataBundle metadataBundle) {
        this.zzgkd = metadataBundle.zzapq();
    }

    public final Map<CustomPropertyKey, String> getCustomPropertyChangeMap() {
        AppVisibleCustomProperties appVisibleCustomProperties = (AppVisibleCustomProperties) this.zzgkd.zza(zzbth.zzgsn);
        return appVisibleCustomProperties == null ? Collections.emptyMap() : appVisibleCustomProperties.zzapl();
    }

    public final String getDescription() {
        return (String) this.zzgkd.zza(zzbth.zzgso);
    }

    public final String getIndexableText() {
        return (String) this.zzgkd.zza(zzbth.zzgsu);
    }

    public final Date getLastViewedByMeDate() {
        return (Date) this.zzgkd.zza(zzbtu.zzgue);
    }

    public final String getMimeType() {
        return (String) this.zzgkd.zza(zzbth.zzgti);
    }

    public final String getTitle() {
        return (String) this.zzgkd.zza(zzbth.zzgtr);
    }

    public final Boolean isPinned() {
        return (Boolean) this.zzgkd.zza(zzbth.zzgta);
    }

    public final Boolean isStarred() {
        return (Boolean) this.zzgkd.zza(zzbth.zzgtp);
    }

    public final Boolean isViewed() {
        return (Boolean) this.zzgkd.zza(zzbth.zzgth);
    }

    public final <T> MetadataChangeSet zza(MetadataField<T> metadataField, T t) {
        MetadataChangeSet metadataChangeSet = new MetadataChangeSet(this.zzgkd);
        metadataChangeSet.zzgkd.zzc(metadataField, t);
        return metadataChangeSet;
    }

    public final MetadataBundle zzaol() {
        return this.zzgkd;
    }
}
