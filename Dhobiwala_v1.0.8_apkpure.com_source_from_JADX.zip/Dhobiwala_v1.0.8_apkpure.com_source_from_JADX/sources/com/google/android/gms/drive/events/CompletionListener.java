package com.google.android.gms.drive.events;

public interface CompletionListener extends zzi {
    void onCompletion(CompletionEvent completionEvent);
}
