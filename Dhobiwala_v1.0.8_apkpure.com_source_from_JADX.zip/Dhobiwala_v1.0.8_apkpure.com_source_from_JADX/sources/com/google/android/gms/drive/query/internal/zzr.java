package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.drive.query.Filter;
import com.google.android.gms.internal.zzbfp;
import java.util.ArrayList;
import java.util.List;

public final class zzr extends zza {
    public static final Creator<zzr> CREATOR = new zzs();
    private List<Filter> zzgus;
    private zzx zzguy;
    private List<FilterHolder> zzgvn;

    public zzr(zzx zzx, Filter filter, Filter... filterArr) {
        this.zzguy = zzx;
        this.zzgvn = new ArrayList(filterArr.length + 1);
        this.zzgvn.add(new FilterHolder(filter));
        this.zzgus = new ArrayList(filterArr.length + 1);
        this.zzgus.add(filter);
        for (Filter filter2 : filterArr) {
            this.zzgvn.add(new FilterHolder(filter2));
            this.zzgus.add(filter2);
        }
    }

    public zzr(zzx zzx, Iterable<Filter> iterable) {
        this.zzguy = zzx;
        this.zzgus = new ArrayList();
        this.zzgvn = new ArrayList();
        for (Filter filter : iterable) {
            this.zzgus.add(filter);
            this.zzgvn.add(new FilterHolder(filter));
        }
    }

    zzr(zzx zzx, List<FilterHolder> list) {
        this.zzguy = zzx;
        this.zzgvn = list;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 1, this.zzguy, i, false);
        zzbfp.zzc(parcel, 2, this.zzgvn, false);
        zzbfp.zzai(parcel, zze);
    }

    public final <T> T zza(zzj<T> zzj) {
        List arrayList = new ArrayList();
        for (FilterHolder filter : this.zzgvn) {
            arrayList.add(filter.getFilter().zza(zzj));
        }
        return zzj.zza(this.zzguy, arrayList);
    }
}
