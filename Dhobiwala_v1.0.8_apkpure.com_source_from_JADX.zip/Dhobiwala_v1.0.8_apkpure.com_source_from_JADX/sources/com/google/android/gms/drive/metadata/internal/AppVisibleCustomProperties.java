package com.google.android.gms.drive.metadata.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.drive.metadata.CustomPropertyKey;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class AppVisibleCustomProperties extends zzbfm implements ReflectedParcelable, Iterable<zzc> {
    public static final Creator<AppVisibleCustomProperties> CREATOR = new zza();
    public static final AppVisibleCustomProperties zzgsb = new zza().zzapm();
    private List<zzc> zzgsc;

    public static class zza {
        private final Map<CustomPropertyKey, zzc> zzgsd = new HashMap();

        public final zza zza(CustomPropertyKey customPropertyKey, String str) {
            zzbq.checkNotNull(customPropertyKey, "key");
            this.zzgsd.put(customPropertyKey, new zzc(customPropertyKey, str));
            return this;
        }

        public final zza zza(zzc zzc) {
            zzbq.checkNotNull(zzc, "property");
            this.zzgsd.put(zzc.zzgse, zzc);
            return this;
        }

        public final AppVisibleCustomProperties zzapm() {
            return new AppVisibleCustomProperties(this.zzgsd.values());
        }
    }

    AppVisibleCustomProperties(Collection<zzc> collection) {
        zzbq.checkNotNull(collection);
        this.zzgsc = new ArrayList(collection);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            if (obj.getClass() == getClass()) {
                return zzapl().equals(((AppVisibleCustomProperties) obj).zzapl());
            }
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.zzgsc});
    }

    public final Iterator<zzc> iterator() {
        return this.zzgsc.iterator();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zzc(parcel, 2, this.zzgsc, false);
        zzbfp.zzai(parcel, i);
    }

    public final Map<CustomPropertyKey, String> zzapl() {
        Map hashMap = new HashMap(this.zzgsc.size());
        for (zzc zzc : this.zzgsc) {
            hashMap.put(zzc.zzgse, zzc.mValue);
        }
        return Collections.unmodifiableMap(hashMap);
    }
}
