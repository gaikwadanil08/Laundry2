package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;

public final class zzi extends zzbfm {
    public static final Creator<zzi> CREATOR = new zzj();
    private long zzgjh;
    private long zzgji;

    public zzi(long j, long j2) {
        this.zzgjh = j;
        this.zzgji = j2;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzgjh);
        zzbfp.zza(parcel, 3, this.zzgji);
        zzbfp.zzai(parcel, i);
    }
}
