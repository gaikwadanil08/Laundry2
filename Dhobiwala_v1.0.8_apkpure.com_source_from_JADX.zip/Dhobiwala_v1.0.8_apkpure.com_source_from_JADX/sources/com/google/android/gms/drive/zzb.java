package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.internal.zzbfn;

public final class zzb implements Creator<zza> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int zzd = zzbfn.zzd(parcel);
        long j = 0;
        long j2 = j;
        long j3 = j2;
        while (parcel.dataPosition() < zzd) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 2:
                    j = zzbfn.zzi(parcel, readInt);
                    break;
                case 3:
                    j2 = zzbfn.zzi(parcel, readInt);
                    break;
                case 4:
                    j3 = zzbfn.zzi(parcel, readInt);
                    break;
                default:
                    zzbfn.zzb(parcel, readInt);
                    break;
            }
        }
        zzbfn.zzaf(parcel, zzd);
        return new zza(j, j2, j3);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new zza[i];
    }
}
