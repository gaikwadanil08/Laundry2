package com.google.android.gms.drive.widget;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.internal.zzal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DataBufferAdapter<T> extends BaseAdapter {
    private static final zzal zzgjj = new zzal("DataBufferAdapter", "");
    private final Context mContext;
    private final LayoutInflater mInflater;
    private final int zzgvy;
    private int zzgvz;
    private final int zzgwa;
    private final List<DataBuffer<T>> zzgwb;
    private boolean zzgwc;

    public DataBufferAdapter(Context context, int i) {
        this(context, i, 0, new ArrayList());
    }

    public DataBufferAdapter(Context context, int i, int i2) {
        this(context, i, i2, new ArrayList());
    }

    public DataBufferAdapter(Context context, int i, int i2, List<DataBuffer<T>> list) {
        this.zzgwc = true;
        this.mContext = context;
        this.zzgvz = i;
        this.zzgvy = i;
        this.zzgwa = i2;
        this.zzgwb = list;
        this.mInflater = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    public DataBufferAdapter(Context context, int i, int i2, DataBuffer<T>... dataBufferArr) {
        this(context, i, i2, Arrays.asList(dataBufferArr));
    }

    public DataBufferAdapter(Context context, int i, List<DataBuffer<T>> list) {
        this(context, i, 0, (List) list);
    }

    public DataBufferAdapter(Context context, int i, DataBuffer<T>... dataBufferArr) {
        this(context, i, 0, Arrays.asList(dataBufferArr));
    }

    private final android.view.View zza(int r2, android.view.View r3, android.view.ViewGroup r4, int r5) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:13:0x002c in {1, 5, 6, 9, 11, 12, 16} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
        /*
        r1 = this;
        if (r3 != 0) goto L_0x0009;
    L_0x0002:
        r3 = r1.mInflater;
        r0 = 0;
        r3 = r3.inflate(r5, r4, r0);
    L_0x0009:
        r4 = r1.zzgwa;	 Catch:{ ClassCastException -> 0x002d }
        if (r4 != 0) goto L_0x0011;	 Catch:{ ClassCastException -> 0x002d }
    L_0x000d:
        r4 = r3;	 Catch:{ ClassCastException -> 0x002d }
        r4 = (android.widget.TextView) r4;	 Catch:{ ClassCastException -> 0x002d }
        goto L_0x0019;	 Catch:{ ClassCastException -> 0x002d }
    L_0x0011:
        r4 = r1.zzgwa;	 Catch:{ ClassCastException -> 0x002d }
        r4 = r3.findViewById(r4);	 Catch:{ ClassCastException -> 0x002d }
        r4 = (android.widget.TextView) r4;	 Catch:{ ClassCastException -> 0x002d }
    L_0x0019:
        r2 = r1.getItem(r2);
        r5 = r2 instanceof java.lang.CharSequence;
        if (r5 == 0) goto L_0x0027;
    L_0x0021:
        r2 = (java.lang.CharSequence) r2;
    L_0x0023:
        r4.setText(r2);
        return r3;
    L_0x0027:
        r2 = r2.toString();
        goto L_0x0023;
        return r3;
    L_0x002d:
        r2 = move-exception;
        r3 = zzgjj;
        r4 = "DataBufferAdapter";
        r5 = "You must supply a resource ID for a TextView";
        r3.zzd(r4, r5, r2);
        r3 = new java.lang.IllegalStateException;
        r4 = "DataBufferAdapter requires the resource ID to be a TextView";
        r3.<init>(r4, r2);
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.drive.widget.DataBufferAdapter.zza(int, android.view.View, android.view.ViewGroup, int):android.view.View");
    }

    public void append(DataBuffer<T> dataBuffer) {
        this.zzgwb.add(dataBuffer);
        if (this.zzgwc) {
            notifyDataSetChanged();
        }
    }

    public void clear() {
        for (DataBuffer release : this.zzgwb) {
            release.release();
        }
        this.zzgwb.clear();
        if (this.zzgwc) {
            notifyDataSetChanged();
        }
    }

    public Context getContext() {
        return this.mContext;
    }

    public int getCount() {
        int i = 0;
        for (DataBuffer count : this.zzgwb) {
            i += count.getCount();
        }
        return i;
    }

    public View getDropDownView(int i, View view, ViewGroup viewGroup) {
        return zza(i, view, viewGroup, this.zzgvz);
    }

    public T getItem(int r5) throws android.database.CursorIndexOutOfBoundsException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
        /*
        r4 = this;
        r0 = r4.zzgwb;
        r0 = r0.iterator();
        r1 = r5;
    L_0x0007:
        r2 = r0.hasNext();
        if (r2 == 0) goto L_0x002a;
    L_0x000d:
        r2 = r0.next();
        r2 = (com.google.android.gms.common.data.DataBuffer) r2;
        r3 = r2.getCount();
        if (r3 > r1) goto L_0x001b;
    L_0x0019:
        r1 = r1 - r3;
        goto L_0x0007;
    L_0x001b:
        r0 = r2.get(r1);	 Catch:{ CursorIndexOutOfBoundsException -> 0x0020 }
        return r0;
    L_0x0020:
        r0 = new android.database.CursorIndexOutOfBoundsException;
        r1 = r4.getCount();
        r0.<init>(r5, r1);
        throw r0;
    L_0x002a:
        r0 = new android.database.CursorIndexOutOfBoundsException;
        r1 = r4.getCount();
        r0.<init>(r5, r1);
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.drive.widget.DataBufferAdapter.getItem(int):T");
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        return zza(i, view, viewGroup, this.zzgvy);
    }

    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        this.zzgwc = true;
    }

    public void setDropDownViewResource(int i) {
        this.zzgvz = i;
    }

    public void setNotifyOnChange(boolean z) {
        this.zzgwc = z;
    }
}
