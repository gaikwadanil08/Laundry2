package com.google.android.gms.drive.events;

@Deprecated
public interface ChangeListener extends zzi {
    void onChange(ChangeEvent changeEvent);
}
