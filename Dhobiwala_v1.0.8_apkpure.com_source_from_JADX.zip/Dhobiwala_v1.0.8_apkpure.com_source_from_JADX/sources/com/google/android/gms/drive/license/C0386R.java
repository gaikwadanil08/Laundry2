package com.google.android.gms.drive.license;

/* renamed from: com.google.android.gms.drive.license.R */
public final class C0386R {
}
