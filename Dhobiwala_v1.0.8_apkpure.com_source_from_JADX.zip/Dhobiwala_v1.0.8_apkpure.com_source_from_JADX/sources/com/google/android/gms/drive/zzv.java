package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.zzbg;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.Arrays;

public final class zzv extends zzbfm {
    public static final Creator<zzv> CREATOR = new zzw();
    private String zzgkm;
    private int zzgkn;
    private String zzgko;
    private String zzgkp;
    private int zzgkq;
    private boolean zzgkr;

    public zzv(String str, int i, String str2, String str3, int i2, boolean z) {
        this.zzgkm = str;
        this.zzgkn = i;
        this.zzgko = str2;
        this.zzgkp = str3;
        this.zzgkq = i2;
        this.zzgkr = z;
    }

    private static boolean zzcs(int i) {
        switch (i) {
            case 256:
            case 257:
            case CallbackHandler.MSG_ROUTE_REMOVED /*258*/:
                return true;
            default:
                return false;
        }
    }

    public final boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        zzv zzv = (zzv) obj;
        return zzbg.equal(this.zzgkm, zzv.zzgkm) && this.zzgkn == zzv.zzgkn && this.zzgkq == zzv.zzgkq && this.zzgkr == zzv.zzgkr;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.zzgkm, Integer.valueOf(this.zzgkn), Integer.valueOf(this.zzgkq), Boolean.valueOf(this.zzgkr)});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        boolean z = false;
        zzbfp.zza(parcel, 2, !zzcs(this.zzgkn) ? null : this.zzgkm, false);
        int i2 = -1;
        zzbfp.zzc(parcel, 3, !zzcs(this.zzgkn) ? -1 : this.zzgkn);
        zzbfp.zza(parcel, 4, this.zzgko, false);
        zzbfp.zza(parcel, 5, this.zzgkp, false);
        switch (this.zzgkq) {
            case 0:
            case 1:
            case 2:
            case 3:
                z = true;
                break;
            default:
                break;
        }
        if (z) {
            i2 = this.zzgkq;
        }
        zzbfp.zzc(parcel, 6, i2);
        zzbfp.zza(parcel, 7, this.zzgkr);
        zzbfp.zzai(parcel, i);
    }
}
