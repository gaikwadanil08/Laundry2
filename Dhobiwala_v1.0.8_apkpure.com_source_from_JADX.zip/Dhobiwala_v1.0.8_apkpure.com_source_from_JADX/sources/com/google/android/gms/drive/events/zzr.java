package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.internal.zzbg;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import com.google.android.gms.internal.zzbku;
import java.util.Arrays;
import java.util.List;

public final class zzr extends zzbfm implements DriveEvent {
    public static final Creator<zzr> CREATOR = new zzs();
    private String zzebv;
    private List<zzbku> zzgly;

    public zzr(String str, List<zzbku> list) {
        this.zzebv = str;
        this.zzgly = list;
    }

    public final boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        zzr zzr = (zzr) obj;
        return zzbg.equal(this.zzebv, zzr.zzebv) && zzbg.equal(this.zzgly, zzr.zzgly);
    }

    public final int getType() {
        return 7;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.zzebv, this.zzgly});
    }

    public final String toString() {
        return String.format("TransferStateEvent[%s]", new Object[]{TextUtils.join("','", this.zzgly)});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzebv, false);
        zzbfp.zzc(parcel, 3, this.zzgly, false);
        zzbfp.zzai(parcel, i);
    }
}
