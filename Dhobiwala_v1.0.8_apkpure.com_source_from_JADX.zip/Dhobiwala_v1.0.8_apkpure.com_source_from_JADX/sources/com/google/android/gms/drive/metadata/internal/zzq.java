package com.google.android.gms.drive.metadata.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;

public final class zzq extends zzbfm {
    public static final Creator<zzq> CREATOR = new zzr();
    final String zzgjk;
    final long zzgjl;
    final int zzgjm;

    public zzq(String str, long j, int i) {
        this.zzgjk = str;
        this.zzgjl = j;
        this.zzgjm = i;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzgjk, false);
        zzbfp.zza(parcel, 3, this.zzgjl);
        zzbfp.zzc(parcel, 4, this.zzgjm);
        zzbfp.zzai(parcel, i);
    }
}
