package com.google.android.gms.drive.metadata.internal;

import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.drive.DriveFolder;

public final class zzk {
    private String zzgsi;

    private zzk(String str) {
        this.zzgsi = str.toLowerCase();
    }

    public static zzk zzgy(String str) {
        boolean z;
        if (str != null) {
            if (str.isEmpty()) {
                z = false;
                zzbq.checkArgument(z);
                return str != null ? null : new zzk(str);
            }
        }
        z = true;
        zzbq.checkArgument(z);
        if (str != null) {
        }
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj != null) {
            if (obj.getClass() == getClass()) {
                return this.zzgsi.equals(((zzk) obj).zzgsi);
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.zzgsi.hashCode();
    }

    public final boolean isFolder() {
        return this.zzgsi.equals(DriveFolder.MIME_TYPE);
    }

    public final String toString() {
        return this.zzgsi;
    }

    public final boolean zzaps() {
        return this.zzgsi.startsWith("application/vnd.google-apps");
    }
}
