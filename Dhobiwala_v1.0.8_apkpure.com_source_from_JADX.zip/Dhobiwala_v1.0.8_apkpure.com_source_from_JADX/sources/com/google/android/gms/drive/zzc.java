package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public final class zzc extends zzbfm {
    public static final Creator<zzc> CREATOR = new zzd();
    private String zzaym;
    private ParcelFileDescriptor zzfxc;
    final int zzgiq;
    private int zzgir;
    private DriveId zzgis;
    private boolean zzgit;

    public zzc(ParcelFileDescriptor parcelFileDescriptor, int i, int i2, DriveId driveId, boolean z, String str) {
        this.zzfxc = parcelFileDescriptor;
        this.zzgiq = i;
        this.zzgir = i2;
        this.zzgis = driveId;
        this.zzgit = z;
        this.zzaym = str;
    }

    public final DriveId getDriveId() {
        return this.zzgis;
    }

    public final InputStream getInputStream() {
        return new FileInputStream(this.zzfxc.getFileDescriptor());
    }

    public final int getMode() {
        return this.zzgir;
    }

    public final OutputStream getOutputStream() {
        return new FileOutputStream(this.zzfxc.getFileDescriptor());
    }

    public final ParcelFileDescriptor getParcelFileDescriptor() {
        return this.zzfxc;
    }

    public final int getRequestId() {
        return this.zzgiq;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzfxc, i, false);
        zzbfp.zzc(parcel, 3, this.zzgiq);
        zzbfp.zzc(parcel, 4, this.zzgir);
        zzbfp.zza(parcel, 5, this.zzgis, i, false);
        zzbfp.zza(parcel, 7, this.zzgit);
        zzbfp.zza(parcel, 8, this.zzaym, false);
        zzbfp.zzai(parcel, zze);
    }

    public final boolean zzant() {
        return this.zzgit;
    }
}
