package com.google.android.gms.drive;

import com.google.android.gms.drive.ExecutionOptions.Builder;

public final class zzt extends Builder {
    private boolean zzgjz = true;

    public final /* synthetic */ ExecutionOptions build() {
        zzaoh();
        return new zzr(this.zzgju, this.zzgjv, this.zzgjw, this.zzgjz, null);
    }

    public final /* synthetic */ Builder setConflictStrategy(int i) {
        super.setConflictStrategy(i);
        return this;
    }

    public final /* synthetic */ Builder setNotifyOnCompletion(boolean z) {
        super.setNotifyOnCompletion(z);
        return this;
    }

    public final /* synthetic */ Builder setTrackingTag(String str) {
        super.setTrackingTag(str);
        return this;
    }
}
