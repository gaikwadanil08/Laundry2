package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.internal.zzbfp;

public final class zzz extends zza {
    public static final Creator<zzz> CREATOR = new zzaa();

    public final void writeToParcel(Parcel parcel, int i) {
        zzbfp.zzai(parcel, zzbfp.zze(parcel));
    }

    public final <F> F zza(zzj<F> zzj) {
        return zzj.zzapu();
    }
}
