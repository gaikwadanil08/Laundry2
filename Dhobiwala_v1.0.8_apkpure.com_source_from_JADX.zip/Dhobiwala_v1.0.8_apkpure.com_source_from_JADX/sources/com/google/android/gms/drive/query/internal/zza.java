package com.google.android.gms.drive.query.internal;

import com.google.android.gms.drive.query.Filter;
import com.google.android.gms.drive.query.zzd;
import com.google.android.gms.internal.zzbfm;

public abstract class zza extends zzbfm implements Filter {
    public String toString() {
        return String.format("Filter[%s]", new Object[]{zza(new zzd())});
    }
}
