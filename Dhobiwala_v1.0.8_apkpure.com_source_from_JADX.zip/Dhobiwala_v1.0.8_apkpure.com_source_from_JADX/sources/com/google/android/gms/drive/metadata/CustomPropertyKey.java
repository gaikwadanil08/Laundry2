package com.google.android.gms.drive.metadata;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;

public class CustomPropertyKey extends zzbfm {
    public static final Creator<CustomPropertyKey> CREATOR = new zzc();
    public static final int PRIVATE = 1;
    public static final int PUBLIC = 0;
    private static final Pattern zzgsa = Pattern.compile("[\\w.!@$%^&*()/-]+");
    private int mVisibility;
    private String zzbhb;

    public CustomPropertyKey(String str, int i) {
        zzbq.checkNotNull(str, "key");
        zzbq.checkArgument(zzgsa.matcher(str).matches(), "key name characters must be alphanumeric or one of .!@$%^&*()-_/");
        boolean z = true;
        if (i != 0) {
            if (i != 1) {
                z = false;
            }
        }
        zzbq.checkArgument(z, "visibility must be either PUBLIC or PRIVATE");
        this.zzbhb = str;
        this.mVisibility = i;
    }

    public static CustomPropertyKey fromJson(JSONObject jSONObject) throws JSONException {
        return new CustomPropertyKey(jSONObject.getString("key"), jSONObject.getInt("visibility"));
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        CustomPropertyKey customPropertyKey = (CustomPropertyKey) obj;
        return customPropertyKey.getKey().equals(this.zzbhb) && customPropertyKey.getVisibility() == this.mVisibility;
    }

    public String getKey() {
        return this.zzbhb;
    }

    public int getVisibility() {
        return this.mVisibility;
    }

    public int hashCode() {
        String str = this.zzbhb;
        int i = this.mVisibility;
        StringBuilder stringBuilder = new StringBuilder(11 + String.valueOf(str).length());
        stringBuilder.append(str);
        stringBuilder.append(i);
        return stringBuilder.toString().hashCode();
    }

    public JSONObject toJson() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("key", getKey());
        jSONObject.put("visibility", getVisibility());
        return jSONObject;
    }

    public String toString() {
        String str = this.zzbhb;
        int i = this.mVisibility;
        StringBuilder stringBuilder = new StringBuilder(31 + String.valueOf(str).length());
        stringBuilder.append("CustomPropertyKey(");
        stringBuilder.append(str);
        stringBuilder.append(",");
        stringBuilder.append(i);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzbhb, false);
        zzbfp.zzc(parcel, 3, this.mVisibility);
        zzbfp.zzai(parcel, i);
    }
}
