package com.google.android.gms.drive;

import com.google.android.gms.drive.ExecutionOptions.Builder;

public final class zzq extends Builder {
    public final /* synthetic */ ExecutionOptions build() {
        zzaoh();
        return new zzo(this.zzgju, this.zzgjv, this.zzgjw);
    }

    public final /* synthetic */ Builder setConflictStrategy(int i) {
        throw new UnsupportedOperationException();
    }

    public final /* synthetic */ Builder setNotifyOnCompletion(boolean z) {
        super.setNotifyOnCompletion(z);
        return this;
    }

    public final /* synthetic */ Builder setTrackingTag(String str) {
        super.setTrackingTag(str);
        return this;
    }
}
