package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.drive.DriveSpace;
import com.google.android.gms.internal.zzbfn;
import java.util.List;

public final class zzu implements Creator<zzt> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int zzd = zzbfn.zzd(parcel);
        List list = null;
        while (parcel.dataPosition() < zzd) {
            int readInt = parcel.readInt();
            if ((65535 & readInt) != 2) {
                zzbfn.zzb(parcel, readInt);
            } else {
                list = zzbfn.zzc(parcel, readInt, DriveSpace.CREATOR);
            }
        }
        zzbfn.zzaf(parcel, zzd);
        return new zzt(list);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new zzt[i];
    }
}
