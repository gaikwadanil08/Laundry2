package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.annotation.NonNull;
import com.google.android.gms.common.internal.zzbg;
import com.google.android.gms.drive.DriveSpace;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class zzt extends zzbfm {
    public static final Creator<zzt> CREATOR = new zzu();
    private List<DriveSpace> zzgle;
    @NonNull
    private final Set<DriveSpace> zzglf;

    zzt(@NonNull List<DriveSpace> list) {
        this(list, list == null ? Collections.emptySet() : new HashSet(list));
    }

    private zzt(List<DriveSpace> list, @NonNull Set<DriveSpace> set) {
        this.zzgle = list;
        this.zzglf = set;
    }

    public final boolean equals(Object obj) {
        if (obj != null) {
            if (obj.getClass() == getClass()) {
                if (obj == this) {
                    return true;
                }
                return zzbg.equal(this.zzglf, ((zzt) obj).zzglf);
            }
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.zzglf});
    }

    public final String toString() {
        return String.format(Locale.US, "TransferStateOptions[Spaces=%s]", new Object[]{this.zzgle});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zzc(parcel, 2, this.zzgle, false);
        zzbfp.zzai(parcel, i);
    }
}
