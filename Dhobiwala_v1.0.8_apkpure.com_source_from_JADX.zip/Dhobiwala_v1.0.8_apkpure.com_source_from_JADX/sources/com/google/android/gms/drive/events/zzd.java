package com.google.android.gms.drive.events;

@Deprecated
public interface zzd extends zzi {
    void zza(zzb zzb);
}
