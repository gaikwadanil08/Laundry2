package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.Locale;

public final class ChangeEvent extends zzbfm implements ResourceEvent {
    public static final Creator<ChangeEvent> CREATOR = new zza();
    private DriveId zzgis;
    private int zzgla;

    public ChangeEvent(DriveId driveId, int i) {
        this.zzgis = driveId;
        this.zzgla = i;
    }

    public final DriveId getDriveId() {
        return this.zzgis;
    }

    public final int getType() {
        return 1;
    }

    public final boolean hasBeenDeleted() {
        return (this.zzgla & 4) != 0;
    }

    public final boolean hasContentChanged() {
        return (this.zzgla & 2) != 0;
    }

    public final boolean hasMetadataChanged() {
        return (this.zzgla & 1) != 0;
    }

    public final String toString() {
        return String.format(Locale.US, "ChangeEvent [id=%s,changeFlags=%x]", new Object[]{this.zzgis, Integer.valueOf(this.zzgla)});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzgis, i, false);
        zzbfp.zzc(parcel, 3, this.zzgla);
        zzbfp.zzai(parcel, zze);
    }
}
