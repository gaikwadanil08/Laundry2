package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.Locale;

public final class zzf extends zzbfm {
    public static final Creator<zzf> CREATOR = new zzg();
    private String zzgrw;
    private boolean zzgvb;

    public zzf(String str, boolean z) {
        this.zzgrw = str;
        this.zzgvb = z;
    }

    public final String toString() {
        Locale locale = Locale.US;
        String str = "FieldWithSortOrder[%s %s]";
        Object[] objArr = new Object[2];
        objArr[0] = this.zzgrw;
        objArr[1] = this.zzgvb ? "ASC" : "DESC";
        return String.format(locale, str, objArr);
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 1, this.zzgrw, false);
        zzbfp.zza(parcel, 2, this.zzgvb);
        zzbfp.zzai(parcel, i);
    }
}
