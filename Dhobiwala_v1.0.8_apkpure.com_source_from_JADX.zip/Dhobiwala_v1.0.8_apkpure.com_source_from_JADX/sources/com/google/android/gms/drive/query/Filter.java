package com.google.android.gms.drive.query;

import com.google.android.gms.drive.query.internal.zzj;
import com.google.android.gms.internal.zzbfq;

public interface Filter extends zzbfq {
    <T> T zza(zzj<T> zzj);
}
