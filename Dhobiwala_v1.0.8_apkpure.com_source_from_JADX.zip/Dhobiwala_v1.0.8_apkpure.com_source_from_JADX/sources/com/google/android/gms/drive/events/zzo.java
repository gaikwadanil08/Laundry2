package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.internal.zzbfn;
import com.google.android.gms.internal.zzbku;

public final class zzo implements Creator<zzn> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int zzd = zzbfn.zzd(parcel);
        zzbku zzbku = null;
        while (parcel.dataPosition() < zzd) {
            int readInt = parcel.readInt();
            if ((65535 & readInt) != 2) {
                zzbfn.zzb(parcel, readInt);
            } else {
                zzbku = (zzbku) zzbfn.zza(parcel, readInt, zzbku.CREATOR);
            }
        }
        zzbfn.zzaf(parcel, zzd);
        return new zzn(zzbku);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new zzn[i];
    }
}
