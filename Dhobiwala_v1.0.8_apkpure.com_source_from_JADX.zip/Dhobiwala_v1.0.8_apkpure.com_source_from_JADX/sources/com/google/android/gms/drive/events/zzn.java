package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.zzbg;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import com.google.android.gms.internal.zzbku;
import java.util.Arrays;

public final class zzn extends zzbfm implements DriveEvent {
    public static final Creator<zzn> CREATOR = new zzo();
    private zzbku zzglw;

    public zzn(zzbku zzbku) {
        this.zzglw = zzbku;
    }

    public final boolean equals(Object obj) {
        if (obj != null) {
            if (obj.getClass() == getClass()) {
                if (obj == this) {
                    return true;
                }
                return zzbg.equal(this.zzglw, ((zzn) obj).zzglw);
            }
        }
        return false;
    }

    public final int getType() {
        return 8;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.zzglw});
    }

    public final String toString() {
        return String.format("TransferProgressEvent[%s]", new Object[]{this.zzglw.toString()});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzglw, i, false);
        zzbfp.zzai(parcel, zze);
    }

    public final zzbku zzaox() {
        return this.zzglw;
    }
}
