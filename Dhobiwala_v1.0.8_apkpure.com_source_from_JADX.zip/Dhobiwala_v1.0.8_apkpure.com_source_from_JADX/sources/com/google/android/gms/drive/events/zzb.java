package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.zzbg;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.Arrays;
import java.util.Locale;

public final class zzb extends zzbfm implements DriveEvent {
    public static final Creator<zzb> CREATOR = new zzc();
    private String zzebv;
    private zze zzglb;

    public zzb(String str, zze zze) {
        this.zzebv = str;
        this.zzglb = zze;
    }

    public final boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        zzb zzb = (zzb) obj;
        return zzbg.equal(this.zzglb, zzb.zzglb) && zzbg.equal(this.zzebv, zzb.zzebv);
    }

    public final int getType() {
        return 4;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.zzglb, this.zzebv});
    }

    public final String toString() {
        return String.format(Locale.US, "ChangesAvailableEvent [changesAvailableOptions=%s]", new Object[]{this.zzglb});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzebv, false);
        zzbfp.zza(parcel, 3, this.zzglb, i, false);
        zzbfp.zzai(parcel, zze);
    }
}
