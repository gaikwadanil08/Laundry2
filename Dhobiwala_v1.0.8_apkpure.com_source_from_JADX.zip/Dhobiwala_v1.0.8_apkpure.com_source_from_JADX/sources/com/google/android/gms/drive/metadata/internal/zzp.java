package com.google.android.gms.drive.metadata.internal;

import com.google.android.gms.common.data.DataHolder;

final class zzp implements zzg {
    zzp() {
    }

    public final String zzapo() {
        return "parentsExtraHolder";
    }

    public final void zzc(DataHolder dataHolder) {
        zzo.zzd(dataHolder);
    }
}
