package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.common.util.zze;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.Set;
import java.util.regex.Pattern;

public class DriveSpace extends zzbfm implements ReflectedParcelable {
    public static final Creator<DriveSpace> CREATOR = new zzn();
    public static final DriveSpace zzgjo = new DriveSpace("DRIVE");
    public static final DriveSpace zzgjp = new DriveSpace("APP_DATA_FOLDER");
    public static final DriveSpace zzgjq = new DriveSpace("PHOTOS");
    private static Set<DriveSpace> zzgjr = zze.zza(zzgjo, zzgjp, zzgjq);
    private static String zzgjs = TextUtils.join(",", zzgjr.toArray());
    private static final Pattern zzgjt = Pattern.compile("[A-Z0-9_]*");
    private final String mName;

    DriveSpace(String str) {
        this.mName = (String) zzbq.checkNotNull(str);
    }

    public boolean equals(Object obj) {
        if (obj != null) {
            if (obj.getClass() == DriveSpace.class) {
                return this.mName.equals(((DriveSpace) obj).mName);
            }
        }
        return false;
    }

    public int hashCode() {
        return this.mName.hashCode() ^ 1247068382;
    }

    public String toString() {
        return this.mName;
    }

    public void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.mName, false);
        zzbfp.zzai(parcel, i);
    }
}
