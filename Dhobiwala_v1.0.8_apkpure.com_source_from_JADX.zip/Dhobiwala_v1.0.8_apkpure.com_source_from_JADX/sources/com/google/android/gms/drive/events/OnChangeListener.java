package com.google.android.gms.drive.events;

public interface OnChangeListener extends zzi {
    void onChange(ChangeEvent changeEvent);
}
