package com.google.android.gms.drive.events;

import com.google.android.gms.internal.zzbfq;

public interface DriveEvent extends zzbfq {
    int getType();
}
