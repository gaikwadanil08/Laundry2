package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.drive.query.Filter;
import com.google.android.gms.internal.zzbfp;

public final class zzv extends zza {
    public static final Creator<zzv> CREATOR = new zzw();
    private FilterHolder zzgvo;

    public zzv(Filter filter) {
        this(new FilterHolder(filter));
    }

    zzv(FilterHolder filterHolder) {
        this.zzgvo = filterHolder;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 1, this.zzgvo, i, false);
        zzbfp.zzai(parcel, zze);
    }

    public final <T> T zza(zzj<T> zzj) {
        return zzj.zzy(this.zzgvo.getFilter().zza(zzj));
    }
}
