package com.google.android.gms.drive;

import android.os.Parcel;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.internal.zzbfm;

public abstract class zzy extends zzbfm {
    private volatile transient boolean zzgkz = false;

    public void writeToParcel(Parcel parcel, int i) {
        zzbq.checkState(this.zzgkz ^ true);
        this.zzgkz = true;
        zzaj(parcel, i);
    }

    protected abstract void zzaj(Parcel parcel, int i);
}
