package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;

public class UserMetadata extends zzbfm implements ReflectedParcelable {
    public static final Creator<UserMetadata> CREATOR = new zzx();
    private String zzegt;
    private String zzgkv;
    private String zzgkw;
    private boolean zzgkx;
    private String zzgky;

    public UserMetadata(String str, String str2, String str3, boolean z, String str4) {
        this.zzgkv = str;
        this.zzegt = str2;
        this.zzgkw = str3;
        this.zzgkx = z;
        this.zzgky = str4;
    }

    public String toString() {
        return String.format("Permission ID: '%s', Display Name: '%s', Picture URL: '%s', Authenticated User: %b, Email: '%s'", new Object[]{this.zzgkv, this.zzegt, this.zzgkw, Boolean.valueOf(this.zzgkx), this.zzgky});
    }

    public void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzgkv, false);
        zzbfp.zza(parcel, 3, this.zzegt, false);
        zzbfp.zza(parcel, 4, this.zzgkw, false);
        zzbfp.zza(parcel, 5, this.zzgkx);
        zzbfp.zza(parcel, 6, this.zzgky, false);
        zzbfp.zzai(parcel, i);
    }
}
