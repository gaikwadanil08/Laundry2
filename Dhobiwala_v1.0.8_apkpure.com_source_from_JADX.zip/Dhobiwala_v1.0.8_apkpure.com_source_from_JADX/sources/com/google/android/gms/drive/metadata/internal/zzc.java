package com.google.android.gms.drive.metadata.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.zzbg;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.drive.metadata.CustomPropertyKey;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.Arrays;

public final class zzc extends zzbfm {
    public static final Creator<zzc> CREATOR = new zzd();
    final String mValue;
    final CustomPropertyKey zzgse;

    public zzc(CustomPropertyKey customPropertyKey, String str) {
        zzbq.checkNotNull(customPropertyKey, "key");
        this.zzgse = customPropertyKey;
        this.mValue = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        zzc zzc = (zzc) obj;
        return zzbg.equal(this.zzgse, zzc.zzgse) && zzbg.equal(this.mValue, zzc.mValue);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.zzgse, this.mValue});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzgse, i, false);
        zzbfp.zza(parcel, 3, this.mValue, false);
        zzbfp.zzai(parcel, zze);
    }
}
