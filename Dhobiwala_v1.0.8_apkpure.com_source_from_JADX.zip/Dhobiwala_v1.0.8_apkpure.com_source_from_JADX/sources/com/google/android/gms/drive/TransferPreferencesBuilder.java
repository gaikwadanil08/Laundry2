package com.google.android.gms.drive;

import java.util.Arrays;

public class TransferPreferencesBuilder {
    public static final TransferPreferences DEFAULT_PREFERENCES = new zza(1, true, 256);
    private int zzgks;
    private boolean zzgkt;
    private int zzgku;

    static class zza implements TransferPreferences {
        private final int zzgks;
        private final boolean zzgkt;
        private final int zzgku;

        zza(int i, boolean z, int i2) {
            this.zzgks = i;
            this.zzgkt = z;
            this.zzgku = i2;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            zza zza = (zza) obj;
            return zza.zzgks == this.zzgks && zza.zzgkt == this.zzgkt && zza.zzgku == this.zzgku;
        }

        public final int getBatteryUsagePreference() {
            return this.zzgku;
        }

        public final int getNetworkPreference() {
            return this.zzgks;
        }

        public final int hashCode() {
            return Arrays.hashCode(new Object[]{Integer.valueOf(this.zzgks), Boolean.valueOf(this.zzgkt), Integer.valueOf(this.zzgku)});
        }

        public final boolean isRoamingAllowed() {
            return this.zzgkt;
        }

        public final String toString() {
            return String.format("NetworkPreference: %s, IsRoamingAllowed %s, BatteryUsagePreference %s", new Object[]{Integer.valueOf(this.zzgks), Boolean.valueOf(this.zzgkt), Integer.valueOf(this.zzgku)});
        }
    }

    public TransferPreferencesBuilder() {
        this(DEFAULT_PREFERENCES);
    }

    public TransferPreferencesBuilder(FileUploadPreferences fileUploadPreferences) {
        this.zzgks = fileUploadPreferences.getNetworkTypePreference();
        this.zzgkt = fileUploadPreferences.isRoamingAllowed();
        this.zzgku = fileUploadPreferences.getBatteryUsagePreference();
    }

    public TransferPreferencesBuilder(TransferPreferences transferPreferences) {
        this.zzgks = transferPreferences.getNetworkPreference();
        this.zzgkt = transferPreferences.isRoamingAllowed();
        this.zzgku = transferPreferences.getBatteryUsagePreference();
    }

    public TransferPreferences build() {
        return new zza(this.zzgks, this.zzgkt, this.zzgku);
    }

    public TransferPreferencesBuilder setBatteryUsagePreference(int i) {
        this.zzgku = i;
        return this;
    }

    public TransferPreferencesBuilder setIsRoamingAllowed(boolean z) {
        this.zzgkt = z;
        return this;
    }

    public TransferPreferencesBuilder setNetworkPreference(int i) {
        this.zzgks = i;
        return this;
    }
}
