package com.google.android.gms.drive.metadata.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ParentDriveIdSet extends zzbfm implements ReflectedParcelable {
    public static final Creator<ParentDriveIdSet> CREATOR = new zzn();
    final List<zzq> zzgsj;

    public ParentDriveIdSet() {
        this(new ArrayList());
    }

    ParentDriveIdSet(List<zzq> list) {
        this.zzgsj = list;
    }

    public void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zzc(parcel, 2, this.zzgsj, false);
        zzbfp.zzai(parcel, i);
    }

    public final Set<DriveId> zzab(long j) {
        Set<DriveId> hashSet = new HashSet();
        for (zzq zzq : this.zzgsj) {
            hashSet.add(new DriveId(zzq.zzgjk, zzq.zzgjl, j, zzq.zzgjm));
        }
        return hashSet;
    }
}
