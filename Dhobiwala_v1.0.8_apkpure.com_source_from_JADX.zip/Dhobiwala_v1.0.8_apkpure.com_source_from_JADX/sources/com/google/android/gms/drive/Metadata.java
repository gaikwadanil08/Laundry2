package com.google.android.gms.drive;

import com.google.android.gms.common.data.Freezable;
import com.google.android.gms.drive.metadata.CustomPropertyKey;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.AppVisibleCustomProperties;
import com.google.android.gms.internal.zzbth;
import com.google.android.gms.internal.zzbtu;
import com.google.android.gms.internal.zzbuc;
import java.util.Collections;
import java.util.Date;
import java.util.Map;

public abstract class Metadata implements Freezable<Metadata> {
    public static final int CONTENT_AVAILABLE_LOCALLY = 1;
    public static final int CONTENT_NOT_AVAILABLE_LOCALLY = 0;

    public String getAlternateLink() {
        return (String) zza(zzbth.zzgsm);
    }

    public int getContentAvailability() {
        Integer num = (Integer) zza(zzbuc.zzguk);
        return num == null ? 0 : num.intValue();
    }

    public Date getCreatedDate() {
        return (Date) zza(zzbtu.zzgud);
    }

    public Map<CustomPropertyKey, String> getCustomProperties() {
        AppVisibleCustomProperties appVisibleCustomProperties = (AppVisibleCustomProperties) zza(zzbth.zzgsn);
        return appVisibleCustomProperties == null ? Collections.emptyMap() : appVisibleCustomProperties.zzapl();
    }

    public String getDescription() {
        return (String) zza(zzbth.zzgso);
    }

    public DriveId getDriveId() {
        return (DriveId) zza(zzbth.zzgsl);
    }

    public String getEmbedLink() {
        return (String) zza(zzbth.zzgsp);
    }

    public String getFileExtension() {
        return (String) zza(zzbth.zzgsq);
    }

    public long getFileSize() {
        return ((Long) zza(zzbth.zzgsr)).longValue();
    }

    public Date getLastViewedByMeDate() {
        return (Date) zza(zzbtu.zzgue);
    }

    public String getMimeType() {
        return (String) zza(zzbth.zzgti);
    }

    public Date getModifiedByMeDate() {
        return (Date) zza(zzbtu.zzgug);
    }

    public Date getModifiedDate() {
        return (Date) zza(zzbtu.zzguf);
    }

    public String getOriginalFilename() {
        return (String) zza(zzbth.zzgtj);
    }

    public long getQuotaBytesUsed() {
        return ((Long) zza(zzbth.zzgto)).longValue();
    }

    public Date getSharedWithMeDate() {
        return (Date) zza(zzbtu.zzguh);
    }

    public String getTitle() {
        return (String) zza(zzbth.zzgtr);
    }

    public String getWebContentLink() {
        return (String) zza(zzbth.zzgtt);
    }

    public String getWebViewLink() {
        return (String) zza(zzbth.zzgtu);
    }

    public boolean isEditable() {
        Boolean bool = (Boolean) zza(zzbth.zzgsx);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isExplicitlyTrashed() {
        Boolean bool = (Boolean) zza(zzbth.zzgsy);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isFolder() {
        return DriveFolder.MIME_TYPE.equals(getMimeType());
    }

    public boolean isInAppFolder() {
        Boolean bool = (Boolean) zza(zzbth.zzgsv);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isPinnable() {
        Boolean bool = (Boolean) zza(zzbuc.zzgul);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isPinned() {
        Boolean bool = (Boolean) zza(zzbth.zzgta);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isRestricted() {
        Boolean bool = (Boolean) zza(zzbth.zzgtc);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isShared() {
        Boolean bool = (Boolean) zza(zzbth.zzgtd);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isStarred() {
        Boolean bool = (Boolean) zza(zzbth.zzgtp);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isTrashable() {
        Boolean bool = (Boolean) zza(zzbth.zzgtg);
        return bool == null ? true : bool.booleanValue();
    }

    public boolean isTrashed() {
        Boolean bool = (Boolean) zza(zzbth.zzgts);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isViewed() {
        Boolean bool = (Boolean) zza(zzbth.zzgth);
        return bool == null ? false : bool.booleanValue();
    }

    public abstract <T> T zza(MetadataField<T> metadataField);
}
