package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.drive.query.Filter;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;

public class FilterHolder extends zzbfm implements ReflectedParcelable {
    public static final Creator<FilterHolder> CREATOR = new zzh();
    private final Filter zzgkg;
    private zzb<?> zzgvc;
    private zzd zzgvd;
    private zzr zzgve;
    private zzv zzgvf;
    private zzp<?> zzgvg;
    private zzt zzgvh;
    private zzn zzgvi;
    private zzl zzgvj;
    private zzz zzgvk;

    public FilterHolder(Filter filter) {
        zzbq.checkNotNull(filter, "Null filter.");
        zzz zzz = null;
        this.zzgvc = filter instanceof zzb ? (zzb) filter : null;
        this.zzgvd = filter instanceof zzd ? (zzd) filter : null;
        this.zzgve = filter instanceof zzr ? (zzr) filter : null;
        this.zzgvf = filter instanceof zzv ? (zzv) filter : null;
        this.zzgvg = filter instanceof zzp ? (zzp) filter : null;
        this.zzgvh = filter instanceof zzt ? (zzt) filter : null;
        this.zzgvi = filter instanceof zzn ? (zzn) filter : null;
        this.zzgvj = filter instanceof zzl ? (zzl) filter : null;
        if (filter instanceof zzz) {
            zzz = (zzz) filter;
        }
        this.zzgvk = zzz;
        if (this.zzgvc == null && this.zzgvd == null && this.zzgve == null && this.zzgvf == null && this.zzgvg == null && this.zzgvh == null && this.zzgvi == null && this.zzgvj == null && this.zzgvk == null) {
            throw new IllegalArgumentException("Invalid filter type.");
        }
        this.zzgkg = filter;
    }

    FilterHolder(zzb<?> zzb, zzd zzd, zzr zzr, zzv zzv, zzp<?> zzp, zzt zzt, zzn<?> zzn, zzl zzl, zzz zzz) {
        Filter filter;
        this.zzgvc = zzb;
        this.zzgvd = zzd;
        this.zzgve = zzr;
        this.zzgvf = zzv;
        this.zzgvg = zzp;
        this.zzgvh = zzt;
        this.zzgvi = zzn;
        this.zzgvj = zzl;
        this.zzgvk = zzz;
        if (this.zzgvc != null) {
            filter = this.zzgvc;
        } else if (this.zzgvd != null) {
            filter = this.zzgvd;
        } else if (this.zzgve != null) {
            filter = this.zzgve;
        } else if (this.zzgvf != null) {
            filter = this.zzgvf;
        } else if (this.zzgvg != null) {
            filter = this.zzgvg;
        } else if (this.zzgvh != null) {
            filter = this.zzgvh;
        } else if (this.zzgvi != null) {
            filter = this.zzgvi;
        } else if (this.zzgvj != null) {
            filter = this.zzgvj;
        } else if (this.zzgvk != null) {
            filter = this.zzgvk;
        } else {
            throw new IllegalArgumentException("At least one filter must be set.");
        }
        this.zzgkg = filter;
    }

    public final Filter getFilter() {
        return this.zzgkg;
    }

    public String toString() {
        return String.format("FilterHolder[%s]", new Object[]{this.zzgkg});
    }

    public void writeToParcel(Parcel parcel, int i) {
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 1, this.zzgvc, i, false);
        zzbfp.zza(parcel, 2, this.zzgvd, i, false);
        zzbfp.zza(parcel, 3, this.zzgve, i, false);
        zzbfp.zza(parcel, 4, this.zzgvf, i, false);
        zzbfp.zza(parcel, 5, this.zzgvg, i, false);
        zzbfp.zza(parcel, 6, this.zzgvh, i, false);
        zzbfp.zza(parcel, 7, this.zzgvi, i, false);
        zzbfp.zza(parcel, 8, this.zzgvj, i, false);
        zzbfp.zza(parcel, 9, this.zzgvk, i, false);
        zzbfp.zzai(parcel, zze);
    }
}
