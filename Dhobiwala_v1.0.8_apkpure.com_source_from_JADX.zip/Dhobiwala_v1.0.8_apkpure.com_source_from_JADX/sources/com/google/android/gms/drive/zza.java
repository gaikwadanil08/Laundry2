package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.Base64;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import com.google.android.gms.internal.zzbte;
import com.google.android.gms.internal.zzfjs;

public class zza extends zzbfm {
    public static final Creator<zza> CREATOR = new zzb();
    private long zzgim;
    private long zzgin;
    private long zzgio;
    private volatile String zzgip = null;

    public zza(long j, long j2, long j3) {
        boolean z = false;
        zzbq.checkArgument(j != -1);
        zzbq.checkArgument(j2 != -1);
        if (j3 != -1) {
            z = true;
        }
        zzbq.checkArgument(z);
        this.zzgim = j;
        this.zzgin = j2;
        this.zzgio = j3;
    }

    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != zza.class) {
            return false;
        }
        zza zza = (zza) obj;
        if (zza.zzgin == this.zzgin && zza.zzgio == this.zzgio && zza.zzgim == this.zzgim) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String valueOf = String.valueOf(this.zzgim);
        String valueOf2 = String.valueOf(this.zzgin);
        String valueOf3 = String.valueOf(this.zzgio);
        StringBuilder stringBuilder = new StringBuilder((String.valueOf(valueOf).length() + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length());
        stringBuilder.append(valueOf);
        stringBuilder.append(valueOf2);
        stringBuilder.append(valueOf3);
        return stringBuilder.toString().hashCode();
    }

    public String toString() {
        if (this.zzgip == null) {
            zzfjs zzbte = new zzbte();
            zzbte.versionCode = 1;
            zzbte.sequenceNumber = this.zzgim;
            zzbte.zzgrr = this.zzgin;
            zzbte.zzgrs = this.zzgio;
            String encodeToString = Base64.encodeToString(zzfjs.zzc(zzbte), 10);
            String valueOf = String.valueOf("ChangeSequenceNumber:");
            encodeToString = String.valueOf(encodeToString);
            this.zzgip = encodeToString.length() != 0 ? valueOf.concat(encodeToString) : new String(valueOf);
        }
        return this.zzgip;
    }

    public void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzgim);
        zzbfp.zza(parcel, 3, this.zzgin);
        zzbfp.zza(parcel, 4, this.zzgio);
        zzbfp.zzai(parcel, i);
    }
}
