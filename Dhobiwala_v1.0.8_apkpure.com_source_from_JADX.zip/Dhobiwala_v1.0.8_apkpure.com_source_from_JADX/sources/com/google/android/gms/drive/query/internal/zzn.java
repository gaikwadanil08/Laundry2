package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.SearchableMetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.zzbfp;

public final class zzn<T> extends zza {
    public static final zzo CREATOR = new zzo();
    private MetadataBundle zzguz;
    private MetadataField<T> zzgva;

    public zzn(SearchableMetadataField<T> searchableMetadataField, T t) {
        this(MetadataBundle.zzb(searchableMetadataField, t));
    }

    zzn(MetadataBundle metadataBundle) {
        this.zzguz = metadataBundle;
        this.zzgva = zzi.zza(metadataBundle);
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 1, this.zzguz, i, false);
        zzbfp.zzai(parcel, zze);
    }

    public final <F> F zza(zzj<F> zzj) {
        return zzj.zzd(this.zzgva, this.zzguz.zza(this.zzgva));
    }
}
