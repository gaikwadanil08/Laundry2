package com.google.android.gms.drive;

import com.google.android.gms.drive.ExecutionOptions.Builder;

@Deprecated
public final class zzr extends ExecutionOptions {
    private boolean zzgjz;

    private zzr(String str, boolean z, int i, boolean z2) {
        super(str, z, i);
        this.zzgjz = z2;
    }

    public static zzr zzb(ExecutionOptions executionOptions) {
        Builder zzt = new zzt();
        if (executionOptions != null) {
            zzt.setConflictStrategy(executionOptions.zzaog());
            zzt.setNotifyOnCompletion(executionOptions.zzaof());
            String zzaoe = executionOptions.zzaoe();
            if (zzaoe != null) {
                zzt.setTrackingTag(zzaoe);
            }
        }
        return (zzr) zzt.build();
    }

    public final boolean zzaok() {
        return this.zzgjz;
    }
}
