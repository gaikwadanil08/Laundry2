package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.annotation.NonNull;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.drive.DriveSpace;
import com.google.android.gms.drive.query.internal.zzr;
import com.google.android.gms.drive.query.internal.zzt;
import com.google.android.gms.drive.query.internal.zzx;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class Query extends zzbfm {
    public static final Creator<Query> CREATOR = new zzb();
    private List<DriveSpace> zzgle;
    private final Set<DriveSpace> zzglf;
    private zzr zzgum;
    private String zzgun;
    private SortOrder zzguo;
    final List<String> zzgup;
    final boolean zzguq;
    final boolean zzgur;

    public static class Builder {
        private Set<DriveSpace> zzglf = Collections.emptySet();
        private String zzgun;
        private SortOrder zzguo;
        private List<String> zzgup;
        private boolean zzguq;
        private boolean zzgur;
        private final List<Filter> zzgus = new ArrayList();

        public Builder(Query query) {
            this.zzgus.add(query.getFilter());
            this.zzgun = query.getPageToken();
            this.zzguo = query.getSortOrder();
            this.zzgup = query.zzgup != null ? query.zzgup : Collections.emptyList();
            this.zzguq = query.zzguq;
            this.zzglf = query.zzapt() != null ? query.zzapt() : Collections.emptySet();
            this.zzgur = query.zzgur;
        }

        public Builder addFilter(@NonNull Filter filter) {
            zzbq.checkNotNull(filter, "Filter may not be null.");
            if (!(filter instanceof zzt)) {
                this.zzgus.add(filter);
            }
            return this;
        }

        public Query build() {
            return new Query(new zzr(zzx.zzgvu, this.zzgus), this.zzgun, this.zzguo, this.zzgup, this.zzguq, this.zzglf, this.zzgur);
        }

        @Deprecated
        public Builder setPageToken(String str) {
            this.zzgun = str;
            return this;
        }

        public Builder setSortOrder(SortOrder sortOrder) {
            this.zzguo = sortOrder;
            return this;
        }
    }

    private Query(zzr zzr, String str, SortOrder sortOrder, @NonNull List<String> list, boolean z, @NonNull List<DriveSpace> list2, Set<DriveSpace> set, boolean z2) {
        this.zzgum = zzr;
        this.zzgun = str;
        this.zzguo = sortOrder;
        this.zzgup = list;
        this.zzguq = z;
        this.zzgle = list2;
        this.zzglf = set;
        this.zzgur = z2;
    }

    Query(zzr zzr, String str, SortOrder sortOrder, @NonNull List<String> list, boolean z, @NonNull List<DriveSpace> list2, boolean z2) {
        List list3 = list2;
        this(zzr, str, sortOrder, (List) list, z, list3, list3 == null ? Collections.emptySet() : new HashSet(list3), z2);
    }

    private Query(zzr zzr, String str, SortOrder sortOrder, List<String> list, boolean z, Set<DriveSpace> set, boolean z2) {
        Set set2 = set;
        this(zzr, str, sortOrder, (List) list, z, set2 == null ? Collections.emptyList() : new ArrayList(set2), set2, z2);
    }

    public Filter getFilter() {
        return this.zzgum;
    }

    @Deprecated
    public String getPageToken() {
        return this.zzgun;
    }

    public SortOrder getSortOrder() {
        return this.zzguo;
    }

    public String toString() {
        return String.format(Locale.US, "Query[%s,%s,PageToken=%s,Spaces=%s]", new Object[]{this.zzgum, this.zzguo, this.zzgun, this.zzgle});
    }

    public void writeToParcel(Parcel parcel, int i) {
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 1, this.zzgum, i, false);
        zzbfp.zza(parcel, 3, this.zzgun, false);
        zzbfp.zza(parcel, 4, this.zzguo, i, false);
        zzbfp.zzb(parcel, 5, this.zzgup, false);
        zzbfp.zza(parcel, 6, this.zzguq);
        zzbfp.zzc(parcel, 7, this.zzgle, false);
        zzbfp.zza(parcel, 8, this.zzgur);
        zzbfp.zzai(parcel, zze);
    }

    public final Set<DriveSpace> zzapt() {
        return this.zzglf;
    }
}
