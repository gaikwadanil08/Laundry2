package com.google.android.gms.drive.events;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import com.google.android.gms.common.internal.zzal;
import com.google.android.gms.common.util.zzx;
import com.google.android.gms.internal.zzbqn;
import com.google.android.gms.internal.zzbrd;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class DriveEventService extends Service implements ChangeListener, CompletionListener, zzd, zzi {
    public static final String ACTION_HANDLE_EVENT = "com.google.android.gms.drive.events.HANDLE_EVENT";
    private static final zzal zzgjj = new zzal("DriveEventService", "");
    private final String mName;
    private CountDownLatch zzglo;
    zza zzglp;
    boolean zzglq;
    private int zzglr;

    final class zza extends Handler {
        private /* synthetic */ DriveEventService zzglt;

        zza(DriveEventService driveEventService) {
            this.zzglt = driveEventService;
        }

        private final Message zzaot() {
            return obtainMessage(2);
        }

        private final Message zzb(zzbrd zzbrd) {
            return obtainMessage(1, zzbrd);
        }

        public final void handleMessage(Message message) {
            DriveEventService.zzgjj.zzb("DriveEventService", "handleMessage message type: %s", Integer.valueOf(message.what));
            switch (message.what) {
                case 1:
                    this.zzglt.zza((zzbrd) message.obj);
                    return;
                case 2:
                    getLooper().quit();
                    return;
                default:
                    DriveEventService.zzgjj.zzc("DriveEventService", "Unexpected message type: %s", Integer.valueOf(message.what));
                    return;
            }
        }
    }

    final class zzb extends zzbqn {
        private /* synthetic */ DriveEventService zzglt;

        zzb(DriveEventService driveEventService) {
            this.zzglt = driveEventService;
        }

        public final void zzc(zzbrd zzbrd) throws RemoteException {
            synchronized (this.zzglt) {
                DriveEventService.zzgjj.zzb("DriveEventService", "onEvent: %s", zzbrd);
                this.zzglt.zzaor();
                if (this.zzglt.zzglp != null) {
                    this.zzglt.zzglp.sendMessage(this.zzglt.zzglp.zzb(zzbrd));
                } else {
                    DriveEventService.zzgjj.zzw("DriveEventService", "Receiving event before initialize is completed.");
                }
            }
        }
    }

    protected DriveEventService() {
        this(DriveEventService.class.getSimpleName());
    }

    protected DriveEventService(String str) {
        this.zzglq = false;
        this.zzglr = -1;
        this.mName = str;
    }

    private final void zza(zzbrd zzbrd) {
        DriveEvent zzapg = zzbrd.zzapg();
        zzgjj.zzb("DriveEventService", "handleEventMessage: %s", zzapg);
        try {
            int type = zzapg.getType();
            if (type == 4) {
                zza((zzb) zzapg);
            } else if (type != 7) {
                switch (type) {
                    case 1:
                        onChange((ChangeEvent) zzapg);
                        return;
                    case 2:
                        onCompletion((CompletionEvent) zzapg);
                        return;
                    default:
                        zzgjj.zzc("DriveEventService", "Unhandled event: %s", zzapg);
                        return;
                }
            } else {
                zzr zzr = (zzr) zzapg;
                zzgjj.zzc("DriveEventService", "Unhandled transfer state event in %s: %s", this.mName, zzr);
            }
        } catch (Throwable e) {
            zzgjj.zzd("DriveEventService", String.format("Error handling event in %s", new Object[]{this.mName}), e);
        }
    }

    private final void zzaor() throws SecurityException {
        int callingUid = getCallingUid();
        if (callingUid != this.zzglr) {
            if (zzx.zzf(this, callingUid)) {
                this.zzglr = callingUid;
                return;
            }
            throw new SecurityException("Caller is not GooglePlayServices");
        }
    }

    protected int getCallingUid() {
        return Binder.getCallingUid();
    }

    public final synchronized IBinder onBind(Intent intent) {
        if (!ACTION_HANDLE_EVENT.equals(intent.getAction())) {
            return null;
        }
        if (this.zzglp == null && !this.zzglq) {
            this.zzglq = true;
            CountDownLatch countDownLatch = new CountDownLatch(1);
            this.zzglo = new CountDownLatch(1);
            new zzh(this, countDownLatch).start();
            try {
                if (!countDownLatch.await(5000, TimeUnit.MILLISECONDS)) {
                    zzgjj.zzw("DriveEventService", "Failed to synchronously initialize event handler.");
                }
            } catch (Throwable e) {
                throw new RuntimeException("Unable to start event handler", e);
            }
        }
        return new zzb(this).asBinder();
    }

    public void onChange(ChangeEvent changeEvent) {
        zzgjj.zzc("DriveEventService", "Unhandled change event in %s: %s", this.mName, changeEvent);
    }

    public void onCompletion(CompletionEvent completionEvent) {
        zzgjj.zzc("DriveEventService", "Unhandled completion event in %s: %s", this.mName, completionEvent);
    }

    public synchronized void onDestroy() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
        /*
        r5 = this;
        monitor-enter(r5);
        r0 = zzgjj;	 Catch:{ all -> 0x0038 }
        r1 = "DriveEventService";	 Catch:{ all -> 0x0038 }
        r2 = "onDestroy";	 Catch:{ all -> 0x0038 }
        r0.zzu(r1, r2);	 Catch:{ all -> 0x0038 }
        r0 = r5.zzglp;	 Catch:{ all -> 0x0038 }
        if (r0 == 0) goto L_0x0033;	 Catch:{ all -> 0x0038 }
    L_0x000e:
        r0 = r5.zzglp;	 Catch:{ all -> 0x0038 }
        r0 = r0.zzaot();	 Catch:{ all -> 0x0038 }
        r1 = r5.zzglp;	 Catch:{ all -> 0x0038 }
        r1.sendMessage(r0);	 Catch:{ all -> 0x0038 }
        r0 = 0;	 Catch:{ all -> 0x0038 }
        r5.zzglp = r0;	 Catch:{ all -> 0x0038 }
        r1 = r5.zzglo;	 Catch:{ InterruptedException -> 0x0031 }
        r2 = 5000; // 0x1388 float:7.006E-42 double:2.4703E-320;	 Catch:{ InterruptedException -> 0x0031 }
        r4 = java.util.concurrent.TimeUnit.MILLISECONDS;	 Catch:{ InterruptedException -> 0x0031 }
        r1 = r1.await(r2, r4);	 Catch:{ InterruptedException -> 0x0031 }
        if (r1 != 0) goto L_0x0031;	 Catch:{ InterruptedException -> 0x0031 }
    L_0x0028:
        r1 = zzgjj;	 Catch:{ InterruptedException -> 0x0031 }
        r2 = "DriveEventService";	 Catch:{ InterruptedException -> 0x0031 }
        r3 = "Failed to synchronously quit event handler. Will quit itself";	 Catch:{ InterruptedException -> 0x0031 }
        r1.zzv(r2, r3);	 Catch:{ InterruptedException -> 0x0031 }
    L_0x0031:
        r5.zzglo = r0;	 Catch:{ all -> 0x0038 }
    L_0x0033:
        super.onDestroy();	 Catch:{ all -> 0x0038 }
        monitor-exit(r5);
        return;
    L_0x0038:
        r0 = move-exception;
        monitor-exit(r5);
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.drive.events.DriveEventService.onDestroy():void");
    }

    public boolean onUnbind(Intent intent) {
        return true;
    }

    public final void zza(zzb zzb) {
        zzgjj.zzc("DriveEventService", "Unhandled changes available event in %s: %s", this.mName, zzb);
    }
}
