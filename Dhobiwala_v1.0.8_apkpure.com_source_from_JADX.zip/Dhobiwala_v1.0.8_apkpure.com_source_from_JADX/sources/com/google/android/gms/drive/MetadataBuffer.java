package com.google.android.gms.drive;

import com.google.android.gms.common.data.AbstractDataBuffer;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.drive.metadata.internal.zzf;
import com.google.android.gms.internal.zzbln;
import com.google.android.gms.internal.zzbth;

public final class MetadataBuffer extends AbstractDataBuffer<Metadata> {
    private zza zzgka;

    static class zza extends Metadata {
        private final DataHolder zzfqt;
        private final int zzfvy;
        private final int zzgkb;

        public zza(DataHolder dataHolder, int i) {
            this.zzfqt = dataHolder;
            this.zzgkb = i;
            this.zzfvy = dataHolder.zzbz(i);
        }

        public final /* synthetic */ Object freeze() {
            MetadataBundle zzapp = MetadataBundle.zzapp();
            for (MetadataField metadataField : zzf.zzapn()) {
                if (metadataField != zzbth.zzgtq) {
                    metadataField.zza(this.zzfqt, zzapp, this.zzgkb, this.zzfvy);
                }
            }
            return new zzbln(zzapp);
        }

        public final boolean isDataValid() {
            return !this.zzfqt.isClosed();
        }

        public final <T> T zza(MetadataField<T> metadataField) {
            return metadataField.zza(this.zzfqt, this.zzgkb, this.zzfvy);
        }
    }

    public MetadataBuffer(DataHolder dataHolder) {
        super(dataHolder);
        dataHolder.zzagk().setClassLoader(MetadataBuffer.class.getClassLoader());
    }

    public final Metadata get(int i) {
        zza zza = this.zzgka;
        if (zza != null && zza.zzgkb == i) {
            return zza;
        }
        Metadata zza2 = new zza(this.zzfqt, i);
        this.zzgka = zza2;
        return zza2;
    }

    @Deprecated
    public final String getNextPageToken() {
        return null;
    }

    public final void release() {
        if (this.zzfqt != null) {
            zzf.zzb(this.zzfqt);
        }
        super.release();
    }
}
