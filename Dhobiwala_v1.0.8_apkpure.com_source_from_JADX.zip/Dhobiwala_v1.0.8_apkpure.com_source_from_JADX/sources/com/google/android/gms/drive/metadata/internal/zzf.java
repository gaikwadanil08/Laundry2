package com.google.android.gms.drive.metadata.internal;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.zzbth;
import com.google.android.gms.internal.zzbts;
import com.google.android.gms.internal.zzbtu;
import com.google.android.gms.internal.zzbuc;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class zzf {
    private static final Map<String, MetadataField<?>> zzgsf = new HashMap();
    private static final Map<String, zzg> zzgsg = new HashMap();

    static {
        zzb(zzbth.zzgsl);
        zzb(zzbth.zzgtr);
        zzb(zzbth.zzgti);
        zzb(zzbth.zzgtp);
        zzb(zzbth.zzgts);
        zzb(zzbth.zzgsy);
        zzb(zzbth.zzgsx);
        zzb(zzbth.zzgsz);
        zzb(zzbth.zzgta);
        zzb(zzbth.zzgtb);
        zzb(zzbth.zzgsv);
        zzb(zzbth.zzgtd);
        zzb(zzbth.zzgte);
        zzb(zzbth.zzgtf);
        zzb(zzbth.zzgtn);
        zzb(zzbth.zzgsm);
        zzb(zzbth.zzgtk);
        zzb(zzbth.zzgso);
        zzb(zzbth.zzgsw);
        zzb(zzbth.zzgsp);
        zzb(zzbth.zzgsq);
        zzb(zzbth.zzgsr);
        zzb(zzbth.zzgss);
        zzb(zzbth.zzgth);
        zzb(zzbth.zzgtc);
        zzb(zzbth.zzgtj);
        zzb(zzbth.zzgtl);
        zzb(zzbth.zzgtm);
        zzb(zzbth.zzgto);
        zzb(zzbth.zzgtt);
        zzb(zzbth.zzgtu);
        zzb(zzbth.zzgsu);
        zzb(zzbth.zzgst);
        zzb(zzbth.zzgtq);
        zzb(zzbth.zzgtg);
        zzb(zzbth.zzgsn);
        zzb(zzbth.zzgtv);
        zzb(zzbth.zzgtw);
        zzb(zzbth.zzgtx);
        zzb(zzbth.zzgty);
        zzb(zzbth.zzgtz);
        zzb(zzbth.zzgua);
        zzb(zzbth.zzgub);
        zzb(zzbtu.zzgud);
        zzb(zzbtu.zzguf);
        zzb(zzbtu.zzgug);
        zzb(zzbtu.zzguh);
        zzb(zzbtu.zzgue);
        zzb(zzbtu.zzgui);
        zzb(zzbuc.zzguk);
        zzb(zzbuc.zzgul);
        zza(zzo.zzgsk);
        zza(zzbts.zzguc);
    }

    private static void zza(zzg zzg) {
        if (zzgsg.put(zzg.zzapo(), zzg) != null) {
            String zzapo = zzg.zzapo();
            StringBuilder stringBuilder = new StringBuilder(46 + String.valueOf(zzapo).length());
            stringBuilder.append("A cleaner for key ");
            stringBuilder.append(zzapo);
            stringBuilder.append(" has already been registered");
            throw new IllegalStateException(stringBuilder.toString());
        }
    }

    public static Collection<MetadataField<?>> zzapn() {
        return Collections.unmodifiableCollection(zzgsf.values());
    }

    public static void zzb(DataHolder dataHolder) {
        for (zzg zzc : zzgsg.values()) {
            zzc.zzc(dataHolder);
        }
    }

    private static void zzb(MetadataField<?> metadataField) {
        if (zzgsf.containsKey(metadataField.getName())) {
            String str = "Duplicate field name registered: ";
            String valueOf = String.valueOf(metadataField.getName());
            throw new IllegalArgumentException(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        }
        zzgsf.put(metadataField.getName(), metadataField);
    }

    public static MetadataField<?> zzgx(String str) {
        return (MetadataField) zzgsf.get(str);
    }
}
