package com.google.android.gms.drive;

import com.google.android.gms.drive.ExecutionOptions.Builder;

@Deprecated
public final class zzo extends ExecutionOptions {
    private String zzgjx;
    private String zzgjy;

    private zzo(String str, boolean z, String str2, String str3, int i) {
        super(str, z, i);
        this.zzgjx = str2;
        this.zzgjy = str3;
    }

    public static zzo zza(ExecutionOptions executionOptions) {
        Builder zzq = new zzq();
        if (executionOptions != null) {
            if (executionOptions.zzaog() != 0) {
                throw new IllegalStateException("May not set a conflict strategy for new file creation.");
            }
            String zzaoe = executionOptions.zzaoe();
            if (zzaoe != null) {
                zzq.setTrackingTag(zzaoe);
            }
            zzq.setNotifyOnCompletion(executionOptions.zzaof());
        }
        return (zzo) zzq.build();
    }

    public final String zzaoi() {
        return this.zzgjx;
    }

    public final String zzaoj() {
        return this.zzgjy;
    }
}
