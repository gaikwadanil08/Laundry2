package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.SearchableCollectionMetadataField;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public final class zzo extends zzl<DriveId> implements SearchableCollectionMetadataField<DriveId> {
    public static final zzg zzgsk = new zzp();

    public zzo(int i) {
        super("parents", Collections.emptySet(), Arrays.asList(new String[]{"parentsExtra", "dbInstanceId", "parentsExtraHolder"}), 4100000);
    }

    private static void zzd(DataHolder dataHolder) {
        Bundle zzagk = dataHolder.zzagk();
        if (zzagk != null) {
            synchronized (dataHolder) {
                DataHolder dataHolder2 = (DataHolder) zzagk.getParcelable("parentsExtraHolder");
                if (dataHolder2 != null) {
                    dataHolder2.close();
                    zzagk.remove("parentsExtraHolder");
                }
            }
        }
    }

    protected final /* synthetic */ Object zzc(DataHolder dataHolder, int i, int i2) {
        return zzd(dataHolder, i, i2);
    }

    protected final Collection<DriveId> zzd(DataHolder dataHolder, int i, int i2) {
        DataHolder dataHolder2 = dataHolder;
        Bundle zzagk = dataHolder.zzagk();
        List parcelableArrayList = zzagk.getParcelableArrayList("parentsExtra");
        if (parcelableArrayList == null) {
            if (zzagk.getParcelable("parentsExtraHolder") != null) {
                synchronized (dataHolder) {
                    DataHolder dataHolder3;
                    try {
                        dataHolder3 = (DataHolder) dataHolder.zzagk().getParcelable("parentsExtraHolder");
                        if (dataHolder3 != null) {
                            int count = dataHolder.getCount();
                            ArrayList arrayList = new ArrayList(count);
                            Map hashMap = new HashMap(count);
                            int i3 = 0;
                            for (int i4 = 0; i4 < count; i4++) {
                                int zzbz = dataHolder2.zzbz(i4);
                                ParentDriveIdSet parentDriveIdSet = new ParentDriveIdSet();
                                arrayList.add(parentDriveIdSet);
                                hashMap.put(Long.valueOf(dataHolder2.zzb("sqlId", i4, zzbz)), parentDriveIdSet);
                            }
                            Bundle zzagk2 = dataHolder3.zzagk();
                            String string = zzagk2.getString("childSqlIdColumn");
                            String string2 = zzagk2.getString("parentSqlIdColumn");
                            String string3 = zzagk2.getString("parentResIdColumn");
                            int count2 = dataHolder3.getCount();
                            while (i3 < count2) {
                                int zzbz2 = dataHolder3.zzbz(i3);
                                ParentDriveIdSet parentDriveIdSet2 = (ParentDriveIdSet) hashMap.get(Long.valueOf(dataHolder3.zzb(string, i3, zzbz2)));
                                int i5 = count2;
                                String str = string3;
                                parentDriveIdSet2.zzgsj.add(new zzq(dataHolder3.zzd(string3, i3, zzbz2), dataHolder3.zzb(string2, i3, zzbz2), 1));
                                i3++;
                                count2 = i5;
                                string3 = str;
                            }
                            dataHolder.zzagk().putParcelableArrayList("parentsExtra", arrayList);
                            dataHolder3.close();
                            dataHolder.zzagk().remove("parentsExtraHolder");
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                parcelableArrayList = zzagk.getParcelableArrayList("parentsExtra");
            }
            if (parcelableArrayList == null) {
                return null;
            }
        }
        return ((ParentDriveIdSet) parcelableArrayList.get(i)).zzab(zzagk.getLong("dbInstanceId"));
    }

    protected final /* synthetic */ Object zzn(Bundle bundle) {
        return zzo(bundle);
    }

    protected final Collection<DriveId> zzo(Bundle bundle) {
        Collection zzo = super.zzo(bundle);
        return zzo == null ? null : new HashSet(zzo);
    }
}
