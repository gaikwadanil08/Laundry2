package com.google.android.gms.drive.events;

import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.data.BitmapTeleporter;
import com.google.android.gms.common.internal.zzal;
import com.google.android.gms.common.util.zzn;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import com.google.android.gms.internal.zzbqp;
import com.google.android.gms.internal.zzbth;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class CompletionEvent extends zzbfm implements ResourceEvent {
    public static final Creator<CompletionEvent> CREATOR = new zzg();
    public static final int STATUS_CANCELED = 3;
    public static final int STATUS_CONFLICT = 2;
    public static final int STATUS_FAILURE = 1;
    public static final int STATUS_SUCCESS = 0;
    private static final zzal zzgjj = new zzal("CompletionEvent", "");
    private int zzcbc;
    private String zzebv;
    private DriveId zzgis;
    private ParcelFileDescriptor zzglg;
    private ParcelFileDescriptor zzglh;
    private MetadataBundle zzgli;
    private List<String> zzglj;
    private IBinder zzglk;
    private boolean zzgll = false;
    private boolean zzglm = false;
    private boolean zzgln = false;

    CompletionEvent(DriveId driveId, String str, ParcelFileDescriptor parcelFileDescriptor, ParcelFileDescriptor parcelFileDescriptor2, MetadataBundle metadataBundle, List<String> list, int i, IBinder iBinder) {
        this.zzgis = driveId;
        this.zzebv = str;
        this.zzglg = parcelFileDescriptor;
        this.zzglh = parcelFileDescriptor2;
        this.zzgli = metadataBundle;
        this.zzglj = list;
        this.zzcbc = i;
        this.zzglk = iBinder;
    }

    private final void zzab(boolean z) {
        zzaoq();
        this.zzgln = true;
        zzn.zza(this.zzglg);
        zzn.zza(this.zzglh);
        if (this.zzgli != null && this.zzgli.zzd(zzbth.zzgtq)) {
            ((BitmapTeleporter) this.zzgli.zza(zzbth.zzgtq)).release();
        }
        if (this.zzglk == null) {
            String str = z ? "snooze" : "dismiss";
            zzgjj.zzd("CompletionEvent", "No callback on %s", str);
            return;
        }
        try {
            zzbqp.zzao(this.zzglk).zzab(z);
        } catch (Throwable e) {
            str = z ? "snooze" : "dismiss";
            zzgjj.zzd("CompletionEvent", String.format("RemoteException on %s", new Object[]{str}), e);
        }
    }

    private final void zzaoq() {
        if (this.zzgln) {
            throw new IllegalStateException("Event has already been dismissed or snoozed.");
        }
    }

    public final void dismiss() {
        zzab(false);
    }

    public final String getAccountName() {
        zzaoq();
        return this.zzebv;
    }

    public final InputStream getBaseContentsInputStream() {
        zzaoq();
        if (this.zzglg == null) {
            return null;
        }
        if (this.zzgll) {
            throw new IllegalStateException("getBaseInputStream() can only be called once per CompletionEvent instance.");
        }
        this.zzgll = true;
        return new FileInputStream(this.zzglg.getFileDescriptor());
    }

    public final DriveId getDriveId() {
        zzaoq();
        return this.zzgis;
    }

    public final InputStream getModifiedContentsInputStream() {
        zzaoq();
        if (this.zzglh == null) {
            return null;
        }
        if (this.zzglm) {
            throw new IllegalStateException("getModifiedInputStream() can only be called once per CompletionEvent instance.");
        }
        this.zzglm = true;
        return new FileInputStream(this.zzglh.getFileDescriptor());
    }

    public final MetadataChangeSet getModifiedMetadataChangeSet() {
        zzaoq();
        return this.zzgli != null ? new MetadataChangeSet(this.zzgli) : null;
    }

    public final int getStatus() {
        zzaoq();
        return this.zzcbc;
    }

    public final List<String> getTrackingTags() {
        zzaoq();
        return new ArrayList(this.zzglj);
    }

    public final int getType() {
        return 2;
    }

    public final void snooze() {
        zzab(true);
    }

    public final String toString() {
        String str;
        if (this.zzglj == null) {
            str = "<null>";
        } else {
            str = TextUtils.join("','", this.zzglj);
            StringBuilder stringBuilder = new StringBuilder(String.valueOf(str).length() + 2);
            stringBuilder.append("'");
            stringBuilder.append(str);
            stringBuilder.append("'");
            str = stringBuilder.toString();
        }
        return String.format(Locale.US, "CompletionEvent [id=%s, status=%s, trackingTag=%s]", new Object[]{this.zzgis, Integer.valueOf(this.zzcbc), str});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i |= 1;
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzgis, i, false);
        zzbfp.zza(parcel, 3, this.zzebv, false);
        zzbfp.zza(parcel, 4, this.zzglg, i, false);
        zzbfp.zza(parcel, 5, this.zzglh, i, false);
        zzbfp.zza(parcel, 6, this.zzgli, i, false);
        zzbfp.zzb(parcel, 7, this.zzglj, false);
        zzbfp.zzc(parcel, 8, this.zzcbc);
        zzbfp.zza(parcel, 9, this.zzglk, false);
        zzbfp.zzai(parcel, zze);
    }
}
