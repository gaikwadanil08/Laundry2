package com.google.android.gms.drive;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.HasGoogleSignInAccountOptions;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.ApiOptions.Optional;
import com.google.android.gms.common.api.Api.zzf;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.zzbg;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.internal.zzbls;
import com.google.android.gms.internal.zzbmo;
import com.google.android.gms.internal.zzbmt;
import com.google.android.gms.internal.zzbnh;
import com.google.android.gms.internal.zzbnr;
import com.google.android.gms.internal.zzbnx;
import com.google.android.gms.internal.zzbpv;
import java.util.Arrays;
import java.util.Set;

public final class Drive {
    @Deprecated
    public static final Api<NoOptions> API = new Api("Drive.API", zzebg, zzebf);
    @Deprecated
    public static final DriveApi DriveApi = new zzbls();
    @Deprecated
    public static final DrivePreferencesApi DrivePreferencesApi = new zzbnr();
    public static final Scope SCOPE_APPFOLDER = new Scope(Scopes.DRIVE_APPFOLDER);
    public static final Scope SCOPE_FILE = new Scope(Scopes.DRIVE_FILE);
    public static final zzf<zzbmo> zzebf = new zzf();
    private static final com.google.android.gms.common.api.Api.zza<zzbmo, NoOptions> zzebg = new zzf();
    private static final com.google.android.gms.common.api.Api.zza<zzbmo, zzb> zzgix = new zzg();
    private static final com.google.android.gms.common.api.Api.zza<zzbmo, zza> zzgiy = new zzh();
    private static Scope zzgiz = new Scope("https://www.googleapis.com/auth/drive");
    private static Scope zzgja = new Scope("https://www.googleapis.com/auth/drive.apps");
    private static Api<zzb> zzgjb = new Api("Drive.INTERNAL_API", zzgix, zzebf);
    public static final Api<zza> zzgjc = new Api("Drive.API_CONNECTIONLESS", zzgiy, zzebf);
    private static zzk zzgjd = new zzbnh();
    private static zzm zzgje = new zzbpv();

    public static class zza implements HasGoogleSignInAccountOptions {
        private final Bundle zzgjf = new Bundle();
        private final GoogleSignInAccount zzgjg;

        public zza(@NonNull GoogleSignInAccount googleSignInAccount) {
            this.zzgjg = googleSignInAccount;
        }

        public final boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (obj == null || obj.getClass() != getClass()) {
                return false;
            }
            zza zza = (zza) obj;
            if (!zzbg.equal(this.zzgjg, zza.getGoogleSignInAccount())) {
                return false;
            }
            String string = this.zzgjf.getString("method_trace_filename");
            String string2 = zza.zzgjf.getString("method_trace_filename");
            return ((string == null && string2 == null) || !(string == null || string2 == null || !string.equals(string2))) && this.zzgjf.getBoolean("bypass_initial_sync") == zza.zzgjf.getBoolean("bypass_initial_sync") && this.zzgjf.getInt("proxy_type") == zza.zzgjf.getInt("proxy_type");
        }

        public final GoogleSignInAccount getGoogleSignInAccount() {
            return this.zzgjg;
        }

        public final int hashCode() {
            String string = this.zzgjf.getString("method_trace_filename", "");
            int i = this.zzgjf.getInt("proxy_type");
            boolean z = this.zzgjf.getBoolean("bypass_initial_sync");
            return Arrays.hashCode(new Object[]{this.zzgjg, string, Integer.valueOf(i), Boolean.valueOf(z)});
        }

        public final Bundle zzanz() {
            return this.zzgjf;
        }
    }

    public static class zzb implements Optional {
    }

    private Drive() {
    }

    public static DriveClient getDriveClient(@NonNull Activity activity, @NonNull GoogleSignInAccount googleSignInAccount) {
        zza(googleSignInAccount);
        return new zzbmt(activity, new zza(googleSignInAccount));
    }

    public static DriveClient getDriveClient(@NonNull Context context, @NonNull GoogleSignInAccount googleSignInAccount) {
        zza(googleSignInAccount);
        return new zzbmt(context, new zza(googleSignInAccount));
    }

    public static DriveResourceClient getDriveResourceClient(@NonNull Activity activity, @NonNull GoogleSignInAccount googleSignInAccount) {
        zza(googleSignInAccount);
        return new zzbnx(activity, new zza(googleSignInAccount));
    }

    public static DriveResourceClient getDriveResourceClient(@NonNull Context context, @NonNull GoogleSignInAccount googleSignInAccount) {
        zza(googleSignInAccount);
        return new zzbnx(context, new zza(googleSignInAccount));
    }

    private static void zza(GoogleSignInAccount googleSignInAccount) {
        boolean z;
        zzbq.checkNotNull(googleSignInAccount);
        Set zzabb = googleSignInAccount.zzabb();
        if (!(zzabb.contains(SCOPE_FILE) || zzabb.contains(SCOPE_APPFOLDER) || zzabb.contains(zzgiz))) {
            if (!zzabb.contains(zzgja)) {
                z = false;
                zzbq.checkArgument(z, "You must request a Drive scope in order to interact with the Drive API.");
            }
        }
        z = true;
        zzbq.checkArgument(z, "You must request a Drive scope in order to interact with the Drive API.");
    }
}
