package com.google.android.gms.drive;

import android.content.IntentSender;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.internal.zzblg;
import com.google.android.gms.internal.zzbmy;

@Deprecated
public class CreateFileActivityBuilder {
    public static final String EXTRA_RESPONSE_DRIVE_ID = "response_drive_id";
    private final zzblg zzgiu = new zzblg(0);
    private DriveContents zzgiv;
    private boolean zzgiw;

    public IntentSender build(GoogleApiClient googleApiClient) {
        zzbq.zza(googleApiClient.isConnected(), (Object) "Client must be connected");
        zzany();
        return this.zzgiu.build(googleApiClient);
    }

    final int getRequestId() {
        return this.zzgiu.getRequestId();
    }

    public CreateFileActivityBuilder setActivityStartFolder(DriveId driveId) {
        this.zzgiu.zza(driveId);
        return this;
    }

    public CreateFileActivityBuilder setActivityTitle(String str) {
        this.zzgiu.setActivityTitle(str);
        return this;
    }

    public CreateFileActivityBuilder setInitialDriveContents(DriveContents driveContents) {
        if (driveContents == null) {
            this.zzgiu.zzct(1);
        } else if (!(driveContents instanceof zzbmy)) {
            throw new IllegalArgumentException("Only DriveContents obtained from the Drive API are accepted.");
        } else if (driveContents.getDriveId() != null) {
            throw new IllegalArgumentException("Only DriveContents obtained through DriveApi.newDriveContents are accepted for file creation.");
        } else if (driveContents.zzaod()) {
            throw new IllegalArgumentException("DriveContents are already closed.");
        } else {
            this.zzgiu.zzct(driveContents.zzaob().zzgiq);
            this.zzgiv = driveContents;
        }
        this.zzgiw = true;
        return this;
    }

    public CreateFileActivityBuilder setInitialMetadata(MetadataChangeSet metadataChangeSet) {
        this.zzgiu.zza(metadataChangeSet);
        return this;
    }

    final MetadataChangeSet zzanu() {
        return this.zzgiu.zzanu();
    }

    final DriveId zzanv() {
        return this.zzgiu.zzanv();
    }

    final String zzanw() {
        return this.zzgiu.zzanw();
    }

    final int zzanx() {
        zzblg zzblg = this.zzgiu;
        return 0;
    }

    final void zzany() {
        zzbq.zza(this.zzgiw, (Object) "Must call setInitialDriveContents.");
        if (this.zzgiv != null) {
            this.zzgiv.zzaoc();
        }
        this.zzgiu.zzany();
    }
}
