package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.zzbg;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.Arrays;
import java.util.Locale;

public final class zzp extends zzbfm {
    public static final Creator<zzp> CREATOR = new zzq();
    private int zzglx;

    public zzp(int i) {
        this.zzglx = i;
    }

    public final boolean equals(Object obj) {
        if (obj != null) {
            if (obj.getClass() == getClass()) {
                if (obj == this) {
                    return true;
                }
                return zzbg.equal(Integer.valueOf(this.zzglx), Integer.valueOf(((zzp) obj).zzglx));
            }
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.zzglx)});
    }

    public final String toString() {
        return String.format(Locale.US, "TransferProgressOptions[type=%d]", new Object[]{Integer.valueOf(this.zzglx)});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zzc(parcel, 2, this.zzglx);
        zzbfp.zzai(parcel, i);
    }
}
