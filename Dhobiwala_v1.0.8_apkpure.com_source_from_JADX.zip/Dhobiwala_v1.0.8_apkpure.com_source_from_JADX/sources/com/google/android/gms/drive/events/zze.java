package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.annotation.NonNull;
import com.google.android.gms.common.internal.zzbg;
import com.google.android.gms.drive.DriveSpace;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class zze extends zzbfm {
    public static final Creator<zze> CREATOR = new zzf();
    private int zzeck;
    private int zzglc;
    private boolean zzgld;
    private List<DriveSpace> zzgle;
    private final Set<DriveSpace> zzglf;

    zze(int i, int i2, boolean z, List<DriveSpace> list) {
        this(i, i2, z, list, list == null ? null : new HashSet(list));
    }

    private zze(int i, int i2, boolean z, List<DriveSpace> list, @NonNull Set<DriveSpace> set) {
        this.zzeck = i;
        this.zzglc = i2;
        this.zzgld = z;
        this.zzgle = list;
        this.zzglf = set;
    }

    public final boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        zze zze = (zze) obj;
        return zzbg.equal(this.zzglf, zze.zzglf) && this.zzglc == zze.zzglc && this.zzgld == zze.zzgld;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.zzglf, Integer.valueOf(this.zzglc), Boolean.valueOf(this.zzgld)});
    }

    public final String toString() {
        return String.format(Locale.US, "ChangesAvailableOptions[ChangesSizeLimit=%d, Repeats=%s, Spaces=%s]", new Object[]{Integer.valueOf(this.zzglc), Boolean.valueOf(this.zzgld), this.zzgle});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zzc(parcel, 1, this.zzeck);
        zzbfp.zzc(parcel, 2, this.zzglc);
        zzbfp.zza(parcel, 3, this.zzgld);
        zzbfp.zzc(parcel, 4, this.zzgle, false);
        zzbfp.zzai(parcel, i);
    }
}
