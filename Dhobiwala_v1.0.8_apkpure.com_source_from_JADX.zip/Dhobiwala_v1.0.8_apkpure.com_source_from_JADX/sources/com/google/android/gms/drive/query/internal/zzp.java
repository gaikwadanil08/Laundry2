package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.drive.metadata.SearchableCollectionMetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.drive.metadata.zzb;
import com.google.android.gms.internal.zzbfp;
import java.util.Collection;
import java.util.Collections;

public final class zzp<T> extends zza {
    public static final zzq CREATOR = new zzq();
    private MetadataBundle zzguz;
    private final zzb<T> zzgvm;

    public zzp(SearchableCollectionMetadataField<T> searchableCollectionMetadataField, T t) {
        this(MetadataBundle.zzb(searchableCollectionMetadataField, Collections.singleton(t)));
    }

    zzp(MetadataBundle metadataBundle) {
        this.zzguz = metadataBundle;
        this.zzgvm = (zzb) zzi.zza(metadataBundle);
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 1, this.zzguz, i, false);
        zzbfp.zzai(parcel, zze);
    }

    public final <F> F zza(zzj<F> zzj) {
        return zzj.zza(this.zzgvm, ((Collection) this.zzguz.zza(this.zzgvm)).iterator().next());
    }
}
