package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.Base64;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.zzal;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import com.google.android.gms.internal.zzbnd;
import com.google.android.gms.internal.zzbni;
import com.google.android.gms.internal.zzbpj;
import com.google.android.gms.internal.zzbtf;
import com.google.android.gms.internal.zzbtg;
import com.google.android.gms.internal.zzfjs;

public class DriveId extends zzbfm implements ReflectedParcelable {
    public static final Creator<DriveId> CREATOR = new zzl();
    public static final int RESOURCE_TYPE_FILE = 0;
    public static final int RESOURCE_TYPE_FOLDER = 1;
    public static final int RESOURCE_TYPE_UNKNOWN = -1;
    private static final zzal zzgjj = new zzal("DriveId", "");
    private long zzgin;
    private volatile String zzgip = null;
    private String zzgjk;
    private long zzgjl;
    private int zzgjm;
    private volatile String zzgjn = null;

    public DriveId(String str, long j, long j2, int i) {
        this.zzgjk = str;
        boolean z = true;
        zzbq.checkArgument("".equals(str) ^ true);
        if (str == null) {
            if (j == -1) {
                z = false;
            }
        }
        zzbq.checkArgument(z);
        this.zzgjl = j;
        this.zzgin = j2;
        this.zzgjm = i;
    }

    public static DriveId decodeFromString(String str) {
        boolean startsWith = str.startsWith("DriveId:");
        String str2 = "Invalid DriveId: ";
        String valueOf = String.valueOf(str);
        zzbq.checkArgument(startsWith, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        return zzn(Base64.decode(str.substring(8), 10));
    }

    public static DriveId zzgv(String str) {
        zzbq.checkNotNull(str);
        return new DriveId(str, -1, -1, -1);
    }

    private static com.google.android.gms.drive.DriveId zzn(byte[] r8) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
        /*
        r0 = new com.google.android.gms.internal.zzbtf;	 Catch:{ zzfjr -> 0x0028 }
        r0.<init>();	 Catch:{ zzfjr -> 0x0028 }
        r8 = com.google.android.gms.internal.zzfjs.zza(r0, r8);	 Catch:{ zzfjr -> 0x0028 }
        r8 = (com.google.android.gms.internal.zzbtf) r8;	 Catch:{ zzfjr -> 0x0028 }
        r0 = "";
        r1 = r8.zzgrt;
        r0 = r0.equals(r1);
        if (r0 == 0) goto L_0x0018;
    L_0x0015:
        r0 = 0;
    L_0x0016:
        r2 = r0;
        goto L_0x001b;
    L_0x0018:
        r0 = r8.zzgrt;
        goto L_0x0016;
    L_0x001b:
        r0 = new com.google.android.gms.drive.DriveId;
        r3 = r8.zzgru;
        r5 = r8.zzgrr;
        r7 = r8.zzgrv;
        r1 = r0;
        r1.<init>(r2, r3, r5, r7);
        return r0;
    L_0x0028:
        r8 = new java.lang.IllegalArgumentException;
        r8.<init>();
        throw r8;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.drive.DriveId.zzn(byte[]):com.google.android.gms.drive.DriveId");
    }

    public DriveFile asDriveFile() {
        if (this.zzgjm != 1) {
            return new zzbnd(this);
        }
        throw new IllegalStateException("This DriveId corresponds to a folder. Call asDriveFolder instead.");
    }

    public DriveFolder asDriveFolder() {
        if (this.zzgjm != 0) {
            return new zzbni(this);
        }
        throw new IllegalStateException("This DriveId corresponds to a file. Call asDriveFile instead.");
    }

    public DriveResource asDriveResource() {
        return this.zzgjm == 1 ? asDriveFolder() : this.zzgjm == 0 ? asDriveFile() : new zzbpj(this);
    }

    public final String encodeToString() {
        if (this.zzgip == null) {
            zzfjs zzbtf = new zzbtf();
            zzbtf.versionCode = 1;
            zzbtf.zzgrt = this.zzgjk == null ? "" : this.zzgjk;
            zzbtf.zzgru = this.zzgjl;
            zzbtf.zzgrr = this.zzgin;
            zzbtf.zzgrv = this.zzgjm;
            String encodeToString = Base64.encodeToString(zzfjs.zzc(zzbtf), 10);
            String valueOf = String.valueOf("DriveId:");
            encodeToString = String.valueOf(encodeToString);
            this.zzgip = encodeToString.length() != 0 ? valueOf.concat(encodeToString) : new String(valueOf);
        }
        return this.zzgip;
    }

    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != DriveId.class) {
            return false;
        }
        DriveId driveId = (DriveId) obj;
        if (driveId.zzgin != this.zzgin) {
            return false;
        }
        if (driveId.zzgjl == -1 && this.zzgjl == -1) {
            return driveId.zzgjk.equals(this.zzgjk);
        }
        if (this.zzgjk != null) {
            if (driveId.zzgjk != null) {
                if (driveId.zzgjl == this.zzgjl) {
                    if (driveId.zzgjk.equals(this.zzgjk)) {
                        return true;
                    }
                    zzgjj.zzv("DriveId", "Unexpected unequal resourceId for same DriveId object.");
                }
                return false;
            }
        }
        return driveId.zzgjl == this.zzgjl;
    }

    public String getResourceId() {
        return this.zzgjk;
    }

    public int getResourceType() {
        return this.zzgjm;
    }

    public int hashCode() {
        if (this.zzgjl == -1) {
            return this.zzgjk.hashCode();
        }
        String valueOf = String.valueOf(String.valueOf(this.zzgin));
        String valueOf2 = String.valueOf(String.valueOf(this.zzgjl));
        return (valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf)).hashCode();
    }

    public final String toInvariantString() {
        if (this.zzgjn == null) {
            zzfjs zzbtg = new zzbtg();
            zzbtg.zzgru = this.zzgjl;
            zzbtg.zzgrr = this.zzgin;
            this.zzgjn = Base64.encodeToString(zzfjs.zzc(zzbtg), 10);
        }
        return this.zzgjn;
    }

    public String toString() {
        return encodeToString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzgjk, false);
        zzbfp.zza(parcel, 3, this.zzgjl);
        zzbfp.zza(parcel, 4, this.zzgin);
        zzbfp.zzc(parcel, 5, this.zzgjm);
        zzbfp.zzai(parcel, i);
    }
}
