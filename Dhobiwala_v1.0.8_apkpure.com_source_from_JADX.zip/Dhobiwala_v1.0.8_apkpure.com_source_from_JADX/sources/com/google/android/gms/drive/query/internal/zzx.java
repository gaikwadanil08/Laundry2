package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;

public final class zzx extends zzbfm {
    public static final Creator<zzx> CREATOR = new zzy();
    public static final zzx zzgvp = new zzx("=");
    public static final zzx zzgvq = new zzx("<");
    public static final zzx zzgvr = new zzx("<=");
    public static final zzx zzgvs = new zzx(">");
    public static final zzx zzgvt = new zzx(">=");
    public static final zzx zzgvu = new zzx("and");
    public static final zzx zzgvv = new zzx("or");
    private static zzx zzgvw = new zzx("not");
    public static final zzx zzgvx = new zzx("contains");
    private String mTag;

    zzx(String str) {
        this.mTag = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        zzx zzx = (zzx) obj;
        if (this.mTag == null) {
            if (zzx.mTag != null) {
                return false;
            }
        } else if (!this.mTag.equals(zzx.mTag)) {
            return false;
        }
        return true;
    }

    public final String getTag() {
        return this.mTag;
    }

    public final int hashCode() {
        return 31 + (this.mTag == null ? 0 : this.mTag.hashCode());
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 1, this.mTag, false);
        zzbfp.zzai(parcel, i);
    }
}
