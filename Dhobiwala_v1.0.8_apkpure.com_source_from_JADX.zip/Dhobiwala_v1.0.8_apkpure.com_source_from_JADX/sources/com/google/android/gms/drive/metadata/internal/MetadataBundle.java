package com.google.android.gms.drive.metadata.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.BitmapTeleporter;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.zzal;
import com.google.android.gms.common.internal.zzbg;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import com.google.android.gms.internal.zzbth;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public final class MetadataBundle extends zzbfm implements ReflectedParcelable {
    public static final Creator<MetadataBundle> CREATOR = new zzj();
    private static final zzal zzgjj = new zzal("MetadataBundle", "");
    private Bundle zzgsh;

    MetadataBundle(Bundle bundle) {
        this.zzgsh = (Bundle) zzbq.checkNotNull(bundle);
        this.zzgsh.setClassLoader(getClass().getClassLoader());
        List arrayList = new ArrayList();
        Iterator it = this.zzgsh.keySet().iterator();
        while (true) {
            int i = 0;
            if (!it.hasNext()) {
                break;
            }
            String str = (String) it.next();
            if (zzf.zzgx(str) == null) {
                arrayList.add(str);
                zzgjj.zzc("MetadataBundle", "Ignored unknown metadata field in bundle: %s", str);
            }
        }
        ArrayList arrayList2 = (ArrayList) arrayList;
        int size = arrayList2.size();
        while (i < size) {
            Object obj = arrayList2.get(i);
            i++;
            this.zzgsh.remove((String) obj);
        }
    }

    public static MetadataBundle zzapp() {
        return new MetadataBundle(new Bundle());
    }

    public static <T> MetadataBundle zzb(MetadataField<T> metadataField, T t) {
        MetadataBundle zzapp = zzapp();
        zzapp.zzc(metadataField, t);
        return zzapp;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        MetadataBundle metadataBundle = (MetadataBundle) obj;
        Set<String> keySet = this.zzgsh.keySet();
        if (!keySet.equals(metadataBundle.zzgsh.keySet())) {
            return false;
        }
        for (String str : keySet) {
            if (!zzbg.equal(this.zzgsh.get(str), metadataBundle.zzgsh.get(str))) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int i = 1;
        for (String str : this.zzgsh.keySet()) {
            i = (i * 31) + this.zzgsh.get(str).hashCode();
        }
        return i;
    }

    public final void setContext(Context context) {
        BitmapTeleporter bitmapTeleporter = (BitmapTeleporter) zza(zzbth.zzgtq);
        if (bitmapTeleporter != null) {
            bitmapTeleporter.setTempDir(context.getCacheDir());
        }
    }

    public final String toString() {
        String valueOf = String.valueOf(this.zzgsh);
        StringBuilder stringBuilder = new StringBuilder(24 + String.valueOf(valueOf).length());
        stringBuilder.append("MetadataBundle [values=");
        stringBuilder.append(valueOf);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzgsh, false);
        zzbfp.zzai(parcel, i);
    }

    public final <T> T zza(MetadataField<T> metadataField) {
        return metadataField.zzm(this.zzgsh);
    }

    public final MetadataBundle zzapq() {
        return new MetadataBundle(new Bundle(this.zzgsh));
    }

    public final Set<MetadataField<?>> zzapr() {
        Set<MetadataField<?>> hashSet = new HashSet();
        for (String zzgx : this.zzgsh.keySet()) {
            hashSet.add(zzf.zzgx(zzgx));
        }
        return hashSet;
    }

    public final <T> T zzc(MetadataField<T> metadataField) {
        T zza = zza(metadataField);
        this.zzgsh.remove(metadataField.getName());
        return zza;
    }

    public final <T> void zzc(MetadataField<T> metadataField, T t) {
        if (zzf.zzgx(metadataField.getName()) == null) {
            String str = "Unregistered field: ";
            String valueOf = String.valueOf(metadataField.getName());
            throw new IllegalArgumentException(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        }
        metadataField.zza(t, this.zzgsh);
    }

    public final boolean zzd(MetadataField<?> metadataField) {
        return this.zzgsh.containsKey(metadataField.getName());
    }
}
