package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.zzy;
import com.google.android.gms.internal.zzbfp;

public final class zzl extends zzy implements DriveEvent {
    public static final Creator<zzl> CREATOR = new zzm();
    private DataHolder zzfqt;
    private boolean zzglu;
    private int zzglv;

    public zzl(DataHolder dataHolder, boolean z, int i) {
        this.zzfqt = dataHolder;
        this.zzglu = z;
        this.zzglv = i;
    }

    public final int getType() {
        return 3;
    }

    public final void zzaj(Parcel parcel, int i) {
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzfqt, i, false);
        zzbfp.zza(parcel, 3, this.zzglu);
        zzbfp.zzc(parcel, 4, this.zzglv);
        zzbfp.zzai(parcel, zze);
    }

    public final DataHolder zzaou() {
        return this.zzfqt;
    }

    public final boolean zzaov() {
        return this.zzglu;
    }

    public final int zzaow() {
        return this.zzglv;
    }
}
