package com.google.android.gms.drive.events;

import android.os.Looper;
import java.util.concurrent.CountDownLatch;

final class zzh extends Thread {
    private /* synthetic */ CountDownLatch zzgls;
    private /* synthetic */ DriveEventService zzglt;

    zzh(DriveEventService driveEventService, CountDownLatch countDownLatch) {
        this.zzglt = driveEventService;
        this.zzgls = countDownLatch;
    }

    public final void run() {
        try {
            Looper.prepare();
            this.zzglt.zzglp = new zza(this.zzglt);
            this.zzglt.zzglq = false;
            this.zzgls.countDown();
            DriveEventService.zzgjj.zzu("DriveEventService", "Bound and starting loop");
            Looper.loop();
            DriveEventService.zzgjj.zzu("DriveEventService", "Finished loop");
        } finally {
            if (this.zzglt.zzglo != null) {
                this.zzglt.zzglo.countDown();
            }
        }
    }
}
