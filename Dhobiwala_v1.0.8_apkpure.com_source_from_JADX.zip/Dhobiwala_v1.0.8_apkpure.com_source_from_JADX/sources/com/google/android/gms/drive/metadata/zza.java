package com.google.android.gms.drive.metadata;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public abstract class zza<T> implements MetadataField<T> {
    private final String zzgrw;
    private final Set<String> zzgrx;
    private final Set<String> zzgry;
    private final int zzgrz;

    protected zza(String str, int i) {
        this.zzgrw = (String) zzbq.checkNotNull(str, "fieldName");
        this.zzgrx = Collections.singleton(str);
        this.zzgry = Collections.emptySet();
        this.zzgrz = i;
    }

    protected zza(String str, Collection<String> collection, Collection<String> collection2, int i) {
        this.zzgrw = (String) zzbq.checkNotNull(str, "fieldName");
        this.zzgrx = Collections.unmodifiableSet(new HashSet(collection));
        this.zzgry = Collections.unmodifiableSet(new HashSet(collection2));
        this.zzgrz = i;
    }

    public final String getName() {
        return this.zzgrw;
    }

    public String toString() {
        return this.zzgrw;
    }

    public final T zza(DataHolder dataHolder, int i, int i2) {
        return zzb(dataHolder, i, i2) ? zzc(dataHolder, i, i2) : null;
    }

    protected abstract void zza(Bundle bundle, T t);

    public final void zza(DataHolder dataHolder, MetadataBundle metadataBundle, int i, int i2) {
        zzbq.checkNotNull(dataHolder, "dataHolder");
        zzbq.checkNotNull(metadataBundle, "bundle");
        if (zzb(dataHolder, i, i2)) {
            metadataBundle.zzc(this, zzc(dataHolder, i, i2));
        }
    }

    public final void zza(T t, Bundle bundle) {
        zzbq.checkNotNull(bundle, "bundle");
        if (t == null) {
            bundle.putString(this.zzgrw, null);
        } else {
            zza(bundle, (Object) t);
        }
    }

    public final Collection<String> zzapk() {
        return this.zzgrx;
    }

    protected boolean zzb(DataHolder dataHolder, int i, int i2) {
        for (String str : this.zzgrx) {
            if (dataHolder.zzga(str)) {
                if (dataHolder.zzh(str, i, i2)) {
                }
            }
            return false;
        }
        return true;
    }

    protected abstract T zzc(DataHolder dataHolder, int i, int i2);

    public final T zzm(Bundle bundle) {
        zzbq.checkNotNull(bundle, "bundle");
        return bundle.get(this.zzgrw) != null ? zzn(bundle) : null;
    }

    protected abstract T zzn(Bundle bundle);
}
