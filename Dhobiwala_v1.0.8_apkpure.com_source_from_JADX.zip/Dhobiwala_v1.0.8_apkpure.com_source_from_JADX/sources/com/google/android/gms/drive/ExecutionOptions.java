package com.google.android.gms.drive;

import android.text.TextUtils;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.internal.zzbg;
import com.google.android.gms.internal.zzbmo;
import java.util.Arrays;

public class ExecutionOptions {
    public static final int CONFLICT_STRATEGY_KEEP_REMOTE = 1;
    public static final int CONFLICT_STRATEGY_OVERWRITE_REMOTE = 0;
    public static final int MAX_TRACKING_TAG_STRING_LENGTH = 65536;
    private final String zzgju;
    private final boolean zzgjv;
    private final int zzgjw;

    public static class Builder {
        protected String zzgju;
        protected boolean zzgjv;
        protected int zzgjw = 0;

        public ExecutionOptions build() {
            zzaoh();
            return new ExecutionOptions(this.zzgju, this.zzgjv, this.zzgjw);
        }

        public Builder setConflictStrategy(int i) {
            Object obj;
            switch (i) {
                case 0:
                case 1:
                    obj = 1;
                    break;
                default:
                    obj = null;
                    break;
            }
            if (obj == null) {
                StringBuilder stringBuilder = new StringBuilder(53);
                stringBuilder.append("Unrecognized value for conflict strategy: ");
                stringBuilder.append(i);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            this.zzgjw = i;
            return this;
        }

        public Builder setNotifyOnCompletion(boolean z) {
            this.zzgjv = z;
            return this;
        }

        public Builder setTrackingTag(String str) {
            int i = (TextUtils.isEmpty(str) || str.length() > 65536) ? 0 : 1;
            if (i == 0) {
                throw new IllegalArgumentException(String.format("trackingTag must not be null nor empty, and the length must be <= the maximum length (%s)", new Object[]{Integer.valueOf(65536)}));
            }
            this.zzgju = str;
            return this;
        }

        protected final void zzaoh() {
            if (this.zzgjw == 1 && !this.zzgjv) {
                throw new IllegalStateException("Cannot use CONFLICT_STRATEGY_KEEP_REMOTE without requesting completion notifications");
            }
        }
    }

    public ExecutionOptions(String str, boolean z, int i) {
        this.zzgju = str;
        this.zzgjv = z;
        this.zzgjw = i;
    }

    public static boolean zzcr(int i) {
        return i == 1;
    }

    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        ExecutionOptions executionOptions = (ExecutionOptions) obj;
        return zzbg.equal(this.zzgju, executionOptions.zzgju) && this.zzgjw == executionOptions.zzgjw && this.zzgjv == executionOptions.zzgjv;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.zzgju, Integer.valueOf(this.zzgjw), Boolean.valueOf(this.zzgjv)});
    }

    public final void zza(zzbmo zzbmo) {
        if (this.zzgjv && !zzbmo.zzapc()) {
            throw new IllegalStateException("Application must define an exported DriveEventService subclass in AndroidManifest.xml to be notified on completion");
        }
    }

    public final String zzaoe() {
        return this.zzgju;
    }

    public final boolean zzaof() {
        return this.zzgjv;
    }

    public final int zzaog() {
        return this.zzgjw;
    }

    @Deprecated
    public final void zzf(GoogleApiClient googleApiClient) {
        zza((zzbmo) googleApiClient.zza(Drive.zzebf));
    }
}
