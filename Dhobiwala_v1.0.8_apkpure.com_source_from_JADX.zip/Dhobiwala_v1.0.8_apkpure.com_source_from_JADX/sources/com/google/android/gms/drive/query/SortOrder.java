package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.drive.metadata.SortableMetadataField;
import com.google.android.gms.drive.query.internal.zzf;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SortOrder extends zzbfm {
    public static final Creator<SortOrder> CREATOR = new zzc();
    private List<zzf> zzguv;
    private boolean zzguw;

    public static class Builder {
        private final List<zzf> zzguv = new ArrayList();
        private boolean zzguw = false;

        public Builder addSortAscending(SortableMetadataField sortableMetadataField) {
            this.zzguv.add(new zzf(sortableMetadataField.getName(), true));
            return this;
        }

        public Builder addSortDescending(SortableMetadataField sortableMetadataField) {
            this.zzguv.add(new zzf(sortableMetadataField.getName(), false));
            return this;
        }

        public SortOrder build() {
            return new SortOrder(this.zzguv, false);
        }
    }

    SortOrder(List<zzf> list, boolean z) {
        this.zzguv = list;
        this.zzguw = z;
    }

    public String toString() {
        return String.format(Locale.US, "SortOrder[%s, %s]", new Object[]{TextUtils.join(",", this.zzguv), Boolean.valueOf(this.zzguw)});
    }

    public void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zzc(parcel, 1, this.zzguv, false);
        zzbfp.zza(parcel, 2, this.zzguw);
        zzbfp.zzai(parcel, i);
    }
}
