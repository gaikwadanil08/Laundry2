package com.google.android.gms.analyticsservices.app.library.license;

/* renamed from: com.google.android.gms.analyticsservices.app.library.license.R */
public final class C0366R {
}
