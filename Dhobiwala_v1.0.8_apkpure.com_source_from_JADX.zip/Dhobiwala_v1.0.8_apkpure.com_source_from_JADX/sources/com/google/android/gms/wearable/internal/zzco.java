package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.internal.zzbo;
import com.google.android.gms.wearable.DataItemBuffer;

final /* synthetic */ class zzco implements zzbo {
    static final zzbo zzgnw = new zzco();

    private zzco() {
    }

    public final Object zzb(Result result) {
        return (DataItemBuffer) result;
    }
}
