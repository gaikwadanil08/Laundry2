package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.CapabilityClient.OnCapabilityChangedListener;
import com.google.android.gms.wearable.CapabilityInfo;

final class zzae implements OnCapabilityChangedListener {
    private String zzlin;
    private OnCapabilityChangedListener zzlis;

    zzae(OnCapabilityChangedListener onCapabilityChangedListener, String str) {
        this.zzlis = onCapabilityChangedListener;
        this.zzlin = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        zzae zzae = (zzae) obj;
        return !this.zzlis.equals(zzae.zzlis) ? false : this.zzlin.equals(zzae.zzlin);
    }

    public final int hashCode() {
        return (this.zzlis.hashCode() * 31) + this.zzlin.hashCode();
    }

    public final void onCapabilityChanged(CapabilityInfo capabilityInfo) {
        this.zzlis.onCapabilityChanged(capabilityInfo);
    }
}
