package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.internal.zzeu;
import com.google.android.gms.internal.zzew;
import com.google.android.gms.wearable.Asset;
import com.google.android.gms.wearable.PutDataRequest;

public final class zzeq extends zzeu implements zzep {
    zzeq(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.wearable.internal.IWearableService");
    }

    public final void zza(zzek zzek) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzb(8, zzbe);
    }

    public final void zza(zzek zzek, int i) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzbe.writeInt(i);
        zzb(43, zzbe);
    }

    public final void zza(zzek zzek, Uri uri) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzew.zza(zzbe, (Parcelable) uri);
        zzb(7, zzbe);
    }

    public final void zza(zzek zzek, Uri uri, int i) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzew.zza(zzbe, (Parcelable) uri);
        zzbe.writeInt(i);
        zzb(40, zzbe);
    }

    public final void zza(zzek zzek, Asset asset) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzew.zza(zzbe, (Parcelable) asset);
        zzb(13, zzbe);
    }

    public final void zza(zzek zzek, PutDataRequest putDataRequest) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzew.zza(zzbe, (Parcelable) putDataRequest);
        zzb(6, zzbe);
    }

    public final void zza(zzek zzek, zzd zzd) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzew.zza(zzbe, (Parcelable) zzd);
        zzb(16, zzbe);
    }

    public final void zza(zzek zzek, zzei zzei, String str) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzew.zza(zzbe, (IInterface) zzei);
        zzbe.writeString(str);
        zzb(34, zzbe);
    }

    public final void zza(zzek zzek, zzfw zzfw) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzew.zza(zzbe, (Parcelable) zzfw);
        zzb(17, zzbe);
    }

    public final void zza(zzek zzek, String str) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzbe.writeString(str);
        zzb(46, zzbe);
    }

    public final void zza(zzek zzek, String str, int i) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzbe.writeString(str);
        zzbe.writeInt(i);
        zzb(42, zzbe);
    }

    public final void zza(zzek zzek, String str, ParcelFileDescriptor parcelFileDescriptor) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzbe.writeString(str);
        zzew.zza(zzbe, (Parcelable) parcelFileDescriptor);
        zzb(38, zzbe);
    }

    public final void zza(zzek zzek, String str, ParcelFileDescriptor parcelFileDescriptor, long j, long j2) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzbe.writeString(str);
        zzew.zza(zzbe, (Parcelable) parcelFileDescriptor);
        zzbe.writeLong(j);
        zzbe.writeLong(j2);
        zzb(39, zzbe);
    }

    public final void zza(zzek zzek, String str, String str2) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzbe.writeString(str);
        zzbe.writeString(str2);
        zzb(31, zzbe);
    }

    public final void zza(zzek zzek, String str, String str2, byte[] bArr) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzbe.writeString(str);
        zzbe.writeString(str2);
        zzbe.writeByteArray(bArr);
        zzb(12, zzbe);
    }

    public final void zzb(zzek zzek) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzb(14, zzbe);
    }

    public final void zzb(zzek zzek, Uri uri, int i) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzew.zza(zzbe, (Parcelable) uri);
        zzbe.writeInt(i);
        zzb(41, zzbe);
    }

    public final void zzb(zzek zzek, zzei zzei, String str) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzew.zza(zzbe, (IInterface) zzei);
        zzbe.writeString(str);
        zzb(35, zzbe);
    }

    public final void zzb(zzek zzek, String str) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzbe.writeString(str);
        zzb(47, zzbe);
    }

    public final void zzb(zzek zzek, String str, int i) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzbe.writeString(str);
        zzbe.writeInt(i);
        zzb(33, zzbe);
    }

    public final void zzc(zzek zzek) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzb(15, zzbe);
    }

    public final void zzc(zzek zzek, String str) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (IInterface) zzek);
        zzbe.writeString(str);
        zzb(32, zzbe);
    }
}
