package com.google.android.gms.wearable.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.zzeu;
import com.google.android.gms.internal.zzew;
import java.util.List;

public final class zzeo extends zzeu implements zzem {
    zzeo(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.wearable.internal.IWearableListener");
    }

    public final void onConnectedNodes(List<zzfo> list) throws RemoteException {
        Parcel zzbe = zzbe();
        zzbe.writeTypedList(list);
        zzc(5, zzbe);
    }

    public final void zza(zzah zzah) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (Parcelable) zzah);
        zzc(8, zzbe);
    }

    public final void zza(zzaw zzaw) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (Parcelable) zzaw);
        zzc(7, zzbe);
    }

    public final void zza(zzfe zzfe) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (Parcelable) zzfe);
        zzc(2, zzbe);
    }

    public final void zza(zzfo zzfo) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (Parcelable) zzfo);
        zzc(3, zzbe);
    }

    public final void zza(zzi zzi) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (Parcelable) zzi);
        zzc(9, zzbe);
    }

    public final void zza(zzl zzl) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (Parcelable) zzl);
        zzc(6, zzbe);
    }

    public final void zzas(DataHolder dataHolder) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (Parcelable) dataHolder);
        zzc(1, zzbe);
    }

    public final void zzb(zzfo zzfo) throws RemoteException {
        Parcel zzbe = zzbe();
        zzew.zza(zzbe, (Parcelable) zzfo);
        zzc(4, zzbe);
    }
}
