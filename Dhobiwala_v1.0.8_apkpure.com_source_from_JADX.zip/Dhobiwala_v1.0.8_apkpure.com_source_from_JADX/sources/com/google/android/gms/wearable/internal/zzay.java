package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzbg;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import com.google.android.gms.wearable.Channel;
import com.google.android.gms.wearable.Channel.GetInputStreamResult;
import com.google.android.gms.wearable.Channel.GetOutputStreamResult;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;
import com.google.android.gms.wearable.ChannelClient;

public final class zzay extends zzbfm implements Channel, ChannelClient.Channel {
    public static final Creator<zzay> CREATOR = new zzbi();
    private final String mPath;
    private final String zzecl;
    private final String zzlgr;

    public zzay(String str, String str2, String str3) {
        this.zzecl = (String) zzbq.checkNotNull(str);
        this.zzlgr = (String) zzbq.checkNotNull(str2);
        this.mPath = (String) zzbq.checkNotNull(str3);
    }

    public final PendingResult<Status> addListener(GoogleApiClient googleApiClient, ChannelListener channelListener) {
        return zzb.zza(googleApiClient, new zzbf(this.zzecl, new IntentFilter[]{zzgj.zzny("com.google.android.gms.wearable.CHANNEL_EVENT")}), channelListener);
    }

    public final PendingResult<Status> close(GoogleApiClient googleApiClient) {
        return googleApiClient.zzd(new zzaz(this, googleApiClient));
    }

    public final PendingResult<Status> close(GoogleApiClient googleApiClient, int i) {
        return googleApiClient.zzd(new zzba(this, googleApiClient, i));
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzay)) {
            return false;
        }
        zzay zzay = (zzay) obj;
        return this.zzecl.equals(zzay.zzecl) && zzbg.equal(zzay.zzlgr, this.zzlgr) && zzbg.equal(zzay.mPath, this.mPath);
    }

    public final PendingResult<GetInputStreamResult> getInputStream(GoogleApiClient googleApiClient) {
        return googleApiClient.zzd(new zzbb(this, googleApiClient));
    }

    public final String getNodeId() {
        return this.zzlgr;
    }

    public final PendingResult<GetOutputStreamResult> getOutputStream(GoogleApiClient googleApiClient) {
        return googleApiClient.zzd(new zzbc(this, googleApiClient));
    }

    public final String getPath() {
        return this.mPath;
    }

    public final String getToken() {
        return this.zzecl;
    }

    public final int hashCode() {
        return this.zzecl.hashCode();
    }

    public final PendingResult<Status> receiveFile(GoogleApiClient googleApiClient, Uri uri, boolean z) {
        zzbq.checkNotNull(googleApiClient, "client is null");
        zzbq.checkNotNull(uri, "uri is null");
        return googleApiClient.zzd(new zzbd(this, googleApiClient, uri, z));
    }

    public final PendingResult<Status> removeListener(GoogleApiClient googleApiClient, ChannelListener channelListener) {
        zzbq.checkNotNull(googleApiClient, "client is null");
        zzbq.checkNotNull(channelListener, "listener is null");
        return googleApiClient.zzd(new zzan(googleApiClient, channelListener, this.zzecl));
    }

    public final PendingResult<Status> sendFile(GoogleApiClient googleApiClient, Uri uri) {
        return sendFile(googleApiClient, uri, 0, -1);
    }

    public final PendingResult<Status> sendFile(GoogleApiClient googleApiClient, Uri uri, long j, long j2) {
        boolean z;
        GoogleApiClient googleApiClient2 = googleApiClient;
        zzbq.checkNotNull(googleApiClient2, "client is null");
        zzbq.checkNotNull(this.zzecl, "token is null");
        Uri uri2 = uri;
        zzbq.checkNotNull(uri2, "uri is null");
        zzbq.zzb(j >= 0, "startOffset is negative: %s", new Object[]{Long.valueOf(j)});
        if (j2 < 0) {
            if (j2 != -1) {
                z = false;
                zzbq.zzb(z, "invalid length: %s", new Object[]{Long.valueOf(j2)});
                return googleApiClient2.zzd(new zzbe(r9, googleApiClient2, uri2, j, j2));
            }
        }
        z = true;
        zzbq.zzb(z, "invalid length: %s", new Object[]{Long.valueOf(j2)});
        return googleApiClient2.zzd(new zzbe(r9, googleApiClient2, uri2, j, j2));
    }

    public final String toString() {
        String substring;
        char[] toCharArray = this.zzecl.toCharArray();
        int i = 0;
        int i2 = i;
        while (i < toCharArray.length) {
            i2 += toCharArray[i];
            i++;
        }
        String trim = this.zzecl.trim();
        int length = trim.length();
        if (length > 25) {
            substring = trim.substring(0, 10);
            trim = trim.substring(length - 10, length);
            StringBuilder stringBuilder = new StringBuilder((16 + String.valueOf(substring).length()) + String.valueOf(trim).length());
            stringBuilder.append(substring);
            stringBuilder.append("...");
            stringBuilder.append(trim);
            stringBuilder.append("::");
            stringBuilder.append(i2);
            trim = stringBuilder.toString();
        }
        substring = this.zzlgr;
        String str = this.mPath;
        StringBuilder stringBuilder2 = new StringBuilder(((31 + String.valueOf(trim).length()) + String.valueOf(substring).length()) + String.valueOf(str).length());
        stringBuilder2.append("Channel{token=");
        stringBuilder2.append(trim);
        stringBuilder2.append(", nodeId=");
        stringBuilder2.append(substring);
        stringBuilder2.append(", path=");
        stringBuilder2.append(str);
        stringBuilder2.append("}");
        return stringBuilder2.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzecl, false);
        zzbfp.zza(parcel, 3, getNodeId(), false);
        zzbfp.zza(parcel, 4, getPath(), false);
        zzbfp.zzai(parcel, i);
    }
}
