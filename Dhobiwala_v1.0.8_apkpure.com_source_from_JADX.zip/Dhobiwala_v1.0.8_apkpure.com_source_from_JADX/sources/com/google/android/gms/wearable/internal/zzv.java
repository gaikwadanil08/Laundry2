package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.CapabilityApi.CapabilityListener;
import com.google.android.gms.wearable.CapabilityInfo;

final class zzv implements CapabilityListener {
    private CapabilityListener zzlim;
    private String zzlin;

    zzv(CapabilityListener capabilityListener, String str) {
        this.zzlim = capabilityListener;
        this.zzlin = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        zzv zzv = (zzv) obj;
        return !this.zzlim.equals(zzv.zzlim) ? false : this.zzlin.equals(zzv.zzlin);
    }

    public final int hashCode() {
        return (this.zzlim.hashCode() * 31) + this.zzlin.hashCode();
    }

    public final void onCapabilityChanged(CapabilityInfo capabilityInfo) {
        this.zzlim.onCapabilityChanged(capabilityInfo);
    }
}
