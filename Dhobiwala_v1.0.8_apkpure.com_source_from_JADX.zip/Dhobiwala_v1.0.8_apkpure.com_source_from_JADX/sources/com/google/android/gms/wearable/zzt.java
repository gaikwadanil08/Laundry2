package com.google.android.gms.wearable;

import com.google.android.gms.wearable.internal.zzaw;

final class zzt implements Runnable {
    private /* synthetic */ zzd zzlho;
    private /* synthetic */ zzaw zzlhv;

    zzt(zzd zzd, zzaw zzaw) {
        this.zzlho = zzd;
        this.zzlhv = zzaw;
    }

    public final void run() {
        this.zzlhv.zza(this.zzlho.zzlhk);
        this.zzlhv.zza(this.zzlho.zzlhk.zzlhj);
    }
}
