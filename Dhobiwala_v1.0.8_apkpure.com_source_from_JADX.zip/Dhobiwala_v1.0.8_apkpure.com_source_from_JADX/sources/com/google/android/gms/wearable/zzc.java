package com.google.android.gms.wearable;

@Deprecated
public interface zzc {
}
