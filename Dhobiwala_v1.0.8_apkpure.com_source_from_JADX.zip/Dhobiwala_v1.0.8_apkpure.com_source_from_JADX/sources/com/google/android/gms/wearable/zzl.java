package com.google.android.gms.wearable;

import com.google.android.gms.common.data.AbstractDataBuffer;
import com.google.android.gms.common.data.DataHolder;

final class zzl implements Runnable {
    private /* synthetic */ DataHolder zzlhn;
    private /* synthetic */ zzd zzlho;

    zzl(zzd zzd, DataHolder dataHolder) {
        this.zzlho = zzd;
        this.zzlhn = dataHolder;
    }

    public final void run() {
        AbstractDataBuffer dataEventBuffer = new DataEventBuffer(this.zzlhn);
        try {
            this.zzlho.zzlhk.onDataChanged(dataEventBuffer);
        } finally {
            dataEventBuffer.release();
        }
    }
}
