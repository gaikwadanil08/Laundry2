package com.google.android.gms.wearable;

import android.app.Activity;
import android.content.Context;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v4.util.Preconditions;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.Optional;
import com.google.android.gms.common.api.Api.zza;
import com.google.android.gms.common.api.Api.zzf;
import com.google.android.gms.common.api.GoogleApi;
import com.google.android.gms.common.api.zzd;
import com.google.android.gms.wearable.internal.zzaa;
import com.google.android.gms.wearable.internal.zzaj;
import com.google.android.gms.wearable.internal.zzao;
import com.google.android.gms.wearable.internal.zzbv;
import com.google.android.gms.wearable.internal.zzbw;
import com.google.android.gms.wearable.internal.zzcj;
import com.google.android.gms.wearable.internal.zzeu;
import com.google.android.gms.wearable.internal.zzez;
import com.google.android.gms.wearable.internal.zzfg;
import com.google.android.gms.wearable.internal.zzfl;
import com.google.android.gms.wearable.internal.zzgi;
import com.google.android.gms.wearable.internal.zzh;
import com.google.android.gms.wearable.internal.zzhg;
import com.google.android.gms.wearable.internal.zzhq;
import com.google.android.gms.wearable.internal.zzk;
import com.google.android.gms.wearable.internal.zzo;

public class Wearable {
    @Deprecated
    public static final Api<WearableOptions> API = new Api("Wearable.API", zzebg, zzebf);
    @Deprecated
    public static final CapabilityApi CapabilityApi = new zzo();
    @Deprecated
    public static final ChannelApi ChannelApi = new zzaj();
    @Deprecated
    public static final DataApi DataApi = new zzbw();
    @Deprecated
    public static final MessageApi MessageApi = new zzeu();
    @Deprecated
    public static final NodeApi NodeApi = new zzfg();
    private static final zzf<zzhg> zzebf = new zzf();
    private static final zza<zzhg, WearableOptions> zzebg = new zzj();
    @Deprecated
    private static zzc zzlgy = new zzk();
    @Deprecated
    private static zza zzlgz = new zzh();
    @Deprecated
    private static zzf zzlha = new zzbv();
    @Deprecated
    private static zzi zzlhb = new zzgi();
    @Deprecated
    private static zzu zzlhc = new zzhq();

    public static final class WearableOptions implements Optional {
        private final Looper zzfml;

        public static class Builder {
            private Looper zzfml;

            public WearableOptions build() {
                return new WearableOptions();
            }

            public Builder setLooper(Looper looper) {
                this.zzfml = looper;
                return this;
            }
        }

        private WearableOptions(Builder builder) {
            this.zzfml = builder.zzfml;
        }

        private final GoogleApi.zza zzbkd() {
            return this.zzfml != null ? new zzd().zza(this.zzfml).zzagq() : GoogleApi.zza.zzfmj;
        }
    }

    private Wearable() {
    }

    public static CapabilityClient getCapabilityClient(@NonNull Activity activity) {
        return new zzaa(activity, GoogleApi.zza.zzfmj);
    }

    public static CapabilityClient getCapabilityClient(@NonNull Activity activity, @NonNull WearableOptions wearableOptions) {
        Preconditions.checkNotNull(wearableOptions, "options must not be null");
        return new zzaa(activity, wearableOptions.zzbkd());
    }

    public static CapabilityClient getCapabilityClient(@NonNull Context context) {
        return new zzaa(context, GoogleApi.zza.zzfmj);
    }

    public static CapabilityClient getCapabilityClient(@NonNull Context context, @NonNull WearableOptions wearableOptions) {
        Preconditions.checkNotNull(wearableOptions, "options must not be null");
        return new zzaa(context, wearableOptions.zzbkd());
    }

    public static ChannelClient getChannelClient(@NonNull Activity activity) {
        return new zzao(activity, GoogleApi.zza.zzfmj);
    }

    public static ChannelClient getChannelClient(@NonNull Activity activity, @NonNull WearableOptions wearableOptions) {
        Preconditions.checkNotNull(wearableOptions, "options must not be null");
        return new zzao(activity, wearableOptions.zzbkd());
    }

    public static ChannelClient getChannelClient(@NonNull Context context) {
        return new zzao(context, GoogleApi.zza.zzfmj);
    }

    public static ChannelClient getChannelClient(@NonNull Context context, @NonNull WearableOptions wearableOptions) {
        Preconditions.checkNotNull(wearableOptions, "options must not be null");
        return new zzao(context, wearableOptions.zzbkd());
    }

    public static DataClient getDataClient(@NonNull Activity activity) {
        return new zzcj(activity, GoogleApi.zza.zzfmj);
    }

    public static DataClient getDataClient(@NonNull Activity activity, @NonNull WearableOptions wearableOptions) {
        Preconditions.checkNotNull(wearableOptions, "options must not be null");
        return new zzcj(activity, wearableOptions.zzbkd());
    }

    public static DataClient getDataClient(@NonNull Context context) {
        return new zzcj(context, GoogleApi.zza.zzfmj);
    }

    public static DataClient getDataClient(@NonNull Context context, @NonNull WearableOptions wearableOptions) {
        Preconditions.checkNotNull(wearableOptions, "options must not be null");
        return new zzcj(context, wearableOptions.zzbkd());
    }

    public static MessageClient getMessageClient(@NonNull Activity activity) {
        return new zzez(activity, GoogleApi.zza.zzfmj);
    }

    public static MessageClient getMessageClient(@NonNull Activity activity, @NonNull WearableOptions wearableOptions) {
        Preconditions.checkNotNull(wearableOptions, "options must not be null");
        return new zzez(activity, wearableOptions.zzbkd());
    }

    public static MessageClient getMessageClient(@NonNull Context context) {
        return new zzez(context, GoogleApi.zza.zzfmj);
    }

    public static MessageClient getMessageClient(@NonNull Context context, @NonNull WearableOptions wearableOptions) {
        Preconditions.checkNotNull(wearableOptions, "options must not be null");
        return new zzez(context, wearableOptions.zzbkd());
    }

    public static NodeClient getNodeClient(@NonNull Activity activity) {
        return new zzfl(activity, GoogleApi.zza.zzfmj);
    }

    public static NodeClient getNodeClient(@NonNull Activity activity, @NonNull WearableOptions wearableOptions) {
        Preconditions.checkNotNull(wearableOptions, "options must not be null");
        return new zzfl(activity, wearableOptions.zzbkd());
    }

    public static NodeClient getNodeClient(@NonNull Context context) {
        return new zzfl(context, GoogleApi.zza.zzfmj);
    }

    public static NodeClient getNodeClient(@NonNull Context context, @NonNull WearableOptions wearableOptions) {
        Preconditions.checkNotNull(wearableOptions, "options must not be null");
        return new zzfl(context, wearableOptions.zzbkd());
    }
}
