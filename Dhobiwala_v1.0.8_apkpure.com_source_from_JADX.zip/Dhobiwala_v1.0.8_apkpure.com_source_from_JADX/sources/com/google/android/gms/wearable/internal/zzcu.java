package com.google.android.gms.wearable.internal;

import android.os.ParcelFileDescriptor;
import com.google.android.gms.common.api.Releasable;
import com.google.android.gms.wearable.DataApi.GetFdForAssetResult;
import com.google.android.gms.wearable.DataClient.GetFdForAssetResponse;
import java.io.InputStream;

final class zzcu extends GetFdForAssetResponse implements Releasable {
    private final GetFdForAssetResult zzlka;

    zzcu(GetFdForAssetResult getFdForAssetResult) {
        this.zzlka = getFdForAssetResult;
    }

    public final ParcelFileDescriptor getFdForAsset() {
        return this.zzlka.getFd();
    }

    public final InputStream getInputStream() {
        return this.zzlka.getInputStream();
    }

    public final void release() {
        this.zzlka.release();
    }
}
