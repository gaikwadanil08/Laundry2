package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.DataItemAsset;

public final class zzcz implements DataItemAsset {
    private final String zzbhb;
    private final String zzbuz;

    public zzcz(DataItemAsset dataItemAsset) {
        this.zzbuz = dataItemAsset.getId();
        this.zzbhb = dataItemAsset.getDataItemKey();
    }

    public final /* bridge */ /* synthetic */ Object freeze() {
        if (this != null) {
            return this;
        }
        throw null;
    }

    public final String getDataItemKey() {
        return this.zzbhb;
    }

    public final String getId() {
        return this.zzbuz;
    }

    public final boolean isDataValid() {
        return true;
    }

    public final String toString() {
        String str;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DataItemAssetEntity[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        if (this.zzbuz == null) {
            str = ",noid";
        } else {
            stringBuilder.append(",");
            str = this.zzbuz;
        }
        stringBuilder.append(str);
        stringBuilder.append(", key=");
        stringBuilder.append(this.zzbhb);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
