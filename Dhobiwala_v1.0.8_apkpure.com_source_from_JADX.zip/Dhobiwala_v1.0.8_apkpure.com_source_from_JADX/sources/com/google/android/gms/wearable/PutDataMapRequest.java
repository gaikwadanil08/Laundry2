package com.google.android.gms.wearable;

import android.net.Uri;
import android.support.annotation.NonNull;
import android.util.Log;
import com.google.android.gms.common.internal.zzc;
import com.google.android.gms.internal.zzdlz;
import com.google.android.gms.internal.zzdma;
import com.google.android.gms.internal.zzfjs;

public class PutDataMapRequest {
    private final DataMap zzlgs = new DataMap();
    private final PutDataRequest zzlgt;

    private PutDataMapRequest(PutDataRequest putDataRequest, DataMap dataMap) {
        this.zzlgt = putDataRequest;
        if (dataMap != null) {
            this.zzlgs.putAll(dataMap);
        }
    }

    public static PutDataMapRequest create(@NonNull String str) {
        zzc.zzb(str, "path must not be null");
        return new PutDataMapRequest(PutDataRequest.create(str), null);
    }

    public static PutDataMapRequest createFromDataMapItem(@NonNull DataMapItem dataMapItem) {
        zzc.zzb(dataMapItem, "source must not be null");
        return new PutDataMapRequest(PutDataRequest.zzs(dataMapItem.getUri()), dataMapItem.getDataMap());
    }

    public static PutDataMapRequest createWithAutoAppendedId(@NonNull String str) {
        zzc.zzb(str, "pathPrefix must not be null");
        return new PutDataMapRequest(PutDataRequest.createWithAutoAppendedId(str), null);
    }

    public PutDataRequest asPutDataRequest() {
        zzdma zza = zzdlz.zza(this.zzlgs);
        this.zzlgt.setData(zzfjs.zzc(zza.zzlmg));
        int size = zza.zzlmh.size();
        int i = 0;
        while (i < size) {
            String num = Integer.toString(i);
            Asset asset = (Asset) zza.zzlmh.get(i);
            String valueOf;
            if (num == null) {
                valueOf = String.valueOf(asset);
                StringBuilder stringBuilder = new StringBuilder(26 + String.valueOf(valueOf).length());
                stringBuilder.append("asset key cannot be null: ");
                stringBuilder.append(valueOf);
                throw new IllegalStateException(stringBuilder.toString());
            } else if (asset == null) {
                valueOf = "asset cannot be null: key=";
                String valueOf2 = String.valueOf(num);
                throw new IllegalStateException(valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf));
            } else {
                if (Log.isLoggable(DataMap.TAG, 3)) {
                    String str = DataMap.TAG;
                    String valueOf3 = String.valueOf(asset);
                    StringBuilder stringBuilder2 = new StringBuilder((33 + String.valueOf(num).length()) + String.valueOf(valueOf3).length());
                    stringBuilder2.append("asPutDataRequest: adding asset: ");
                    stringBuilder2.append(num);
                    stringBuilder2.append(" ");
                    stringBuilder2.append(valueOf3);
                    Log.d(str, stringBuilder2.toString());
                }
                this.zzlgt.putAsset(num, asset);
                i++;
            }
        }
        return this.zzlgt;
    }

    public DataMap getDataMap() {
        return this.zzlgs;
    }

    public Uri getUri() {
        return this.zzlgt.getUri();
    }

    public boolean isUrgent() {
        return this.zzlgt.isUrgent();
    }

    public PutDataMapRequest setUrgent() {
        this.zzlgt.setUrgent();
        return this;
    }
}
