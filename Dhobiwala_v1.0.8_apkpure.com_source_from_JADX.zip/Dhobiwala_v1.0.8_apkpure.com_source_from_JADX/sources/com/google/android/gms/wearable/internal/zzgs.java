package com.google.android.gms.wearable.internal;

import android.os.ParcelFileDescriptor.AutoCloseInputStream;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.zzn;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.wearable.Channel.GetInputStreamResult;
import java.io.InputStream;

final class zzgs extends zzgm<GetInputStreamResult> {
    private final zzbr zzllf;

    public zzgs(zzn<GetInputStreamResult> zzn, zzbr zzbr) {
        super(zzn);
        this.zzllf = (zzbr) zzbq.checkNotNull(zzbr);
    }

    public final void zza(zzdm zzdm) {
        InputStream zzbj;
        if (zzdm.zzlkg != null) {
            zzbj = new zzbj(new AutoCloseInputStream(zzdm.zzlkg));
            this.zzllf.zza(new zzbk(zzbj));
        } else {
            zzbj = null;
        }
        zzav(new zzbg(new Status(zzdm.statusCode), zzbj));
    }
}
