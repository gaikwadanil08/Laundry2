package com.google.android.gms.wearable.internal;

import android.net.Uri;
import com.google.android.gms.common.api.internal.zzn;

final class zzhj implements Runnable {
    private /* synthetic */ String zzecf;
    private /* synthetic */ Uri zzjvt;
    private /* synthetic */ long zzljh;
    private /* synthetic */ long zzlji;
    private /* synthetic */ zzn zzllr;
    private /* synthetic */ zzhg zzlls;

    zzhj(zzhg zzhg, Uri uri, zzn zzn, String str, long j, long j2) {
        this.zzlls = zzhg;
        this.zzjvt = uri;
        this.zzllr = zzn;
        this.zzecf = str;
        this.zzljh = j;
        this.zzlji = j2;
    }

    public final void run() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
        /*
        r10 = this;
        r0 = "WearableClient";
        r1 = 2;
        r0 = android.util.Log.isLoggable(r0, r1);
        if (r0 == 0) goto L_0x0010;
    L_0x0009:
        r0 = "WearableClient";
        r1 = "Executing sendFileToChannelTask";
        android.util.Log.v(r0, r1);
    L_0x0010:
        r0 = "file";
        r1 = r10.zzjvt;
        r1 = r1.getScheme();
        r0 = r0.equals(r1);
        if (r0 != 0) goto L_0x0034;
    L_0x001e:
        r0 = "WearableClient";
        r1 = "Channel.sendFile used with non-file URI";
        android.util.Log.w(r0, r1);
        r0 = r10.zzllr;
        r1 = new com.google.android.gms.common.api.Status;
        r2 = 10;
        r3 = "Channel.sendFile used with non-file URI";
        r1.<init>(r2, r3);
        r0.zzu(r1);
        return;
    L_0x0034:
        r0 = new java.io.File;
        r1 = r10.zzjvt;
        r1 = r1.getPath();
        r0.<init>(r1);
        r1 = 268435456; // 0x10000000 float:2.5243549E-29 double:1.32624737E-315;
        r1 = android.os.ParcelFileDescriptor.open(r0, r1);	 Catch:{ FileNotFoundException -> 0x009c }
        r0 = r10.zzlls;	 Catch:{ RemoteException -> 0x006e }
        r0 = r0.zzakn();	 Catch:{ RemoteException -> 0x006e }
        r2 = r0;	 Catch:{ RemoteException -> 0x006e }
        r2 = (com.google.android.gms.wearable.internal.zzep) r2;	 Catch:{ RemoteException -> 0x006e }
        r3 = new com.google.android.gms.wearable.internal.zzhc;	 Catch:{ RemoteException -> 0x006e }
        r0 = r10.zzllr;	 Catch:{ RemoteException -> 0x006e }
        r3.<init>(r0);	 Catch:{ RemoteException -> 0x006e }
        r4 = r10.zzecf;	 Catch:{ RemoteException -> 0x006e }
        r6 = r10.zzljh;	 Catch:{ RemoteException -> 0x006e }
        r8 = r10.zzlji;	 Catch:{ RemoteException -> 0x006e }
        r5 = r1;	 Catch:{ RemoteException -> 0x006e }
        r2.zza(r3, r4, r5, r6, r8);	 Catch:{ RemoteException -> 0x006e }
        r1.close();	 Catch:{ IOException -> 0x0063 }
        return;
    L_0x0063:
        r0 = move-exception;
        r1 = "WearableClient";
        r2 = "Failed to close sourceFd";
        android.util.Log.w(r1, r2, r0);
        return;
    L_0x006c:
        r0 = move-exception;
        goto L_0x008f;
    L_0x006e:
        r0 = move-exception;
        r2 = "WearableClient";	 Catch:{ all -> 0x006c }
        r3 = "Channel.sendFile failed.";	 Catch:{ all -> 0x006c }
        android.util.Log.w(r2, r3, r0);	 Catch:{ all -> 0x006c }
        r0 = r10.zzllr;	 Catch:{ all -> 0x006c }
        r2 = new com.google.android.gms.common.api.Status;	 Catch:{ all -> 0x006c }
        r3 = 8;	 Catch:{ all -> 0x006c }
        r2.<init>(r3);	 Catch:{ all -> 0x006c }
        r0.zzu(r2);	 Catch:{ all -> 0x006c }
        r1.close();	 Catch:{ IOException -> 0x0086 }
        return;
    L_0x0086:
        r0 = move-exception;
        r1 = "WearableClient";
        r2 = "Failed to close sourceFd";
        android.util.Log.w(r1, r2, r0);
        return;
    L_0x008f:
        r1.close();	 Catch:{ IOException -> 0x0093 }
        goto L_0x009b;
    L_0x0093:
        r1 = move-exception;
        r2 = "WearableClient";
        r3 = "Failed to close sourceFd";
        android.util.Log.w(r2, r3, r1);
    L_0x009b:
        throw r0;
    L_0x009c:
        r1 = "WearableClient";
        r0 = java.lang.String.valueOf(r0);
        r2 = 46;
        r3 = java.lang.String.valueOf(r0);
        r3 = r3.length();
        r2 = r2 + r3;
        r3 = new java.lang.StringBuilder;
        r3.<init>(r2);
        r2 = "File couldn't be opened for Channel.sendFile: ";
        r3.append(r2);
        r3.append(r0);
        r0 = r3.toString();
        android.util.Log.w(r1, r0);
        r0 = r10.zzllr;
        r1 = new com.google.android.gms.common.api.Status;
        r2 = 13;
        r1.<init>(r2);
        r0.zzu(r1);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.wearable.internal.zzhj.run():void");
    }
}
