package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.Status;

final class zzgz extends zza {
    zzgz() {
    }

    public final void zza(Status status) {
    }
}
