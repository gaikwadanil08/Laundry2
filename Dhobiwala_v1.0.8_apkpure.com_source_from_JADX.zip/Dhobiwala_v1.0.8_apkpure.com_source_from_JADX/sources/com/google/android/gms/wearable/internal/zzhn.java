package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.internal.zzcl;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;

final class zzhn implements zzcl<ChannelListener> {
    private /* synthetic */ zzaw zzlhv;

    zzhn(zzaw zzaw) {
        this.zzlhv = zzaw;
    }

    public final void zzahz() {
    }

    public final /* synthetic */ void zzu(Object obj) {
        this.zzlhv.zza((ChannelListener) obj);
    }
}
