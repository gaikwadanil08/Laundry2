package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.zzn;
import com.google.android.gms.tasks.TaskCompletionSource;

final class zzgg implements zzn<Status> {
    private TaskCompletionSource<Boolean> zzlle;

    zzgg(TaskCompletionSource<Boolean> taskCompletionSource) {
        this.zzlle = taskCompletionSource;
    }

    public final /* synthetic */ void setResult(Object obj) {
        TaskCompletionSource taskCompletionSource;
        boolean z;
        Status status = (Status) obj;
        int statusCode = status.getStatusCode();
        if (statusCode == 0) {
            taskCompletionSource = this.zzlle;
            z = true;
        } else if (statusCode == 4002) {
            taskCompletionSource = this.zzlle;
            z = false;
        } else {
            zzu(status);
            return;
        }
        taskCompletionSource.setResult(Boolean.valueOf(z));
    }

    public final void zzu(Status status) {
        this.zzlle.setException(new ApiException(status));
    }
}
