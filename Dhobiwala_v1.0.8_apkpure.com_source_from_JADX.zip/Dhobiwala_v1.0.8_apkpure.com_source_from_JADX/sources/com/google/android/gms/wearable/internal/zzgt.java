package com.google.android.gms.wearable.internal;

import android.os.ParcelFileDescriptor.AutoCloseOutputStream;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.zzn;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.wearable.Channel.GetOutputStreamResult;
import java.io.OutputStream;

final class zzgt extends zzgm<GetOutputStreamResult> {
    private final zzbr zzllf;

    public zzgt(zzn<GetOutputStreamResult> zzn, zzbr zzbr) {
        super(zzn);
        this.zzllf = (zzbr) zzbq.checkNotNull(zzbr);
    }

    public final void zza(zzdo zzdo) {
        OutputStream zzbl;
        if (zzdo.zzlkg != null) {
            zzbl = new zzbl(new AutoCloseOutputStream(zzdo.zzlkg));
            this.zzllf.zza(new zzbm(zzbl));
        } else {
            zzbl = null;
        }
        zzav(new zzbh(new Status(zzdo.statusCode), zzbl));
    }
}
