package com.google.android.gms.wearable;

import com.google.android.gms.wearable.internal.zzfo;

final class zzn implements Runnable {
    private /* synthetic */ zzd zzlho;
    private /* synthetic */ zzfo zzlhq;

    zzn(zzd zzd, zzfo zzfo) {
        this.zzlho = zzd;
        this.zzlhq = zzfo;
    }

    public final void run() {
        this.zzlho.zzlhk.onPeerConnected(this.zzlhq);
    }
}
