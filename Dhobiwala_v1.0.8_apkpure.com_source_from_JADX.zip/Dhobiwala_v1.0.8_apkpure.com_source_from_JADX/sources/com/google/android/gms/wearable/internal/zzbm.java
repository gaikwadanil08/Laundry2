package com.google.android.gms.wearable.internal;

final class zzbm implements zzbs {
    private /* synthetic */ zzbl zzljp;

    zzbm(zzbl zzbl) {
        this.zzljp = zzbl;
    }

    public final void zzb(zzav zzav) {
        this.zzljp.zzc(zzav);
    }
}
