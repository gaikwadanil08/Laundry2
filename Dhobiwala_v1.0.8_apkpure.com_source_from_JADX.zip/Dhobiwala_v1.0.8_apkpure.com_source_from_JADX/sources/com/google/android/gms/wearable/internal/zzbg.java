package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.wearable.Channel.GetInputStreamResult;
import java.io.InputStream;

final class zzbg implements GetInputStreamResult {
    private final Status mStatus;
    private final InputStream zzljj;

    zzbg(Status status, InputStream inputStream) {
        this.mStatus = (Status) zzbq.checkNotNull(status);
        this.zzljj = inputStream;
    }

    public final InputStream getInputStream() {
        return this.zzljj;
    }

    public final Status getStatus() {
        return this.mStatus;
    }

    public final void release() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
*/
        /*
        r1 = this;
        r0 = r1.zzljj;
        if (r0 == 0) goto L_0x0009;
    L_0x0004:
        r0 = r1.zzljj;	 Catch:{ IOException -> 0x0009 }
        r0.close();	 Catch:{ IOException -> 0x0009 }
    L_0x0009:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.wearable.internal.zzbg.release():void");
    }
}
