package com.google.android.gms.wearable.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.zzci;
import com.google.android.gms.common.internal.zzbq;

final class zzb<T> extends zzn<Status> {
    private T zzfuk;
    private zzci<T> zzfus;
    private zzc<T> zzlhw;

    private zzb(GoogleApiClient googleApiClient, T t, zzci<T> zzci, zzc<T> zzc) {
        super(googleApiClient);
        this.zzfuk = zzbq.checkNotNull(t);
        this.zzfus = (zzci) zzbq.checkNotNull(zzci);
        this.zzlhw = (zzc) zzbq.checkNotNull(zzc);
    }

    static <T> PendingResult<Status> zza(GoogleApiClient googleApiClient, zzc<T> zzc, T t) {
        return googleApiClient.zzd(new zzb(googleApiClient, t, googleApiClient.zzt(t), zzc));
    }

    protected final /* synthetic */ void zza(com.google.android.gms.common.api.Api.zzb zzb) throws RemoteException {
        this.zzlhw.zza((zzhg) zzb, this, this.zzfuk, this.zzfus);
        this.zzfuk = null;
        this.zzfus = null;
    }

    protected final /* synthetic */ Result zzb(Status status) {
        this.zzfuk = null;
        this.zzfus = null;
        return status;
    }
}
