package com.google.android.gms.wearable.internal;

import android.content.Context;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.zzci;
import com.google.android.gms.common.api.internal.zzn;
import com.google.android.gms.common.internal.zzab;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.common.internal.zzr;
import com.google.android.gms.wearable.Asset;
import com.google.android.gms.wearable.CapabilityApi.CapabilityListener;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;
import com.google.android.gms.wearable.DataApi.DataListener;
import com.google.android.gms.wearable.DataApi.GetFdForAssetResult;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class zzhg extends zzab<zzep> {
    private final ExecutorService zzieo;
    private final zzer<Object> zzllh;
    private final zzer<Object> zzlli;
    private final zzer<ChannelListener> zzllj;
    private final zzer<DataListener> zzllk;
    private final zzer<MessageListener> zzlll;
    private final zzer<Object> zzllm;
    private final zzer<Object> zzlln;
    private final zzer<CapabilityListener> zzllo;
    private final zzhp zzllp;

    public zzhg(Context context, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, zzr zzr) {
        this(context, looper, connectionCallbacks, onConnectionFailedListener, zzr, Executors.newCachedThreadPool(), zzhp.zzep(context));
    }

    private zzhg(Context context, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, zzr zzr, ExecutorService executorService, zzhp zzhp) {
        super(context, looper, 14, zzr, connectionCallbacks, onConnectionFailedListener);
        this.zzllh = new zzer();
        this.zzlli = new zzer();
        this.zzllj = new zzer();
        this.zzllk = new zzer();
        this.zzlll = new zzer();
        this.zzllm = new zzer();
        this.zzlln = new zzer();
        this.zzllo = new zzer();
        this.zzieo = (ExecutorService) zzbq.checkNotNull(executorService);
        this.zzllp = zzhp;
    }

    protected final void zza(int i, IBinder iBinder, Bundle bundle, int i2) {
        if (Log.isLoggable("WearableClient", 2)) {
            StringBuilder stringBuilder = new StringBuilder(41);
            stringBuilder.append("onPostInitHandler: statusCode ");
            stringBuilder.append(i);
            Log.d("WearableClient", stringBuilder.toString());
        }
        if (i == 0) {
            this.zzllh.zzbr(iBinder);
            this.zzlli.zzbr(iBinder);
            this.zzllj.zzbr(iBinder);
            this.zzllk.zzbr(iBinder);
            this.zzlll.zzbr(iBinder);
            this.zzllm.zzbr(iBinder);
            this.zzlln.zzbr(iBinder);
            this.zzllo.zzbr(iBinder);
        }
        super.zza(i, iBinder, bundle, i2);
    }

    public final void zza(zzn<GetFdForAssetResult> zzn, Asset asset) throws RemoteException {
        ((zzep) zzakn()).zza(new zzgx(zzn), asset);
    }

    public final void zza(zzn<Status> zzn, CapabilityListener capabilityListener) throws RemoteException {
        this.zzllo.zza(this, zzn, capabilityListener);
    }

    public final void zza(zzn<Status> zzn, CapabilityListener capabilityListener, zzci<CapabilityListener> zzci, IntentFilter[] intentFilterArr) throws RemoteException {
        this.zzllo.zza(this, zzn, capabilityListener, zzhk.zzd(zzci, intentFilterArr));
    }

    public final void zza(zzn<Status> zzn, ChannelListener channelListener, zzci<ChannelListener> zzci, String str, IntentFilter[] intentFilterArr) throws RemoteException {
        if (str == null) {
            this.zzllj.zza(this, zzn, channelListener, zzhk.zzc(zzci, intentFilterArr));
            return;
        }
        this.zzllj.zza(this, zzn, new zzgc(str, channelListener), zzhk.zza(zzci, str, intentFilterArr));
    }

    public final void zza(zzn<Status> zzn, ChannelListener channelListener, String str) throws RemoteException {
        if (str == null) {
            this.zzllj.zza(this, zzn, channelListener);
            return;
        }
        this.zzllj.zza(this, zzn, new zzgc(str, channelListener));
    }

    public final void zza(zzn<Status> zzn, DataListener dataListener) throws RemoteException {
        this.zzllk.zza(this, zzn, dataListener);
    }

    public final void zza(zzn<Status> zzn, DataListener dataListener, zzci<DataListener> zzci, IntentFilter[] intentFilterArr) throws RemoteException {
        this.zzllk.zza(this, zzn, dataListener, zzhk.zza(zzci, intentFilterArr));
    }

    public final void zza(zzn<Status> zzn, MessageListener messageListener) throws RemoteException {
        this.zzlll.zza(this, zzn, messageListener);
    }

    public final void zza(zzn<Status> zzn, MessageListener messageListener, zzci<MessageListener> zzci, IntentFilter[] intentFilterArr) throws RemoteException {
        this.zzlll.zza(this, zzn, messageListener, zzhk.zzb(zzci, intentFilterArr));
    }

    public final void zza(com.google.android.gms.common.api.internal.zzn<com.google.android.gms.wearable.DataApi.DataItemResult> r18, com.google.android.gms.wearable.PutDataRequest r19) throws android.os.RemoteException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
        /*
        r17 = this;
        r1 = r17;
        r2 = r18;
        r3 = r19.getAssets();
        r3 = r3.entrySet();
        r3 = r3.iterator();
    L_0x0010:
        r4 = r3.hasNext();
        if (r4 == 0) goto L_0x0079;
    L_0x0016:
        r4 = r3.next();
        r4 = (java.util.Map.Entry) r4;
        r4 = r4.getValue();
        r4 = (com.google.android.gms.wearable.Asset) r4;
        r5 = r4.getData();
        if (r5 != 0) goto L_0x0010;
    L_0x0028:
        r5 = r4.getDigest();
        if (r5 != 0) goto L_0x0010;
    L_0x002e:
        r5 = r4.getFd();
        if (r5 != 0) goto L_0x0010;
    L_0x0034:
        r5 = r4.getUri();
        if (r5 != 0) goto L_0x0010;
    L_0x003a:
        r2 = new java.lang.IllegalArgumentException;
        r3 = r19.getUri();
        r3 = java.lang.String.valueOf(r3);
        r4 = java.lang.String.valueOf(r4);
        r5 = 33;
        r6 = java.lang.String.valueOf(r3);
        r6 = r6.length();
        r5 = r5 + r6;
        r6 = java.lang.String.valueOf(r4);
        r6 = r6.length();
        r5 = r5 + r6;
        r6 = new java.lang.StringBuilder;
        r6.<init>(r5);
        r5 = "Put for ";
        r6.append(r5);
        r6.append(r3);
        r3 = " contains invalid asset: ";
        r6.append(r3);
        r6.append(r4);
        r3 = r6.toString();
        r2.<init>(r3);
        throw r2;
    L_0x0079:
        r3 = r19.getUri();
        r3 = com.google.android.gms.wearable.PutDataRequest.zzs(r3);
        r4 = r19.getData();
        r3.setData(r4);
        r4 = r19.isUrgent();
        if (r4 == 0) goto L_0x0091;
    L_0x008e:
        r3.setUrgent();
    L_0x0091:
        r4 = new java.util.ArrayList;
        r4.<init>();
        r5 = r19.getAssets();
        r5 = r5.entrySet();
        r5 = r5.iterator();
    L_0x00a2:
        r6 = r5.hasNext();
        if (r6 == 0) goto L_0x01d9;
    L_0x00a8:
        r6 = r5.next();
        r6 = (java.util.Map.Entry) r6;
        r7 = r6.getValue();
        r7 = (com.google.android.gms.wearable.Asset) r7;
        r8 = r7.getData();
        if (r8 == 0) goto L_0x016d;
    L_0x00ba:
        r8 = android.os.ParcelFileDescriptor.createPipe();	 Catch:{ IOException -> 0x0146 }
        r9 = "WearableClient";
        r10 = 3;
        r9 = android.util.Log.isLoggable(r9, r10);
        r10 = 1;
        r11 = 0;
        if (r9 == 0) goto L_0x011c;
    L_0x00c9:
        r9 = "WearableClient";
        r12 = java.lang.String.valueOf(r7);
        r13 = r8[r11];
        r13 = java.lang.String.valueOf(r13);
        r14 = r8[r10];
        r14 = java.lang.String.valueOf(r14);
        r15 = 61;
        r10 = java.lang.String.valueOf(r12);
        r10 = r10.length();
        r15 = r15 + r10;
        r10 = java.lang.String.valueOf(r13);
        r10 = r10.length();
        r15 = r15 + r10;
        r10 = java.lang.String.valueOf(r14);
        r10 = r10.length();
        r15 = r15 + r10;
        r10 = new java.lang.StringBuilder;
        r10.<init>(r15);
        r15 = "processAssets: replacing data with FD in asset: ";
        r10.append(r15);
        r10.append(r12);
        r12 = " read:";
        r10.append(r12);
        r10.append(r13);
        r12 = " write:";
        r10.append(r12);
        r10.append(r14);
        r10 = r10.toString();
        android.util.Log.d(r9, r10);
    L_0x011c:
        r6 = r6.getKey();
        r6 = (java.lang.String) r6;
        r9 = r8[r11];
        r9 = com.google.android.gms.wearable.Asset.createFromFd(r9);
        r3.putAsset(r6, r9);
        r6 = 1;
        r6 = r8[r6];
        r7 = r7.getData();
        r8 = new java.util.concurrent.FutureTask;
        r9 = new com.google.android.gms.wearable.internal.zzhh;
        r9.<init>(r1, r6, r7);
        r8.<init>(r9);
        r4.add(r8);
        r6 = r1.zzieo;
        r6.submit(r8);
        goto L_0x00a2;
    L_0x0146:
        r0 = move-exception;
        r2 = new java.lang.IllegalStateException;
        r3 = java.lang.String.valueOf(r19);
        r4 = 60;
        r5 = java.lang.String.valueOf(r3);
        r5 = r5.length();
        r4 = r4 + r5;
        r5 = new java.lang.StringBuilder;
        r5.<init>(r4);
        r4 = "Unable to create ParcelFileDescriptor for asset in request: ";
        r5.append(r4);
        r5.append(r3);
        r3 = r5.toString();
        r2.<init>(r3, r0);
        throw r2;
    L_0x016d:
        r8 = r7.getUri();
        if (r8 == 0) goto L_0x01ce;
    L_0x0173:
        r8 = r17.getContext();	 Catch:{ FileNotFoundException -> 0x0194 }
        r8 = r8.getContentResolver();	 Catch:{ FileNotFoundException -> 0x0194 }
        r9 = r7.getUri();	 Catch:{ FileNotFoundException -> 0x0194 }
        r10 = "r";	 Catch:{ FileNotFoundException -> 0x0194 }
        r8 = r8.openFileDescriptor(r9, r10);	 Catch:{ FileNotFoundException -> 0x0194 }
        r8 = com.google.android.gms.wearable.Asset.createFromFd(r8);	 Catch:{ FileNotFoundException -> 0x0194 }
        r6 = r6.getKey();	 Catch:{ FileNotFoundException -> 0x0194 }
        r6 = (java.lang.String) r6;	 Catch:{ FileNotFoundException -> 0x0194 }
        r3.putAsset(r6, r8);	 Catch:{ FileNotFoundException -> 0x0194 }
        goto L_0x00a2;
    L_0x0194:
        r3 = new com.google.android.gms.wearable.internal.zzhb;
        r3.<init>(r2, r4);
        r2 = new com.google.android.gms.wearable.internal.zzfu;
        r4 = 4005; // 0xfa5 float:5.612E-42 double:1.9787E-320;
        r5 = 0;
        r2.<init>(r4, r5);
        r3.zza(r2);
        r2 = "WearableClient";
        r3 = r7.getUri();
        r3 = java.lang.String.valueOf(r3);
        r4 = 28;
        r5 = java.lang.String.valueOf(r3);
        r5 = r5.length();
        r4 = r4 + r5;
        r5 = new java.lang.StringBuilder;
        r5.<init>(r4);
        r4 = "Couldn't resolve asset URI: ";
        r5.append(r4);
        r5.append(r3);
        r3 = r5.toString();
        android.util.Log.w(r2, r3);
        return;
    L_0x01ce:
        r6 = r6.getKey();
        r6 = (java.lang.String) r6;
        r3.putAsset(r6, r7);
        goto L_0x00a2;
    L_0x01d9:
        r5 = r17.zzakn();
        r5 = (com.google.android.gms.wearable.internal.zzep) r5;
        r6 = new com.google.android.gms.wearable.internal.zzhb;
        r6.<init>(r2, r4);
        r5.zza(r6, r3);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.wearable.internal.zzhg.zza(com.google.android.gms.common.api.internal.zzn, com.google.android.gms.wearable.PutDataRequest):void");
    }

    public final void zza(zzn<Status> zzn, String str, Uri uri, long j, long j2) {
        try {
            ExecutorService executorService = this.zzieo;
            zzbq.checkNotNull(zzn);
            zzbq.checkNotNull(str);
            zzbq.checkNotNull(uri);
            zzbq.zzb(j >= 0, "startOffset is negative: %s", new Object[]{Long.valueOf(j)});
            zzbq.zzb(j2 >= -1, "invalid length: %s", new Object[]{Long.valueOf(j2)});
            executorService.execute(new zzhj(r10, uri, zzn, str, j, j2));
        } catch (RuntimeException e) {
            RuntimeException runtimeException = e;
            zzn.zzu(new Status(8));
            throw runtimeException;
        }
    }

    public final void zza(zzn<Status> zzn, String str, Uri uri, boolean z) {
        try {
            ExecutorService executorService = this.zzieo;
            zzbq.checkNotNull(zzn);
            zzbq.checkNotNull(str);
            zzbq.checkNotNull(uri);
            executorService.execute(new zzhi(this, uri, zzn, z, str));
        } catch (RuntimeException e) {
            zzn.zzu(new Status(8));
            throw e;
        }
    }

    public final void zza(@android.support.annotation.NonNull com.google.android.gms.common.internal.zzj r7) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
        /*
        r6 = this;
        r0 = r6.zzagg();
        if (r0 != 0) goto L_0x0098;
    L_0x0006:
        r0 = r6.getContext();	 Catch:{ NameNotFoundException -> 0x0091 }
        r0 = r0.getPackageManager();	 Catch:{ NameNotFoundException -> 0x0091 }
        r1 = "com.google.android.wearable.app.cn";	 Catch:{ NameNotFoundException -> 0x0091 }
        r2 = 128; // 0x80 float:1.794E-43 double:6.32E-322;	 Catch:{ NameNotFoundException -> 0x0091 }
        r0 = r0.getApplicationInfo(r1, r2);	 Catch:{ NameNotFoundException -> 0x0091 }
        r0 = r0.metaData;	 Catch:{ NameNotFoundException -> 0x0091 }
        r1 = 0;	 Catch:{ NameNotFoundException -> 0x0091 }
        if (r0 == 0) goto L_0x0022;	 Catch:{ NameNotFoundException -> 0x0091 }
    L_0x001b:
        r2 = "com.google.android.wearable.api.version";	 Catch:{ NameNotFoundException -> 0x0091 }
        r0 = r0.getInt(r2, r1);	 Catch:{ NameNotFoundException -> 0x0091 }
        goto L_0x0023;	 Catch:{ NameNotFoundException -> 0x0091 }
    L_0x0022:
        r0 = r1;	 Catch:{ NameNotFoundException -> 0x0091 }
    L_0x0023:
        r2 = com.google.android.gms.common.zzf.GOOGLE_PLAY_SERVICES_VERSION_CODE;	 Catch:{ NameNotFoundException -> 0x0091 }
        if (r0 >= r2) goto L_0x0098;	 Catch:{ NameNotFoundException -> 0x0091 }
    L_0x0027:
        r2 = "WearableClient";	 Catch:{ NameNotFoundException -> 0x0091 }
        r3 = com.google.android.gms.common.zzf.GOOGLE_PLAY_SERVICES_VERSION_CODE;	 Catch:{ NameNotFoundException -> 0x0091 }
        r4 = 80;	 Catch:{ NameNotFoundException -> 0x0091 }
        r5 = new java.lang.StringBuilder;	 Catch:{ NameNotFoundException -> 0x0091 }
        r5.<init>(r4);	 Catch:{ NameNotFoundException -> 0x0091 }
        r4 = "Android Wear out of date. Requires API version ";	 Catch:{ NameNotFoundException -> 0x0091 }
        r5.append(r4);	 Catch:{ NameNotFoundException -> 0x0091 }
        r5.append(r3);	 Catch:{ NameNotFoundException -> 0x0091 }
        r3 = " but found ";	 Catch:{ NameNotFoundException -> 0x0091 }
        r5.append(r3);	 Catch:{ NameNotFoundException -> 0x0091 }
        r5.append(r0);	 Catch:{ NameNotFoundException -> 0x0091 }
        r0 = r5.toString();	 Catch:{ NameNotFoundException -> 0x0091 }
        android.util.Log.w(r2, r0);	 Catch:{ NameNotFoundException -> 0x0091 }
        r0 = 6;	 Catch:{ NameNotFoundException -> 0x0091 }
        r2 = r6.getContext();	 Catch:{ NameNotFoundException -> 0x0091 }
        r3 = r6.getContext();	 Catch:{ NameNotFoundException -> 0x0091 }
        r4 = new android.content.Intent;	 Catch:{ NameNotFoundException -> 0x0091 }
        r5 = "com.google.android.wearable.app.cn.UPDATE_ANDROID_WEAR";	 Catch:{ NameNotFoundException -> 0x0091 }
        r4.<init>(r5);	 Catch:{ NameNotFoundException -> 0x0091 }
        r5 = "com.google.android.wearable.app.cn";	 Catch:{ NameNotFoundException -> 0x0091 }
        r4 = r4.setPackage(r5);	 Catch:{ NameNotFoundException -> 0x0091 }
        r3 = r3.getPackageManager();	 Catch:{ NameNotFoundException -> 0x0091 }
        r5 = 65536; // 0x10000 float:9.18355E-41 double:3.2379E-319;	 Catch:{ NameNotFoundException -> 0x0091 }
        r3 = r3.resolveActivity(r4, r5);	 Catch:{ NameNotFoundException -> 0x0091 }
        if (r3 == 0) goto L_0x006c;	 Catch:{ NameNotFoundException -> 0x0091 }
    L_0x006b:
        goto L_0x0089;	 Catch:{ NameNotFoundException -> 0x0091 }
    L_0x006c:
        r3 = "market://details";	 Catch:{ NameNotFoundException -> 0x0091 }
        r3 = android.net.Uri.parse(r3);	 Catch:{ NameNotFoundException -> 0x0091 }
        r3 = r3.buildUpon();	 Catch:{ NameNotFoundException -> 0x0091 }
        r4 = "id";	 Catch:{ NameNotFoundException -> 0x0091 }
        r5 = "com.google.android.wearable.app.cn";	 Catch:{ NameNotFoundException -> 0x0091 }
        r3 = r3.appendQueryParameter(r4, r5);	 Catch:{ NameNotFoundException -> 0x0091 }
        r3 = r3.build();	 Catch:{ NameNotFoundException -> 0x0091 }
        r4 = new android.content.Intent;	 Catch:{ NameNotFoundException -> 0x0091 }
        r5 = "android.intent.action.VIEW";	 Catch:{ NameNotFoundException -> 0x0091 }
        r4.<init>(r5, r3);	 Catch:{ NameNotFoundException -> 0x0091 }
    L_0x0089:
        r1 = android.app.PendingIntent.getActivity(r2, r1, r4, r1);	 Catch:{ NameNotFoundException -> 0x0091 }
        r6.zza(r7, r0, r1);	 Catch:{ NameNotFoundException -> 0x0091 }
        return;
    L_0x0091:
        r0 = 16;
        r1 = 0;
        r6.zza(r7, r0, r1);
        return;
    L_0x0098:
        super.zza(r7);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.wearable.internal.zzhg.zza(com.google.android.gms.common.internal.zzj):void");
    }

    public final boolean zzagg() {
        return !this.zzllp.zznz("com.google.android.wearable.app.cn");
    }

    protected final String zzakh() {
        return this.zzllp.zznz("com.google.android.wearable.app.cn") ? "com.google.android.wearable.app.cn" : "com.google.android.gms";
    }

    protected final /* synthetic */ IInterface zzd(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.wearable.internal.IWearableService");
        return queryLocalInterface instanceof zzep ? (zzep) queryLocalInterface : new zzeq(iBinder);
    }

    protected final String zzhi() {
        return "com.google.android.gms.wearable.BIND";
    }

    protected final String zzhj() {
        return "com.google.android.gms.wearable.internal.IWearableService";
    }
}
