package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.internal.zzbo;
import com.google.android.gms.wearable.DataApi.GetFdForAssetResult;

final /* synthetic */ class zzcs implements zzbo {
    static final zzbo zzgnw = new zzcs();

    private zzcs() {
    }

    public final Object zzb(Result result) {
        return new zzcu((GetFdForAssetResult) result);
    }
}
