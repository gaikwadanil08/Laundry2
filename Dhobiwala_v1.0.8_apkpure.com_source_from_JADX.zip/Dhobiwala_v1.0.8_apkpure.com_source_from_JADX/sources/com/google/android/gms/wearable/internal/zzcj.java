package com.google.android.gms.wearable.internal;

import android.app.Activity;
import android.content.Context;
import android.content.IntentFilter;
import android.net.Uri;
import android.support.annotation.NonNull;
import com.google.android.gms.common.api.GoogleApi.zza;
import com.google.android.gms.common.api.internal.zzci;
import com.google.android.gms.common.api.internal.zzcm;
import com.google.android.gms.common.internal.zzbj;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.common.internal.zzc;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.wearable.Asset;
import com.google.android.gms.wearable.DataApi;
import com.google.android.gms.wearable.DataClient;
import com.google.android.gms.wearable.DataClient.GetFdForAssetResponse;
import com.google.android.gms.wearable.DataClient.OnDataChangedListener;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataItemAsset;
import com.google.android.gms.wearable.DataItemBuffer;
import com.google.android.gms.wearable.PutDataRequest;

public final class zzcj extends DataClient {
    private final DataApi zzljz = new zzbw();

    public zzcj(@NonNull Activity activity, @NonNull zza zza) {
        super(activity, zza);
    }

    public zzcj(@NonNull Context context, @NonNull zza zza) {
        super(context, zza);
    }

    private final Task<Void> zza(OnDataChangedListener onDataChangedListener, IntentFilter[] intentFilterArr) {
        zzci zzb = zzcm.zzb(onDataChangedListener, getLooper(), "DataListener");
        return zza(new zzcv(onDataChangedListener, intentFilterArr, zzb), new zzcw(onDataChangedListener, zzb.zzajo()));
    }

    public final Task<Void> addListener(@NonNull OnDataChangedListener onDataChangedListener) {
        return zza(onDataChangedListener, new IntentFilter[]{zzgj.zzny("com.google.android.gms.wearable.DATA_CHANGED")});
    }

    public final Task<Void> addListener(@NonNull OnDataChangedListener onDataChangedListener, @NonNull Uri uri, int i) {
        boolean z;
        IntentFilter zza;
        zzc.zzb(uri, "uri must not be null");
        if (i != 0) {
            if (i != 1) {
                z = false;
                zzbq.checkArgument(z, "invalid filter type");
                zza = zzgj.zza("com.google.android.gms.wearable.DATA_CHANGED", uri, i);
                return zza(onDataChangedListener, new IntentFilter[]{zza});
            }
        }
        z = true;
        zzbq.checkArgument(z, "invalid filter type");
        zza = zzgj.zza("com.google.android.gms.wearable.DATA_CHANGED", uri, i);
        return zza(onDataChangedListener, new IntentFilter[]{zza});
    }

    public final Task<Integer> deleteDataItems(@NonNull Uri uri) {
        return zzbj.zza(this.zzljz.deleteDataItems(zzago(), uri), zzcp.zzgnw);
    }

    public final Task<Integer> deleteDataItems(@NonNull Uri uri, int i) {
        return zzbj.zza(this.zzljz.deleteDataItems(zzago(), uri, i), zzcq.zzgnw);
    }

    public final Task<DataItem> getDataItem(@NonNull Uri uri) {
        return zzbj.zza(this.zzljz.getDataItem(zzago(), uri), zzcl.zzgnw);
    }

    public final Task<DataItemBuffer> getDataItems() {
        return zzbj.zza(this.zzljz.getDataItems(zzago()), zzcm.zzgnw);
    }

    public final Task<DataItemBuffer> getDataItems(@NonNull Uri uri) {
        return zzbj.zza(this.zzljz.getDataItems(zzago(), uri), zzcn.zzgnw);
    }

    public final Task<DataItemBuffer> getDataItems(@NonNull Uri uri, int i) {
        return zzbj.zza(this.zzljz.getDataItems(zzago(), uri, i), zzco.zzgnw);
    }

    public final Task<GetFdForAssetResponse> getFdForAsset(@NonNull Asset asset) {
        return zzbj.zza(this.zzljz.getFdForAsset(zzago(), asset), zzcr.zzgnw);
    }

    public final Task<GetFdForAssetResponse> getFdForAsset(@NonNull DataItemAsset dataItemAsset) {
        return zzbj.zza(this.zzljz.getFdForAsset(zzago(), dataItemAsset), zzcs.zzgnw);
    }

    public final Task<DataItem> putDataItem(@NonNull PutDataRequest putDataRequest) {
        return zzbj.zza(this.zzljz.putDataItem(zzago(), putDataRequest), zzck.zzgnw);
    }

    public final Task<Boolean> removeListener(@NonNull OnDataChangedListener onDataChangedListener) {
        return zza(zzcm.zzb(onDataChangedListener, getLooper(), "DataListener").zzajo());
    }
}
