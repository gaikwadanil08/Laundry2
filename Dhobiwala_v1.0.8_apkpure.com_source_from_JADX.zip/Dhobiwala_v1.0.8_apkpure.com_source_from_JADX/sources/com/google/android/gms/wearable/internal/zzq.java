package com.google.android.gms.wearable.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api.zzb;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.wearable.CapabilityApi.GetAllCapabilitiesResult;

final class zzq extends zzn<GetAllCapabilitiesResult> {
    private /* synthetic */ int zzlik;

    zzq(zzo zzo, GoogleApiClient googleApiClient, int i) {
        this.zzlik = i;
        super(googleApiClient);
    }

    protected final /* synthetic */ void zza(zzb zzb) throws RemoteException {
        zzhg zzhg = (zzhg) zzb;
        ((zzep) zzhg.zzakn()).zza(new zzgq(this), this.zzlik);
    }

    protected final /* synthetic */ Result zzb(Status status) {
        return new zzx(status, null);
    }
}
