package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.internal.zzbo;
import com.google.android.gms.wearable.DataItemBuffer;

final /* synthetic */ class zzcn implements zzbo {
    static final zzbo zzgnw = new zzcn();

    private zzcn() {
    }

    public final Object zzb(Result result) {
        return (DataItemBuffer) result;
    }
}
