package com.google.android.gms.wearable;

import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.common.internal.zzc;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import com.google.android.gms.wearable.internal.DataItemAssetParcelable;
import java.security.SecureRandom;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class PutDataRequest extends zzbfm {
    public static final Creator<PutDataRequest> CREATOR = new zzh();
    public static final String WEAR_URI_SCHEME = "wear";
    private static final long zzlgu = TimeUnit.MINUTES.toMillis(30);
    private static final Random zzlgv = new SecureRandom();
    private final Uri mUri;
    private byte[] zzhyw;
    private final Bundle zzlgw;
    private long zzlgx;

    private PutDataRequest(Uri uri) {
        this(uri, new Bundle(), null, zzlgu);
    }

    PutDataRequest(Uri uri, Bundle bundle, byte[] bArr, long j) {
        this.mUri = uri;
        this.zzlgw = bundle;
        this.zzlgw.setClassLoader(DataItemAssetParcelable.class.getClassLoader());
        this.zzhyw = bArr;
        this.zzlgx = j;
    }

    public static PutDataRequest create(@NonNull String str) {
        zzc.zzb(str, "path must not be null");
        return zzs(zznw(str));
    }

    public static PutDataRequest createFromDataItem(@NonNull DataItem dataItem) {
        zzc.zzb(dataItem, "source must not be null");
        PutDataRequest zzs = zzs(dataItem.getUri());
        for (Entry entry : dataItem.getAssets().entrySet()) {
            if (((DataItemAsset) entry.getValue()).getId() == null) {
                String str = "Cannot create an asset for a put request without a digest: ";
                String valueOf = String.valueOf((String) entry.getKey());
                throw new IllegalStateException(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            }
            zzs.putAsset((String) entry.getKey(), Asset.createFromRef(((DataItemAsset) entry.getValue()).getId()));
        }
        zzs.setData(dataItem.getData());
        return zzs;
    }

    public static PutDataRequest createWithAutoAppendedId(@NonNull String str) {
        zzc.zzb(str, "pathPrefix must not be null");
        StringBuilder stringBuilder = new StringBuilder(str);
        if (!str.endsWith("/")) {
            stringBuilder.append("/");
        }
        stringBuilder.append("PN");
        stringBuilder.append(zzlgv.nextLong());
        return new PutDataRequest(zznw(stringBuilder.toString()));
    }

    private static Uri zznw(String str) {
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("An empty path was supplied.");
        } else if (!str.startsWith("/")) {
            throw new IllegalArgumentException("A path must start with a single / .");
        } else if (!str.startsWith("//")) {
            return new Builder().scheme(WEAR_URI_SCHEME).path(str).build();
        } else {
            throw new IllegalArgumentException("A path must start with a single / .");
        }
    }

    public static PutDataRequest zzs(@NonNull Uri uri) {
        zzc.zzb(uri, "uri must not be null");
        return new PutDataRequest(uri);
    }

    public Asset getAsset(@NonNull String str) {
        zzc.zzb(str, "key must not be null");
        return (Asset) this.zzlgw.getParcelable(str);
    }

    public Map<String, Asset> getAssets() {
        Map hashMap = new HashMap();
        for (String str : this.zzlgw.keySet()) {
            hashMap.put(str, (Asset) this.zzlgw.getParcelable(str));
        }
        return Collections.unmodifiableMap(hashMap);
    }

    public byte[] getData() {
        return this.zzhyw;
    }

    public Uri getUri() {
        return this.mUri;
    }

    public boolean hasAsset(@NonNull String str) {
        zzc.zzb(str, "key must not be null");
        return this.zzlgw.containsKey(str);
    }

    public boolean isUrgent() {
        return this.zzlgx == 0;
    }

    public PutDataRequest putAsset(@NonNull String str, @NonNull Asset asset) {
        zzbq.checkNotNull(str);
        zzbq.checkNotNull(asset);
        this.zzlgw.putParcelable(str, asset);
        return this;
    }

    public PutDataRequest removeAsset(@NonNull String str) {
        zzc.zzb(str, "key must not be null");
        this.zzlgw.remove(str);
        return this;
    }

    public PutDataRequest setData(byte[] bArr) {
        this.zzhyw = bArr;
        return this;
    }

    public PutDataRequest setUrgent() {
        this.zzlgx = 0;
        return this;
    }

    public String toString() {
        return toString(Log.isLoggable(DataMap.TAG, 3));
    }

    public String toString(boolean z) {
        String str;
        StringBuilder stringBuilder = new StringBuilder("PutDataRequest[");
        String valueOf = String.valueOf(this.zzhyw == null ? "null" : Integer.valueOf(this.zzhyw.length));
        StringBuilder stringBuilder2 = new StringBuilder(String.valueOf(valueOf).length() + 7);
        stringBuilder2.append("dataSz=");
        stringBuilder2.append(valueOf);
        stringBuilder.append(stringBuilder2.toString());
        int size = this.zzlgw.size();
        stringBuilder2 = new StringBuilder(23);
        stringBuilder2.append(", numAssets=");
        stringBuilder2.append(size);
        stringBuilder.append(stringBuilder2.toString());
        valueOf = String.valueOf(this.mUri);
        stringBuilder2 = new StringBuilder(6 + String.valueOf(valueOf).length());
        stringBuilder2.append(", uri=");
        stringBuilder2.append(valueOf);
        stringBuilder.append(stringBuilder2.toString());
        long j = this.zzlgx;
        StringBuilder stringBuilder3 = new StringBuilder(35);
        stringBuilder3.append(", syncDeadline=");
        stringBuilder3.append(j);
        stringBuilder.append(stringBuilder3.toString());
        if (z) {
            stringBuilder.append("]\n  assets: ");
            for (String valueOf2 : this.zzlgw.keySet()) {
                String valueOf3 = String.valueOf(this.zzlgw.getParcelable(valueOf2));
                stringBuilder3 = new StringBuilder((String.valueOf(valueOf2).length() + 7) + String.valueOf(valueOf3).length());
                stringBuilder3.append("\n    ");
                stringBuilder3.append(valueOf2);
                stringBuilder3.append(": ");
                stringBuilder3.append(valueOf3);
                stringBuilder.append(stringBuilder3.toString());
            }
            str = "\n  ]";
        } else {
            str = "]";
        }
        stringBuilder.append(str);
        return stringBuilder.toString();
    }

    public void writeToParcel(@NonNull Parcel parcel, int i) {
        zzc.zzb(parcel, "dest must not be null");
        int zze = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, getUri(), i, false);
        zzbfp.zza(parcel, 4, this.zzlgw, false);
        zzbfp.zza(parcel, 5, getData(), false);
        zzbfp.zza(parcel, 6, this.zzlgx);
        zzbfp.zzai(parcel, zze);
    }
}
