package com.google.android.gms.wearable.internal;

final class zzav {
    final int zzljc;
    final int zzljd;

    zzav(int i, int i2) {
        this.zzljc = i;
        this.zzljd = i2;
    }
}
