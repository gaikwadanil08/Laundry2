package com.google.android.gms.wearable.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api.zzb;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.wearable.ChannelApi.OpenChannelResult;

final class zzak extends zzn<OpenChannelResult> {
    private /* synthetic */ String zzcav;
    private /* synthetic */ String zzliv;

    zzak(zzaj zzaj, GoogleApiClient googleApiClient, String str, String str2) {
        this.zzliv = str;
        this.zzcav = str2;
        super(googleApiClient);
    }

    protected final /* synthetic */ void zza(zzb zzb) throws RemoteException {
        zzhg zzhg = (zzhg) zzb;
        ((zzep) zzhg.zzakn()).zza(new zzha(this), this.zzliv, this.zzcav);
    }

    public final /* synthetic */ Result zzb(Status status) {
        return new zzam(status, null);
    }
}
