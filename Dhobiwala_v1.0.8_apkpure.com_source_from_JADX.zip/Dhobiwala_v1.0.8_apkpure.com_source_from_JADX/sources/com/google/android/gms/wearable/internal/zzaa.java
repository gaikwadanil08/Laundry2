package com.google.android.gms.wearable.internal;

import android.app.Activity;
import android.content.Context;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Looper;
import android.support.annotation.NonNull;
import com.google.android.gms.common.api.GoogleApi.zza;
import com.google.android.gms.common.api.internal.zzci;
import com.google.android.gms.common.api.internal.zzcm;
import com.google.android.gms.common.internal.zzbj;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.common.internal.zzc;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.wearable.CapabilityApi;
import com.google.android.gms.wearable.CapabilityClient;
import com.google.android.gms.wearable.CapabilityClient.OnCapabilityChangedListener;
import com.google.android.gms.wearable.CapabilityInfo;
import java.util.Map;

public final class zzaa extends CapabilityClient {
    private final CapabilityApi zzlir = new zzo();

    public zzaa(@NonNull Activity activity, @NonNull zza zza) {
        super(activity, zza);
    }

    public zzaa(@NonNull Context context, @NonNull zza zza) {
        super(context, zza);
    }

    private final Task<Void> zza(zzci<OnCapabilityChangedListener> zzci, OnCapabilityChangedListener onCapabilityChangedListener, IntentFilter[] intentFilterArr) {
        return zza(new zzaf(onCapabilityChangedListener, intentFilterArr, zzci), new zzag(onCapabilityChangedListener, zzci.zzajo()));
    }

    public final Task<Void> addListener(@NonNull OnCapabilityChangedListener onCapabilityChangedListener, @NonNull Uri uri, int i) {
        boolean z;
        IntentFilter zza;
        zzc.zzb(onCapabilityChangedListener, "listener must not be null");
        zzc.zzb(uri, "uri must not be null");
        if (i != 0) {
            if (i != 1) {
                z = false;
                zzbq.checkArgument(z, "invalid filter type");
                zza = zzgj.zza("com.google.android.gms.wearable.CAPABILITY_CHANGED", uri, i);
                return zza(zzcm.zzb(onCapabilityChangedListener, getLooper(), "CapabilityListener"), onCapabilityChangedListener, new IntentFilter[]{zza});
            }
        }
        z = true;
        zzbq.checkArgument(z, "invalid filter type");
        zza = zzgj.zza("com.google.android.gms.wearable.CAPABILITY_CHANGED", uri, i);
        return zza(zzcm.zzb(onCapabilityChangedListener, getLooper(), "CapabilityListener"), onCapabilityChangedListener, new IntentFilter[]{zza});
    }

    public final Task<Void> addListener(@NonNull OnCapabilityChangedListener onCapabilityChangedListener, @NonNull String str) {
        String str2;
        zzc.zzb(onCapabilityChangedListener, "listener must not be null");
        zzc.zzb(str, "capability must not be null");
        IntentFilter zzny = zzgj.zzny("com.google.android.gms.wearable.CAPABILITY_CHANGED");
        if (!str.startsWith("/")) {
            str2 = "/";
            str = String.valueOf(str);
            str = str.length() != 0 ? str2.concat(str) : new String(str2);
        }
        zzny.addDataPath(str, 0);
        IntentFilter[] intentFilterArr = new IntentFilter[]{zzny};
        Looper looper = getLooper();
        str2 = "CapabilityListener:";
        String valueOf = String.valueOf(str);
        return zza(zzcm.zzb(onCapabilityChangedListener, looper, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2)), new zzae(onCapabilityChangedListener, str), intentFilterArr);
    }

    public final Task<Void> addLocalCapability(@NonNull String str) {
        zzc.zzb(str, "capability must not be null");
        return zzbj.zzb(this.zzlir.addLocalCapability(zzago(), str));
    }

    public final Task<Map<String, CapabilityInfo>> getAllCapabilities(int i) {
        return zzbj.zza(this.zzlir.getAllCapabilities(zzago(), i), zzac.zzgnw);
    }

    public final Task<CapabilityInfo> getCapability(@NonNull String str, int i) {
        zzc.zzb(str, "capability must not be null");
        return zzbj.zza(this.zzlir.getCapability(zzago(), str, i), zzab.zzgnw);
    }

    public final Task<Boolean> removeListener(@NonNull OnCapabilityChangedListener onCapabilityChangedListener) {
        zzc.zzb(onCapabilityChangedListener, "listener must not be null");
        return zza(zzcm.zzb(onCapabilityChangedListener, getLooper(), "CapabilityListener").zzajo());
    }

    public final Task<Boolean> removeListener(@NonNull OnCapabilityChangedListener onCapabilityChangedListener, String str) {
        Object concat;
        zzc.zzb(onCapabilityChangedListener, "listener must not be null");
        zzc.zzb(str, "capability must not be null");
        if (!str.startsWith("/")) {
            String str2 = "/";
            str = String.valueOf(str);
            concat = str.length() != 0 ? str2.concat(str) : new String(str2);
        }
        Looper looper = getLooper();
        String str3 = "CapabilityListener:";
        str = String.valueOf(concat);
        return zza(zzcm.zzb(onCapabilityChangedListener, looper, str.length() != 0 ? str3.concat(str) : new String(str3)).zzajo());
    }

    public final Task<Void> removeLocalCapability(@NonNull String str) {
        zzc.zzb(str, "capability must not be null");
        return zzbj.zzb(this.zzlir.removeLocalCapability(zzago(), str));
    }
}
