package com.google.android.gms.wearable.internal;

import android.os.ParcelFileDescriptor;
import java.util.concurrent.Callable;

final class zzhh implements Callable<Boolean> {
    private /* synthetic */ byte[] zzkrx;
    private /* synthetic */ ParcelFileDescriptor zzllq;

    zzhh(zzhg zzhg, ParcelFileDescriptor parcelFileDescriptor, byte[] bArr) {
        this.zzllq = parcelFileDescriptor;
        this.zzkrx = bArr;
    }

    private final java.lang.Boolean zzbkf() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
        /*
        r8 = this;
        r0 = "WearableClient";
        r1 = 3;
        r0 = android.util.Log.isLoggable(r0, r1);
        r2 = 36;
        if (r0 == 0) goto L_0x0030;
    L_0x000b:
        r0 = "WearableClient";
        r3 = r8.zzllq;
        r3 = java.lang.String.valueOf(r3);
        r4 = java.lang.String.valueOf(r3);
        r4 = r4.length();
        r4 = r4 + r2;
        r5 = new java.lang.StringBuilder;
        r5.<init>(r4);
        r4 = "processAssets: writing data to FD : ";
        r5.append(r4);
        r5.append(r3);
        r3 = r5.toString();
        android.util.Log.d(r0, r3);
    L_0x0030:
        r0 = new android.os.ParcelFileDescriptor$AutoCloseOutputStream;
        r3 = r8.zzllq;
        r0.<init>(r3);
        r3 = 24;
        r4 = r8.zzkrx;	 Catch:{ IOException -> 0x00a8 }
        r0.write(r4);	 Catch:{ IOException -> 0x00a8 }
        r0.flush();	 Catch:{ IOException -> 0x00a8 }
        r4 = "WearableClient";	 Catch:{ IOException -> 0x00a8 }
        r4 = android.util.Log.isLoggable(r4, r1);	 Catch:{ IOException -> 0x00a8 }
        if (r4 == 0) goto L_0x0070;	 Catch:{ IOException -> 0x00a8 }
    L_0x0049:
        r4 = "WearableClient";	 Catch:{ IOException -> 0x00a8 }
        r5 = r8.zzllq;	 Catch:{ IOException -> 0x00a8 }
        r5 = java.lang.String.valueOf(r5);	 Catch:{ IOException -> 0x00a8 }
        r6 = 27;	 Catch:{ IOException -> 0x00a8 }
        r7 = java.lang.String.valueOf(r5);	 Catch:{ IOException -> 0x00a8 }
        r7 = r7.length();	 Catch:{ IOException -> 0x00a8 }
        r6 = r6 + r7;	 Catch:{ IOException -> 0x00a8 }
        r7 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x00a8 }
        r7.<init>(r6);	 Catch:{ IOException -> 0x00a8 }
        r6 = "processAssets: wrote data: ";	 Catch:{ IOException -> 0x00a8 }
        r7.append(r6);	 Catch:{ IOException -> 0x00a8 }
        r7.append(r5);	 Catch:{ IOException -> 0x00a8 }
        r5 = r7.toString();	 Catch:{ IOException -> 0x00a8 }
        android.util.Log.d(r4, r5);	 Catch:{ IOException -> 0x00a8 }
    L_0x0070:
        r4 = 1;	 Catch:{ IOException -> 0x00a8 }
        r4 = java.lang.Boolean.valueOf(r4);	 Catch:{ IOException -> 0x00a8 }
        r2 = "WearableClient";	 Catch:{ IOException -> 0x00a5 }
        r1 = android.util.Log.isLoggable(r2, r1);	 Catch:{ IOException -> 0x00a5 }
        if (r1 == 0) goto L_0x00a2;	 Catch:{ IOException -> 0x00a5 }
    L_0x007d:
        r1 = "WearableClient";	 Catch:{ IOException -> 0x00a5 }
        r2 = r8.zzllq;	 Catch:{ IOException -> 0x00a5 }
        r2 = java.lang.String.valueOf(r2);	 Catch:{ IOException -> 0x00a5 }
        r5 = java.lang.String.valueOf(r2);	 Catch:{ IOException -> 0x00a5 }
        r5 = r5.length();	 Catch:{ IOException -> 0x00a5 }
        r3 = r3 + r5;	 Catch:{ IOException -> 0x00a5 }
        r5 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x00a5 }
        r5.<init>(r3);	 Catch:{ IOException -> 0x00a5 }
        r3 = "processAssets: closing: ";	 Catch:{ IOException -> 0x00a5 }
        r5.append(r3);	 Catch:{ IOException -> 0x00a5 }
        r5.append(r2);	 Catch:{ IOException -> 0x00a5 }
        r2 = r5.toString();	 Catch:{ IOException -> 0x00a5 }
        android.util.Log.d(r1, r2);	 Catch:{ IOException -> 0x00a5 }
    L_0x00a2:
        r0.close();	 Catch:{ IOException -> 0x00a5 }
    L_0x00a5:
        return r4;
    L_0x00a6:
        r2 = move-exception;
        goto L_0x0103;
    L_0x00a8:
        r4 = "WearableClient";	 Catch:{ all -> 0x00a6 }
        r5 = r8.zzllq;	 Catch:{ all -> 0x00a6 }
        r5 = java.lang.String.valueOf(r5);	 Catch:{ all -> 0x00a6 }
        r6 = java.lang.String.valueOf(r5);	 Catch:{ all -> 0x00a6 }
        r6 = r6.length();	 Catch:{ all -> 0x00a6 }
        r2 = r2 + r6;	 Catch:{ all -> 0x00a6 }
        r6 = new java.lang.StringBuilder;	 Catch:{ all -> 0x00a6 }
        r6.<init>(r2);	 Catch:{ all -> 0x00a6 }
        r2 = "processAssets: writing data failed: ";	 Catch:{ all -> 0x00a6 }
        r6.append(r2);	 Catch:{ all -> 0x00a6 }
        r6.append(r5);	 Catch:{ all -> 0x00a6 }
        r2 = r6.toString();	 Catch:{ all -> 0x00a6 }
        android.util.Log.w(r4, r2);	 Catch:{ all -> 0x00a6 }
        r2 = "WearableClient";	 Catch:{ IOException -> 0x00fd }
        r1 = android.util.Log.isLoggable(r2, r1);	 Catch:{ IOException -> 0x00fd }
        if (r1 == 0) goto L_0x00fa;	 Catch:{ IOException -> 0x00fd }
    L_0x00d5:
        r1 = "WearableClient";	 Catch:{ IOException -> 0x00fd }
        r2 = r8.zzllq;	 Catch:{ IOException -> 0x00fd }
        r2 = java.lang.String.valueOf(r2);	 Catch:{ IOException -> 0x00fd }
        r4 = java.lang.String.valueOf(r2);	 Catch:{ IOException -> 0x00fd }
        r4 = r4.length();	 Catch:{ IOException -> 0x00fd }
        r3 = r3 + r4;	 Catch:{ IOException -> 0x00fd }
        r4 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x00fd }
        r4.<init>(r3);	 Catch:{ IOException -> 0x00fd }
        r3 = "processAssets: closing: ";	 Catch:{ IOException -> 0x00fd }
        r4.append(r3);	 Catch:{ IOException -> 0x00fd }
        r4.append(r2);	 Catch:{ IOException -> 0x00fd }
        r2 = r4.toString();	 Catch:{ IOException -> 0x00fd }
        android.util.Log.d(r1, r2);	 Catch:{ IOException -> 0x00fd }
    L_0x00fa:
        r0.close();	 Catch:{ IOException -> 0x00fd }
    L_0x00fd:
        r0 = 0;
        r0 = java.lang.Boolean.valueOf(r0);
        return r0;
    L_0x0103:
        r4 = "WearableClient";	 Catch:{ IOException -> 0x0133 }
        r1 = android.util.Log.isLoggable(r4, r1);	 Catch:{ IOException -> 0x0133 }
        if (r1 == 0) goto L_0x0130;	 Catch:{ IOException -> 0x0133 }
    L_0x010b:
        r1 = "WearableClient";	 Catch:{ IOException -> 0x0133 }
        r4 = r8.zzllq;	 Catch:{ IOException -> 0x0133 }
        r4 = java.lang.String.valueOf(r4);	 Catch:{ IOException -> 0x0133 }
        r5 = java.lang.String.valueOf(r4);	 Catch:{ IOException -> 0x0133 }
        r5 = r5.length();	 Catch:{ IOException -> 0x0133 }
        r3 = r3 + r5;	 Catch:{ IOException -> 0x0133 }
        r5 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x0133 }
        r5.<init>(r3);	 Catch:{ IOException -> 0x0133 }
        r3 = "processAssets: closing: ";	 Catch:{ IOException -> 0x0133 }
        r5.append(r3);	 Catch:{ IOException -> 0x0133 }
        r5.append(r4);	 Catch:{ IOException -> 0x0133 }
        r3 = r5.toString();	 Catch:{ IOException -> 0x0133 }
        android.util.Log.d(r1, r3);	 Catch:{ IOException -> 0x0133 }
    L_0x0130:
        r0.close();	 Catch:{ IOException -> 0x0133 }
    L_0x0133:
        throw r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.wearable.internal.zzhh.zzbkf():java.lang.Boolean");
    }

    public final /* synthetic */ Object call() throws Exception {
        return zzbkf();
    }
}
