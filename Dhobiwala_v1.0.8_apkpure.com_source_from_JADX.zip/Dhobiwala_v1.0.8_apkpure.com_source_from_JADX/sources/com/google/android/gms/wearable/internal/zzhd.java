package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.internal.zzn;
import com.google.android.gms.wearable.CapabilityApi.RemoveLocalCapabilityResult;

final class zzhd extends zzgm<RemoveLocalCapabilityResult> {
    public zzhd(zzn<RemoveLocalCapabilityResult> zzn) {
        super(zzn);
    }

    public final void zza(zzfy zzfy) {
        zzav(new zzu(zzgd.zzdg(zzfy.statusCode)));
    }
}
