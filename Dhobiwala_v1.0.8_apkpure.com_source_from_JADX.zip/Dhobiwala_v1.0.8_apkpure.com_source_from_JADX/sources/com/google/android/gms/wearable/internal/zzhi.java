package com.google.android.gms.wearable.internal;

import android.net.Uri;
import com.google.android.gms.common.api.internal.zzn;

final class zzhi implements Runnable {
    private /* synthetic */ String zzecf;
    private /* synthetic */ Uri zzjvt;
    private /* synthetic */ boolean zzljg;
    private /* synthetic */ zzn zzllr;
    private /* synthetic */ zzhg zzlls;

    zzhi(zzhg zzhg, Uri uri, zzn zzn, boolean z, String str) {
        this.zzlls = zzhg;
        this.zzjvt = uri;
        this.zzllr = zzn;
        this.zzljg = z;
        this.zzecf = str;
    }

    public final void run() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
        /*
        r4 = this;
        r0 = "WearableClient";
        r1 = 2;
        r0 = android.util.Log.isLoggable(r0, r1);
        if (r0 == 0) goto L_0x0010;
    L_0x0009:
        r0 = "WearableClient";
        r1 = "Executing receiveFileFromChannelTask";
        android.util.Log.v(r0, r1);
    L_0x0010:
        r0 = "file";
        r1 = r4.zzjvt;
        r1 = r1.getScheme();
        r0 = r0.equals(r1);
        if (r0 != 0) goto L_0x0034;
    L_0x001e:
        r0 = "WearableClient";
        r1 = "Channel.receiveFile used with non-file URI";
        android.util.Log.w(r0, r1);
        r0 = r4.zzllr;
        r1 = new com.google.android.gms.common.api.Status;
        r2 = 10;
        r3 = "Channel.receiveFile used with non-file URI";
        r1.<init>(r2, r3);
        r0.zzu(r1);
        return;
    L_0x0034:
        r0 = new java.io.File;
        r1 = r4.zzjvt;
        r1 = r1.getPath();
        r0.<init>(r1);
        r1 = 671088640; // 0x28000000 float:7.1054274E-15 double:3.315618423E-315;
        r2 = r4.zzljg;
        if (r2 == 0) goto L_0x0048;
    L_0x0045:
        r2 = 33554432; // 0x2000000 float:9.403955E-38 double:1.6578092E-316;
        goto L_0x0049;
    L_0x0048:
        r2 = 0;
    L_0x0049:
        r1 = r1 | r2;
        r1 = android.os.ParcelFileDescriptor.open(r0, r1);	 Catch:{ FileNotFoundException -> 0x009f }
        r0 = r4.zzlls;	 Catch:{ RemoteException -> 0x0071 }
        r0 = r0.zzakn();	 Catch:{ RemoteException -> 0x0071 }
        r0 = (com.google.android.gms.wearable.internal.zzep) r0;	 Catch:{ RemoteException -> 0x0071 }
        r2 = new com.google.android.gms.wearable.internal.zzhf;	 Catch:{ RemoteException -> 0x0071 }
        r3 = r4.zzllr;	 Catch:{ RemoteException -> 0x0071 }
        r2.<init>(r3);	 Catch:{ RemoteException -> 0x0071 }
        r3 = r4.zzecf;	 Catch:{ RemoteException -> 0x0071 }
        r0.zza(r2, r3, r1);	 Catch:{ RemoteException -> 0x0071 }
        r1.close();	 Catch:{ IOException -> 0x0066 }
        return;
    L_0x0066:
        r0 = move-exception;
        r1 = "WearableClient";
        r2 = "Failed to close targetFd";
        android.util.Log.w(r1, r2, r0);
        return;
    L_0x006f:
        r0 = move-exception;
        goto L_0x0092;
    L_0x0071:
        r0 = move-exception;
        r2 = "WearableClient";	 Catch:{ all -> 0x006f }
        r3 = "Channel.receiveFile failed.";	 Catch:{ all -> 0x006f }
        android.util.Log.w(r2, r3, r0);	 Catch:{ all -> 0x006f }
        r0 = r4.zzllr;	 Catch:{ all -> 0x006f }
        r2 = new com.google.android.gms.common.api.Status;	 Catch:{ all -> 0x006f }
        r3 = 8;	 Catch:{ all -> 0x006f }
        r2.<init>(r3);	 Catch:{ all -> 0x006f }
        r0.zzu(r2);	 Catch:{ all -> 0x006f }
        r1.close();	 Catch:{ IOException -> 0x0089 }
        return;
    L_0x0089:
        r0 = move-exception;
        r1 = "WearableClient";
        r2 = "Failed to close targetFd";
        android.util.Log.w(r1, r2, r0);
        return;
    L_0x0092:
        r1.close();	 Catch:{ IOException -> 0x0096 }
        goto L_0x009e;
    L_0x0096:
        r1 = move-exception;
        r2 = "WearableClient";
        r3 = "Failed to close targetFd";
        android.util.Log.w(r2, r3, r1);
    L_0x009e:
        throw r0;
    L_0x009f:
        r1 = "WearableClient";
        r0 = java.lang.String.valueOf(r0);
        r2 = 49;
        r3 = java.lang.String.valueOf(r0);
        r3 = r3.length();
        r2 = r2 + r3;
        r3 = new java.lang.StringBuilder;
        r3.<init>(r2);
        r2 = "File couldn't be opened for Channel.receiveFile: ";
        r3.append(r2);
        r3.append(r0);
        r0 = r3.toString();
        android.util.Log.w(r1, r0);
        r0 = r4.zzllr;
        r1 = new com.google.android.gms.common.api.Status;
        r2 = 13;
        r1.<init>(r2);
        r0.zzu(r1);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.wearable.internal.zzhi.run():void");
    }
}
