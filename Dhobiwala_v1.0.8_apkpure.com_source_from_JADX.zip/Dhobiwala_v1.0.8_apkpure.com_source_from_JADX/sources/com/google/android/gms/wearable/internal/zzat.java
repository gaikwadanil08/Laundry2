package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.RemoteException;
import com.google.android.gms.common.api.Api.zzb;
import com.google.android.gms.common.api.internal.zzci;
import com.google.android.gms.common.api.internal.zzcq;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;
import com.google.android.gms.wearable.ChannelClient.ChannelCallback;

final class zzat extends zzcq<zzhg, ChannelCallback> {
    private String zzldj;
    private IntentFilter[] zzlhy;
    private ChannelListener zzlja;
    private zzci<ChannelListener> zzljb;

    zzat(ChannelListener channelListener, String str, IntentFilter[] intentFilterArr, zzci<ChannelCallback> zzci, zzci<ChannelListener> zzci2) {
        super(zzci);
        this.zzlja = channelListener;
        this.zzlhy = intentFilterArr;
        this.zzldj = str;
        this.zzljb = zzci2;
    }

    protected final /* synthetic */ void zzb(zzb zzb, TaskCompletionSource taskCompletionSource) throws RemoteException {
        ((zzhg) zzb).zza(new zzgh(taskCompletionSource), this.zzlja, this.zzljb, this.zzldj, this.zzlhy);
    }
}
