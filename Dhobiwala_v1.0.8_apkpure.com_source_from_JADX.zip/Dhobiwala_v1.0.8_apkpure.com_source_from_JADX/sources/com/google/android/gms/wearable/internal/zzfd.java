package com.google.android.gms.wearable.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api.zzb;
import com.google.android.gms.common.api.internal.zzck;
import com.google.android.gms.common.api.internal.zzdn;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.wearable.MessageClient.OnMessageReceivedListener;

final class zzfd extends zzdn<zzhg, OnMessageReceivedListener> {
    private final OnMessageReceivedListener zzlkv;

    private zzfd(OnMessageReceivedListener onMessageReceivedListener, zzck<OnMessageReceivedListener> zzck) {
        super(zzck);
        this.zzlkv = onMessageReceivedListener;
    }

    protected final /* synthetic */ void zzc(zzb zzb, TaskCompletionSource taskCompletionSource) throws RemoteException {
        ((zzhg) zzb).zza(new zzgg(taskCompletionSource), this.zzlkv);
    }
}
