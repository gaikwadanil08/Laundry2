package com.google.android.gms.wearable.internal;

import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.zzn;
import java.util.HashMap;
import java.util.Map;

final class zzer<T> {
    private final Map<T, zzhk<T>> zzhhi = new HashMap();

    zzer() {
    }

    public final void zza(zzhg zzhg, zzn<Status> zzn, T t) throws RemoteException {
        synchronized (this.zzhhi) {
            zzhk zzhk = (zzhk) this.zzhhi.remove(t);
            if (zzhk == null) {
                if (Log.isLoggable("WearableClient", 2)) {
                    String valueOf = String.valueOf(t);
                    StringBuilder stringBuilder = new StringBuilder(25 + String.valueOf(valueOf).length());
                    stringBuilder.append("remove Listener unknown: ");
                    stringBuilder.append(valueOf);
                    Log.v("WearableClient", stringBuilder.toString());
                }
                zzn.setResult(new Status(4002));
                return;
            }
            zzhk.clear();
            if (Log.isLoggable("WearableClient", 2)) {
                String valueOf2 = String.valueOf(t);
                StringBuilder stringBuilder2 = new StringBuilder(24 + String.valueOf(valueOf2).length());
                stringBuilder2.append("service.removeListener: ");
                stringBuilder2.append(valueOf2);
                Log.v("WearableClient", stringBuilder2.toString());
            }
            ((zzep) zzhg.zzakn()).zza(new zzet(this.zzhhi, t, zzn), new zzfw(zzhk));
        }
    }

    public final void zza(zzhg zzhg, zzn<Status> zzn, T t, zzhk<T> zzhk) throws RemoteException {
        synchronized (this.zzhhi) {
            if (this.zzhhi.get(t) != null) {
                if (Log.isLoggable("WearableClient", 2)) {
                    String valueOf = String.valueOf(t);
                    StringBuilder stringBuilder = new StringBuilder(20 + String.valueOf(valueOf).length());
                    stringBuilder.append("duplicate listener: ");
                    stringBuilder.append(valueOf);
                    Log.v("WearableClient", stringBuilder.toString());
                }
                zzn.setResult(new Status(4001));
                return;
            }
            if (Log.isLoggable("WearableClient", 2)) {
                String valueOf2 = String.valueOf(t);
                StringBuilder stringBuilder2 = new StringBuilder(14 + String.valueOf(valueOf2).length());
                stringBuilder2.append("new listener: ");
                stringBuilder2.append(valueOf2);
                Log.v("WearableClient", stringBuilder2.toString());
            }
            this.zzhhi.put(t, zzhk);
            try {
                ((zzep) zzhg.zzakn()).zza(new zzes(this.zzhhi, t, zzn), new zzd(zzhk));
            } catch (RemoteException e) {
                if (Log.isLoggable("WearableClient", 3)) {
                    String valueOf3 = String.valueOf(t);
                    StringBuilder stringBuilder3 = new StringBuilder(39 + String.valueOf(valueOf3).length());
                    stringBuilder3.append("addListener failed, removing listener: ");
                    stringBuilder3.append(valueOf3);
                    Log.d("WearableClient", stringBuilder3.toString());
                }
                this.zzhhi.remove(t);
                throw e;
            }
        }
    }

    public final void zzbr(android.os.IBinder r11) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/384515747.run(Unknown Source)
*/
        /*
        r10 = this;
        r0 = r10.zzhhi;
        monitor-enter(r0);
        if (r11 != 0) goto L_0x0007;
    L_0x0005:
        r11 = 0;
        goto L_0x001b;
    L_0x0007:
        r1 = "com.google.android.gms.wearable.internal.IWearableService";	 Catch:{ all -> 0x00ce }
        r1 = r11.queryLocalInterface(r1);	 Catch:{ all -> 0x00ce }
        r2 = r1 instanceof com.google.android.gms.wearable.internal.zzep;	 Catch:{ all -> 0x00ce }
        if (r2 == 0) goto L_0x0015;	 Catch:{ all -> 0x00ce }
    L_0x0011:
        r11 = r1;	 Catch:{ all -> 0x00ce }
        r11 = (com.google.android.gms.wearable.internal.zzep) r11;	 Catch:{ all -> 0x00ce }
        goto L_0x001b;	 Catch:{ all -> 0x00ce }
    L_0x0015:
        r1 = new com.google.android.gms.wearable.internal.zzeq;	 Catch:{ all -> 0x00ce }
        r1.<init>(r11);	 Catch:{ all -> 0x00ce }
        r11 = r1;	 Catch:{ all -> 0x00ce }
    L_0x001b:
        r1 = new com.google.android.gms.wearable.internal.zzgz;	 Catch:{ all -> 0x00ce }
        r1.<init>();	 Catch:{ all -> 0x00ce }
        r2 = r10.zzhhi;	 Catch:{ all -> 0x00ce }
        r2 = r2.entrySet();	 Catch:{ all -> 0x00ce }
        r2 = r2.iterator();	 Catch:{ all -> 0x00ce }
    L_0x002a:
        r3 = r2.hasNext();	 Catch:{ all -> 0x00ce }
        if (r3 == 0) goto L_0x00cc;	 Catch:{ all -> 0x00ce }
    L_0x0030:
        r3 = r2.next();	 Catch:{ all -> 0x00ce }
        r3 = (java.util.Map.Entry) r3;	 Catch:{ all -> 0x00ce }
        r4 = r3.getValue();	 Catch:{ all -> 0x00ce }
        r4 = (com.google.android.gms.wearable.internal.zzhk) r4;	 Catch:{ all -> 0x00ce }
        r5 = new com.google.android.gms.wearable.internal.zzd;	 Catch:{ RemoteException -> 0x008c }
        r5.<init>(r4);	 Catch:{ RemoteException -> 0x008c }
        r11.zza(r1, r5);	 Catch:{ RemoteException -> 0x008c }
        r5 = "WearableClient";	 Catch:{ RemoteException -> 0x008c }
        r6 = 3;	 Catch:{ RemoteException -> 0x008c }
        r5 = android.util.Log.isLoggable(r5, r6);	 Catch:{ RemoteException -> 0x008c }
        if (r5 == 0) goto L_0x002a;	 Catch:{ RemoteException -> 0x008c }
    L_0x004d:
        r5 = "WearableClient";	 Catch:{ RemoteException -> 0x008c }
        r6 = r3.getKey();	 Catch:{ RemoteException -> 0x008c }
        r6 = java.lang.String.valueOf(r6);	 Catch:{ RemoteException -> 0x008c }
        r7 = java.lang.String.valueOf(r4);	 Catch:{ RemoteException -> 0x008c }
        r8 = 27;	 Catch:{ RemoteException -> 0x008c }
        r9 = java.lang.String.valueOf(r6);	 Catch:{ RemoteException -> 0x008c }
        r9 = r9.length();	 Catch:{ RemoteException -> 0x008c }
        r8 = r8 + r9;	 Catch:{ RemoteException -> 0x008c }
        r9 = java.lang.String.valueOf(r7);	 Catch:{ RemoteException -> 0x008c }
        r9 = r9.length();	 Catch:{ RemoteException -> 0x008c }
        r8 = r8 + r9;	 Catch:{ RemoteException -> 0x008c }
        r9 = new java.lang.StringBuilder;	 Catch:{ RemoteException -> 0x008c }
        r9.<init>(r8);	 Catch:{ RemoteException -> 0x008c }
        r8 = "onPostInitHandler: added: ";	 Catch:{ RemoteException -> 0x008c }
        r9.append(r8);	 Catch:{ RemoteException -> 0x008c }
        r9.append(r6);	 Catch:{ RemoteException -> 0x008c }
        r6 = "/";	 Catch:{ RemoteException -> 0x008c }
        r9.append(r6);	 Catch:{ RemoteException -> 0x008c }
        r9.append(r7);	 Catch:{ RemoteException -> 0x008c }
        r6 = r9.toString();	 Catch:{ RemoteException -> 0x008c }
        android.util.Log.d(r5, r6);	 Catch:{ RemoteException -> 0x008c }
        goto L_0x002a;
    L_0x008c:
        r5 = "WearableClient";	 Catch:{ all -> 0x00ce }
        r3 = r3.getKey();	 Catch:{ all -> 0x00ce }
        r3 = java.lang.String.valueOf(r3);	 Catch:{ all -> 0x00ce }
        r4 = java.lang.String.valueOf(r4);	 Catch:{ all -> 0x00ce }
        r6 = 32;	 Catch:{ all -> 0x00ce }
        r7 = java.lang.String.valueOf(r3);	 Catch:{ all -> 0x00ce }
        r7 = r7.length();	 Catch:{ all -> 0x00ce }
        r6 = r6 + r7;	 Catch:{ all -> 0x00ce }
        r7 = java.lang.String.valueOf(r4);	 Catch:{ all -> 0x00ce }
        r7 = r7.length();	 Catch:{ all -> 0x00ce }
        r6 = r6 + r7;	 Catch:{ all -> 0x00ce }
        r7 = new java.lang.StringBuilder;	 Catch:{ all -> 0x00ce }
        r7.<init>(r6);	 Catch:{ all -> 0x00ce }
        r6 = "onPostInitHandler: Didn't add: ";	 Catch:{ all -> 0x00ce }
        r7.append(r6);	 Catch:{ all -> 0x00ce }
        r7.append(r3);	 Catch:{ all -> 0x00ce }
        r3 = "/";	 Catch:{ all -> 0x00ce }
        r7.append(r3);	 Catch:{ all -> 0x00ce }
        r7.append(r4);	 Catch:{ all -> 0x00ce }
        r3 = r7.toString();	 Catch:{ all -> 0x00ce }
        android.util.Log.w(r5, r3);	 Catch:{ all -> 0x00ce }
        goto L_0x002a;	 Catch:{ all -> 0x00ce }
    L_0x00cc:
        monitor-exit(r0);	 Catch:{ all -> 0x00ce }
        return;	 Catch:{ all -> 0x00ce }
    L_0x00ce:
        r11 = move-exception;	 Catch:{ all -> 0x00ce }
        monitor-exit(r0);	 Catch:{ all -> 0x00ce }
        throw r11;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.wearable.internal.zzer.zzbr(android.os.IBinder):void");
    }
}
