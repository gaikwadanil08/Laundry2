package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.util.Log;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataItemAsset;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public final class zzdc implements DataItem {
    private Uri mUri;
    private byte[] zzhyw;
    private Map<String, DataItemAsset> zzlkc;

    public zzdc(DataItem dataItem) {
        this.mUri = dataItem.getUri();
        this.zzhyw = dataItem.getData();
        Map hashMap = new HashMap();
        for (Entry entry : dataItem.getAssets().entrySet()) {
            if (entry.getKey() != null) {
                hashMap.put((String) entry.getKey(), (DataItemAsset) ((DataItemAsset) entry.getValue()).freeze());
            }
        }
        this.zzlkc = Collections.unmodifiableMap(hashMap);
    }

    public final /* bridge */ /* synthetic */ Object freeze() {
        if (this != null) {
            return this;
        }
        throw null;
    }

    public final Map<String, DataItemAsset> getAssets() {
        return this.zzlkc;
    }

    public final byte[] getData() {
        return this.zzhyw;
    }

    public final Uri getUri() {
        return this.mUri;
    }

    public final boolean isDataValid() {
        return true;
    }

    public final DataItem setData(byte[] bArr) {
        throw new UnsupportedOperationException();
    }

    public final String toString() {
        boolean isLoggable = Log.isLoggable("DataItem", 3);
        StringBuilder stringBuilder = new StringBuilder("DataItemEntity{ ");
        String valueOf = String.valueOf(this.mUri);
        StringBuilder stringBuilder2 = new StringBuilder(4 + String.valueOf(valueOf).length());
        stringBuilder2.append("uri=");
        stringBuilder2.append(valueOf);
        stringBuilder.append(stringBuilder2.toString());
        valueOf = String.valueOf(this.zzhyw == null ? "null" : Integer.valueOf(this.zzhyw.length));
        StringBuilder stringBuilder3 = new StringBuilder(9 + String.valueOf(valueOf).length());
        stringBuilder3.append(", dataSz=");
        stringBuilder3.append(valueOf);
        stringBuilder.append(stringBuilder3.toString());
        int size = this.zzlkc.size();
        stringBuilder3 = new StringBuilder(23);
        stringBuilder3.append(", numAssets=");
        stringBuilder3.append(size);
        stringBuilder.append(stringBuilder3.toString());
        if (isLoggable && !this.zzlkc.isEmpty()) {
            stringBuilder.append(", assets=[");
            String str = "";
            for (Entry entry : this.zzlkc.entrySet()) {
                String str2 = (String) entry.getKey();
                String id = ((DataItemAsset) entry.getValue()).getId();
                StringBuilder stringBuilder4 = new StringBuilder(((2 + String.valueOf(str).length()) + String.valueOf(str2).length()) + String.valueOf(id).length());
                stringBuilder4.append(str);
                stringBuilder4.append(str2);
                stringBuilder4.append(": ");
                stringBuilder4.append(id);
                stringBuilder.append(stringBuilder4.toString());
                str = ", ";
            }
            stringBuilder.append("]");
        }
        stringBuilder.append(" }");
        return stringBuilder.toString();
    }
}
