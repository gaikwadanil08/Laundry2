package com.google.android.gms.wearable.internal;

final class zzbk implements zzbs {
    private /* synthetic */ zzbj zzljn;

    zzbk(zzbj zzbj) {
        this.zzljn = zzbj;
    }

    public final void zzb(zzav zzav) {
        this.zzljn.zza(zzav);
    }
}
