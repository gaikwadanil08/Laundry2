package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;

public final class zzl extends zzbfm {
    public static final Creator<zzl> CREATOR = new zzm();
    private final String mAppId;
    private int mId;
    private final String mPackageName;
    private final String zzegt;
    private final String zzemt;
    private final String zzepx;
    private final String zzlid;
    private final String zzlie;
    private final byte zzlif;
    private final byte zzlig;
    private final byte zzlih;
    private final byte zzlii;

    public zzl(int i, String str, String str2, String str3, String str4, String str5, String str6, byte b, byte b2, byte b3, byte b4, String str7) {
        this.mId = i;
        this.mAppId = str;
        this.zzlid = str2;
        this.zzepx = str3;
        this.zzemt = str4;
        this.zzlie = str5;
        this.zzegt = str6;
        this.zzlif = b;
        this.zzlig = b2;
        this.zzlih = b3;
        this.zzlii = b4;
        this.mPackageName = str7;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        zzl zzl = (zzl) obj;
        if (this.mId != zzl.mId || this.zzlif != zzl.zzlif || this.zzlig != zzl.zzlig || this.zzlih != zzl.zzlih || this.zzlii != zzl.zzlii || !this.mAppId.equals(zzl.mAppId)) {
            return false;
        }
        if (this.zzlid != null) {
            if (!this.zzlid.equals(zzl.zzlid)) {
                return false;
            }
        } else if (zzl.zzlid != null) {
            return false;
        }
        if (!this.zzepx.equals(zzl.zzepx) || !this.zzemt.equals(zzl.zzemt) || !this.zzlie.equals(zzl.zzlie)) {
            return false;
        }
        if (this.zzegt != null) {
            if (!this.zzegt.equals(zzl.zzegt)) {
                return false;
            }
        } else if (zzl.zzegt != null) {
            return false;
        }
        return this.mPackageName != null ? this.mPackageName.equals(zzl.mPackageName) : zzl.mPackageName == null;
    }

    public final int hashCode() {
        int i = 0;
        int hashCode = (((((((((((((((((((((this.mId + 31) * 31) + this.mAppId.hashCode()) * 31) + (this.zzlid != null ? this.zzlid.hashCode() : 0)) * 31) + this.zzepx.hashCode()) * 31) + this.zzemt.hashCode()) * 31) + this.zzlie.hashCode()) * 31) + (this.zzegt != null ? this.zzegt.hashCode() : 0)) * 31) + this.zzlif) * 31) + this.zzlig) * 31) + this.zzlih) * 31) + this.zzlii) * 31;
        if (this.mPackageName != null) {
            i = this.mPackageName.hashCode();
        }
        return hashCode + i;
    }

    public final String toString() {
        int i = this.mId;
        String str = this.mAppId;
        String str2 = this.zzlid;
        String str3 = this.zzepx;
        String str4 = this.zzemt;
        String str5 = this.zzlie;
        String str6 = this.zzegt;
        byte b = this.zzlif;
        byte b2 = this.zzlig;
        byte b3 = this.zzlih;
        byte b4 = this.zzlii;
        String str7 = this.mPackageName;
        StringBuilder stringBuilder = new StringBuilder(((((((211 + String.valueOf(str).length()) + String.valueOf(str2).length()) + String.valueOf(str3).length()) + String.valueOf(str4).length()) + String.valueOf(str5).length()) + String.valueOf(str6).length()) + String.valueOf(str7).length());
        stringBuilder.append("AncsNotificationParcelable{, id=");
        stringBuilder.append(i);
        stringBuilder.append(", appId='");
        stringBuilder.append(str);
        stringBuilder.append("', dateTime='");
        stringBuilder.append(str2);
        stringBuilder.append("', notificationText='");
        stringBuilder.append(str3);
        stringBuilder.append("', title='");
        stringBuilder.append(str4);
        stringBuilder.append("', subtitle='");
        stringBuilder.append(str5);
        stringBuilder.append("', displayName='");
        stringBuilder.append(str6);
        stringBuilder.append("', eventId=");
        stringBuilder.append(b);
        stringBuilder.append(", eventFlags=");
        stringBuilder.append(b2);
        stringBuilder.append(", categoryId=");
        stringBuilder.append(b3);
        stringBuilder.append(", categoryCount=");
        stringBuilder.append(b4);
        stringBuilder.append(", packageName='");
        stringBuilder.append(str7);
        stringBuilder.append("'}");
        return stringBuilder.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zzc(parcel, 2, this.mId);
        zzbfp.zza(parcel, 3, this.mAppId, false);
        zzbfp.zza(parcel, 4, this.zzlid, false);
        zzbfp.zza(parcel, 5, this.zzepx, false);
        zzbfp.zza(parcel, 6, this.zzemt, false);
        zzbfp.zza(parcel, 7, this.zzlie, false);
        zzbfp.zza(parcel, 8, this.zzegt == null ? this.mAppId : this.zzegt, false);
        zzbfp.zza(parcel, 9, this.zzlif);
        zzbfp.zza(parcel, 10, this.zzlig);
        zzbfp.zza(parcel, 11, this.zzlih);
        zzbfp.zza(parcel, 12, this.zzlii);
        zzbfp.zza(parcel, 13, this.mPackageName, false);
        zzbfp.zzai(parcel, i);
    }
}
