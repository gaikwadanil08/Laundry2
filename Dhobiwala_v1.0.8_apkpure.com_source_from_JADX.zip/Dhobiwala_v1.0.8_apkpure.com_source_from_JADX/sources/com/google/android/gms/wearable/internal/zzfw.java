package com.google.android.gms.wearable.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;

public final class zzfw extends zzbfm {
    public static final Creator<zzfw> CREATOR = new zzfx();
    private int zzeck;
    private zzem zzlhx;

    zzfw(int i, IBinder iBinder) {
        this.zzeck = i;
        zzem zzem = null;
        if (iBinder != null) {
            if (iBinder != null) {
                IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.wearable.internal.IWearableListener");
                zzem = queryLocalInterface instanceof zzem ? (zzem) queryLocalInterface : new zzeo(iBinder);
            }
            this.zzlhx = zzem;
            return;
        }
        this.zzlhx = null;
    }

    public zzfw(zzem zzem) {
        this.zzeck = 1;
        this.zzlhx = zzem;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zzc(parcel, 1, this.zzeck);
        zzbfp.zza(parcel, 2, this.zzlhx == null ? null : this.zzlhx.asBinder(), false);
        zzbfp.zzai(parcel, i);
    }
}
