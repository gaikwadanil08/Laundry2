package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.internal.zzbq;

public final class zzbr extends zzej {
    private final Object mLock = new Object();
    private zzav zzljm;
    private zzbs zzljq;

    public final void zza(zzbs zzbs) {
        synchronized (this.mLock) {
            this.zzljq = (zzbs) zzbq.checkNotNull(zzbs);
            zzav zzav = this.zzljm;
        }
        if (zzav != null) {
            zzbs.zzb(zzav);
        }
    }

    public final void zzs(int i, int i2) {
        synchronized (this.mLock) {
            zzbs zzbs = this.zzljq;
            zzav zzav = new zzav(i, i2);
            this.zzljm = zzav;
        }
        if (zzbs != null) {
            zzbs.zzb(zzav);
        }
    }
}
