package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataItem;

public final class zzcx implements DataEvent {
    private int zzeie;
    private DataItem zzljw;

    public zzcx(DataEvent dataEvent) {
        this.zzeie = dataEvent.getType();
        this.zzljw = (DataItem) dataEvent.getDataItem().freeze();
    }

    public final /* bridge */ /* synthetic */ Object freeze() {
        if (this != null) {
            return this;
        }
        throw null;
    }

    public final DataItem getDataItem() {
        return this.zzljw;
    }

    public final int getType() {
        return this.zzeie;
    }

    public final boolean isDataValid() {
        return true;
    }

    public final String toString() {
        String str = getType() == 1 ? "changed" : getType() == 2 ? "deleted" : "unknown";
        String valueOf = String.valueOf(getDataItem());
        StringBuilder stringBuilder = new StringBuilder((35 + String.valueOf(str).length()) + String.valueOf(valueOf).length());
        stringBuilder.append("DataEventEntity{ type=");
        stringBuilder.append(str);
        stringBuilder.append(", dataitem=");
        stringBuilder.append(valueOf);
        stringBuilder.append(" }");
        return stringBuilder.toString();
    }
}
