package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.zzn;
import java.lang.ref.WeakReference;
import java.util.Map;

final class zzet<T> extends zzgm<Status> {
    private WeakReference<Map<T, zzhk<T>>> zzlkp;
    private WeakReference<T> zzlkq;

    zzet(Map<T, zzhk<T>> map, T t, zzn<Status> zzn) {
        super(zzn);
        this.zzlkp = new WeakReference(map);
        this.zzlkq = new WeakReference(t);
    }

    public final void zza(Status status) {
        Map map = (Map) this.zzlkp.get();
        Object obj = this.zzlkq.get();
        if (!(status.getStatus().getStatusCode() != 4002 || map == null || obj == null)) {
            synchronized (map) {
                zzhk zzhk = (zzhk) map.remove(obj);
                if (zzhk != null) {
                    zzhk.clear();
                }
            }
        }
        zzav(status);
    }
}
