package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.zzn;
import com.google.android.gms.tasks.TaskCompletionSource;

final class zzgh implements zzn<Status> {
    private TaskCompletionSource<Void> zzlle;

    zzgh(TaskCompletionSource<Void> taskCompletionSource) {
        this.zzlle = taskCompletionSource;
    }

    public final /* synthetic */ void setResult(Object obj) {
        Status status = (Status) obj;
        int statusCode = status.getStatusCode();
        if (statusCode != 0) {
            if (statusCode != 4001) {
                zzu(status);
                return;
            }
        }
        this.zzlle.setResult(null);
    }

    public final void zzu(Status status) {
        this.zzlle.setException(new ApiException(status));
    }
}
