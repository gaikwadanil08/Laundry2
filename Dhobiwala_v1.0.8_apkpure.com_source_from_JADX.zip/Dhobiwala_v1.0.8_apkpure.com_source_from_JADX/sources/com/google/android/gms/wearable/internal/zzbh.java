package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.wearable.Channel.GetOutputStreamResult;
import java.io.OutputStream;

final class zzbh implements GetOutputStreamResult {
    private final Status mStatus;
    private final OutputStream zzljk;

    zzbh(Status status, OutputStream outputStream) {
        this.mStatus = (Status) zzbq.checkNotNull(status);
        this.zzljk = outputStream;
    }

    public final OutputStream getOutputStream() {
        return this.zzljk;
    }

    public final Status getStatus() {
        return this.mStatus;
    }

    public final void release() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
*/
        /*
        r1 = this;
        r0 = r1.zzljk;
        if (r0 == 0) goto L_0x0009;
    L_0x0004:
        r0 = r1.zzljk;	 Catch:{ IOException -> 0x0009 }
        r0.close();	 Catch:{ IOException -> 0x0009 }
    L_0x0009:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.wearable.internal.zzbh.release():void");
    }
}
