package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;
import com.google.android.gms.wearable.DataItemAsset;

@KeepName
public class DataItemAssetParcelable extends zzbfm implements ReflectedParcelable, DataItemAsset {
    public static final Creator<DataItemAssetParcelable> CREATOR = new zzda();
    private final String zzbhb;
    private final String zzbuz;

    public DataItemAssetParcelable(DataItemAsset dataItemAsset) {
        this.zzbuz = (String) zzbq.checkNotNull(dataItemAsset.getId());
        this.zzbhb = (String) zzbq.checkNotNull(dataItemAsset.getDataItemKey());
    }

    DataItemAssetParcelable(String str, String str2) {
        this.zzbuz = str;
        this.zzbhb = str2;
    }

    public /* bridge */ /* synthetic */ Object freeze() {
        if (this != null) {
            return this;
        }
        throw null;
    }

    public String getDataItemKey() {
        return this.zzbhb;
    }

    public String getId() {
        return this.zzbuz;
    }

    public boolean isDataValid() {
        return true;
    }

    public String toString() {
        String str;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DataItemAssetParcelable[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        if (this.zzbuz == null) {
            str = ",noid";
        } else {
            stringBuilder.append(",");
            str = this.zzbuz;
        }
        stringBuilder.append(str);
        stringBuilder.append(", key=");
        stringBuilder.append(this.zzbhb);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, getId(), false);
        zzbfp.zza(parcel, 3, getDataItemKey(), false);
        zzbfp.zzai(parcel, i);
    }
}
