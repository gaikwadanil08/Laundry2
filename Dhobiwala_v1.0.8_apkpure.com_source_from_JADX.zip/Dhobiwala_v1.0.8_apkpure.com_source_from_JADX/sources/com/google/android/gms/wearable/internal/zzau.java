package com.google.android.gms.wearable.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api.zzb;
import com.google.android.gms.common.api.internal.zzck;
import com.google.android.gms.common.api.internal.zzdn;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;
import com.google.android.gms.wearable.ChannelClient.ChannelCallback;

final class zzau extends zzdn<zzhg, ChannelCallback> {
    private final String zzldj;
    private final ChannelListener zzlja;

    zzau(ChannelListener channelListener, String str, zzck<ChannelCallback> zzck) {
        super(zzck);
        this.zzlja = channelListener;
        this.zzldj = str;
    }

    protected final /* synthetic */ void zzc(zzb zzb, TaskCompletionSource taskCompletionSource) throws RemoteException {
        ((zzhg) zzb).zza(new zzgg(taskCompletionSource), this.zzlja, this.zzldj);
    }
}
