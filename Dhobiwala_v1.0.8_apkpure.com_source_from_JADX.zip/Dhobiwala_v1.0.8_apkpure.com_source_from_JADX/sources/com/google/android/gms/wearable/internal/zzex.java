package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.RemoteException;
import com.google.android.gms.common.api.Api.zzb;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.zzci;
import com.google.android.gms.common.api.internal.zzn;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.wearable.MessageApi.MessageListener;

final class zzex extends zzn<Status> {
    private zzci<MessageListener> zzfus;
    private MessageListener zzlks;
    private IntentFilter[] zzlkt;

    private zzex(GoogleApiClient googleApiClient, MessageListener messageListener, zzci<MessageListener> zzci, IntentFilter[] intentFilterArr) {
        super(googleApiClient);
        this.zzlks = (MessageListener) zzbq.checkNotNull(messageListener);
        this.zzfus = (zzci) zzbq.checkNotNull(zzci);
        this.zzlkt = (IntentFilter[]) zzbq.checkNotNull(intentFilterArr);
    }

    protected final /* synthetic */ void zza(zzb zzb) throws RemoteException {
        ((zzhg) zzb).zza((zzn) this, this.zzlks, this.zzfus, this.zzlkt);
        this.zzlks = null;
        this.zzfus = null;
        this.zzlkt = null;
    }

    public final /* synthetic */ Result zzb(Status status) {
        this.zzlks = null;
        this.zzfus = null;
        this.zzlkt = null;
        return status;
    }
}
