package com.google.android.gms.wearable.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api.zzb;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;

final class zzaz extends zzn<Status> {
    private /* synthetic */ zzay zzljf;

    zzaz(zzay zzay, GoogleApiClient googleApiClient) {
        this.zzljf = zzay;
        super(googleApiClient);
    }

    protected final /* synthetic */ void zza(zzb zzb) throws RemoteException {
        zzhg zzhg = (zzhg) zzb;
        ((zzep) zzhg.zzakn()).zzc(new zzgn(this), this.zzljf.zzecl);
    }

    protected final /* synthetic */ Result zzb(Status status) {
        return status;
    }
}
