package com.google.android.gms.wearable.internal;

import android.os.ParcelFileDescriptor;
import android.os.ParcelFileDescriptor.AutoCloseInputStream;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.wearable.DataApi.GetFdForAssetResult;
import java.io.InputStream;

public final class zzci implements GetFdForAssetResult {
    private volatile boolean mClosed = false;
    private final Status mStatus;
    private volatile InputStream zzljj;
    private volatile ParcelFileDescriptor zzljy;

    public zzci(Status status, ParcelFileDescriptor parcelFileDescriptor) {
        this.mStatus = status;
        this.zzljy = parcelFileDescriptor;
    }

    public final ParcelFileDescriptor getFd() {
        if (!this.mClosed) {
            return this.zzljy;
        }
        throw new IllegalStateException("Cannot access the file descriptor after release().");
    }

    public final InputStream getInputStream() {
        if (this.mClosed) {
            throw new IllegalStateException("Cannot access the input stream after release().");
        } else if (this.zzljy == null) {
            return null;
        } else {
            if (this.zzljj == null) {
                this.zzljj = new AutoCloseInputStream(this.zzljy);
            }
            return this.zzljj;
        }
    }

    public final Status getStatus() {
        return this.mStatus;
    }

    public final void release() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
*/
        /*
        r2 = this;
        r0 = r2.zzljy;
        if (r0 != 0) goto L_0x0005;
    L_0x0004:
        return;
    L_0x0005:
        r0 = r2.mClosed;
        if (r0 == 0) goto L_0x0011;
    L_0x0009:
        r0 = new java.lang.IllegalStateException;
        r1 = "releasing an already released result.";
        r0.<init>(r1);
        throw r0;
    L_0x0011:
        r0 = r2.zzljj;	 Catch:{ IOException -> 0x0028 }
        if (r0 == 0) goto L_0x001b;	 Catch:{ IOException -> 0x0028 }
    L_0x0015:
        r0 = r2.zzljj;	 Catch:{ IOException -> 0x0028 }
        r0.close();	 Catch:{ IOException -> 0x0028 }
        goto L_0x0020;	 Catch:{ IOException -> 0x0028 }
    L_0x001b:
        r0 = r2.zzljy;	 Catch:{ IOException -> 0x0028 }
        r0.close();	 Catch:{ IOException -> 0x0028 }
    L_0x0020:
        r0 = 1;	 Catch:{ IOException -> 0x0028 }
        r2.mClosed = r0;	 Catch:{ IOException -> 0x0028 }
        r0 = 0;	 Catch:{ IOException -> 0x0028 }
        r2.zzljy = r0;	 Catch:{ IOException -> 0x0028 }
        r2.zzljj = r0;	 Catch:{ IOException -> 0x0028 }
    L_0x0028:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.wearable.internal.zzci.release():void");
    }
}
