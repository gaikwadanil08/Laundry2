package com.google.android.gms.wearable;

import com.google.android.gms.wearable.internal.zzl;

final class zzr implements Runnable {
    private /* synthetic */ zzd zzlho;
    private /* synthetic */ zzl zzlht;

    zzr(zzd zzd, zzl zzl) {
        this.zzlho = zzd;
        this.zzlht = zzl;
    }

    public final void run() {
        this.zzlho.zzlhk.onNotificationReceived(this.zzlht);
    }
}
