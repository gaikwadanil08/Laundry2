package com.google.android.gms.wearable;

/* renamed from: com.google.android.gms.wearable.R */
public final class C0667R {
}
