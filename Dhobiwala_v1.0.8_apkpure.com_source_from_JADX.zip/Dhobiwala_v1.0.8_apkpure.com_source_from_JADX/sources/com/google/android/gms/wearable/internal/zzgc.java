package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.wearable.Channel;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;

final class zzgc implements ChannelListener {
    private final String zzecl;
    private final ChannelListener zzllc;

    zzgc(String str, ChannelListener channelListener) {
        this.zzecl = (String) zzbq.checkNotNull(str);
        this.zzllc = (ChannelListener) zzbq.checkNotNull(channelListener);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzgc)) {
            return false;
        }
        zzgc zzgc = (zzgc) obj;
        return this.zzllc.equals(zzgc.zzllc) && this.zzecl.equals(zzgc.zzecl);
    }

    public final int hashCode() {
        return (this.zzecl.hashCode() * 31) + this.zzllc.hashCode();
    }

    public final void onChannelClosed(Channel channel, int i, int i2) {
        this.zzllc.onChannelClosed(channel, i, i2);
    }

    public final void onChannelOpened(Channel channel) {
        this.zzllc.onChannelOpened(channel);
    }

    public final void onInputClosed(Channel channel, int i, int i2) {
        this.zzllc.onInputClosed(channel, i, i2);
    }

    public final void onOutputClosed(Channel channel, int i, int i2) {
        this.zzllc.onOutputClosed(channel, i, i2);
    }
}
