package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import com.google.android.gms.common.api.internal.zzci;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.zzbq;
import com.google.android.gms.wearable.CapabilityApi.CapabilityListener;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;
import com.google.android.gms.wearable.DataApi.DataListener;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import java.util.List;

public final class zzhk<T> extends zzen {
    private final IntentFilter[] zzlkt;
    private zzci<Object> zzllt;
    private zzci<Object> zzllu;
    private zzci<DataListener> zzllv;
    private zzci<MessageListener> zzllw;
    private zzci<Object> zzllx;
    private zzci<Object> zzlly;
    private zzci<ChannelListener> zzllz;
    private zzci<CapabilityListener> zzlma;
    private final String zzlmb;

    private zzhk(IntentFilter[] intentFilterArr, String str) {
        this.zzlkt = (IntentFilter[]) zzbq.checkNotNull(intentFilterArr);
        this.zzlmb = str;
    }

    public static zzhk<ChannelListener> zza(zzci<ChannelListener> zzci, String str, IntentFilter[] intentFilterArr) {
        zzhk<ChannelListener> zzhk = new zzhk(intentFilterArr, (String) zzbq.checkNotNull(str));
        zzhk.zzllz = (zzci) zzbq.checkNotNull(zzci);
        return zzhk;
    }

    public static zzhk<DataListener> zza(zzci<DataListener> zzci, IntentFilter[] intentFilterArr) {
        zzhk<DataListener> zzhk = new zzhk(intentFilterArr, null);
        zzhk.zzllv = (zzci) zzbq.checkNotNull(zzci);
        return zzhk;
    }

    public static zzhk<MessageListener> zzb(zzci<MessageListener> zzci, IntentFilter[] intentFilterArr) {
        zzhk<MessageListener> zzhk = new zzhk(intentFilterArr, null);
        zzhk.zzllw = (zzci) zzbq.checkNotNull(zzci);
        return zzhk;
    }

    public static zzhk<ChannelListener> zzc(zzci<ChannelListener> zzci, IntentFilter[] intentFilterArr) {
        zzhk<ChannelListener> zzhk = new zzhk(intentFilterArr, null);
        zzhk.zzllz = (zzci) zzbq.checkNotNull(zzci);
        return zzhk;
    }

    public static zzhk<CapabilityListener> zzd(zzci<CapabilityListener> zzci, IntentFilter[] intentFilterArr) {
        zzhk<CapabilityListener> zzhk = new zzhk(intentFilterArr, null);
        zzhk.zzlma = (zzci) zzbq.checkNotNull(zzci);
        return zzhk;
    }

    private static void zzo(zzci<?> zzci) {
        if (zzci != null) {
            zzci.clear();
        }
    }

    public final void clear() {
        zzo(null);
        this.zzllt = null;
        zzo(null);
        this.zzllu = null;
        zzo(this.zzllv);
        this.zzllv = null;
        zzo(this.zzllw);
        this.zzllw = null;
        zzo(null);
        this.zzllx = null;
        zzo(null);
        this.zzlly = null;
        zzo(this.zzllz);
        this.zzllz = null;
        zzo(this.zzlma);
        this.zzlma = null;
    }

    public final void onConnectedNodes(List<zzfo> list) {
    }

    public final void zza(zzah zzah) {
        if (this.zzlma != null) {
            this.zzlma.zza(new zzho(zzah));
        }
    }

    public final void zza(zzaw zzaw) {
        if (this.zzllz != null) {
            this.zzllz.zza(new zzhn(zzaw));
        }
    }

    public final void zza(zzfe zzfe) {
        if (this.zzllw != null) {
            this.zzllw.zza(new zzhm(zzfe));
        }
    }

    public final void zza(zzfo zzfo) {
    }

    public final void zza(zzi zzi) {
    }

    public final void zza(zzl zzl) {
    }

    public final void zzas(DataHolder dataHolder) {
        if (this.zzllv != null) {
            this.zzllv.zza(new zzhl(dataHolder));
        } else {
            dataHolder.close();
        }
    }

    public final void zzb(zzfo zzfo) {
    }

    public final IntentFilter[] zzbkg() {
        return this.zzlkt;
    }

    public final String zzbkh() {
        return this.zzlmb;
    }
}
