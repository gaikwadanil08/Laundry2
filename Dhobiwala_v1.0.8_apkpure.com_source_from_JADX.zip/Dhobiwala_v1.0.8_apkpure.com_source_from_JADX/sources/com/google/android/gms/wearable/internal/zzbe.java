package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.os.RemoteException;
import com.google.android.gms.common.api.Api.zzb;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.zzn;

final class zzbe extends zzn<Status> {
    private /* synthetic */ Uri zzjvt;
    private /* synthetic */ zzay zzljf;
    private /* synthetic */ long zzljh;
    private /* synthetic */ long zzlji;

    zzbe(zzay zzay, GoogleApiClient googleApiClient, Uri uri, long j, long j2) {
        this.zzljf = zzay;
        this.zzjvt = uri;
        this.zzljh = j;
        this.zzlji = j2;
        super(googleApiClient);
    }

    protected final /* synthetic */ void zza(zzb zzb) throws RemoteException {
        ((zzhg) zzb).zza((zzn) this, this.zzljf.zzecl, this.zzjvt, this.zzljh, this.zzlji);
    }

    public final /* synthetic */ Result zzb(Status status) {
        return status;
    }
}
