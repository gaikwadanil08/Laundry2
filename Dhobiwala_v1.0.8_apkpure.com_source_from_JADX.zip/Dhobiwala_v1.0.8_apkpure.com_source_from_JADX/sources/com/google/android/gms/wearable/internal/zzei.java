package com.google.android.gms.wearable.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzei extends IInterface {
    void zzs(int i, int i2) throws RemoteException;
}
