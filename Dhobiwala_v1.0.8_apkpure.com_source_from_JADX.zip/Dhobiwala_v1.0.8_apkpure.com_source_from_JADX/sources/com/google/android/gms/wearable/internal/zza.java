package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;

public class zza extends zzel {
    public void zza(Status status) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzbn zzbn) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzbp zzbp) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzbt zzbt) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzdg zzdg) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzdi zzdi) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzdk zzdk) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzdm zzdm) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzdo zzdo) {
        throw new UnsupportedOperationException();
    }

    @Deprecated
    public final void zza(zzdr zzdr) {
        throw new UnsupportedOperationException();
    }

    public final void zza(zzdt zzdt) {
        throw new UnsupportedOperationException();
    }

    public final void zza(zzdv zzdv) {
        throw new UnsupportedOperationException();
    }

    public final void zza(zzdw zzdw) {
        throw new UnsupportedOperationException();
    }

    public final void zza(zzdy zzdy) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzea zzea) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzec zzec) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzee zzee) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzeg zzeg) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzf zzf) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzfq zzfq) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzfu zzfu) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzfy zzfy) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzga zzga) {
        throw new UnsupportedOperationException();
    }

    public final void zza(zzge zzge) {
        throw new UnsupportedOperationException();
    }

    public void zzat(DataHolder dataHolder) {
        throw new UnsupportedOperationException();
    }

    public void zzb(zzbt zzbt) {
        throw new UnsupportedOperationException();
    }
}
