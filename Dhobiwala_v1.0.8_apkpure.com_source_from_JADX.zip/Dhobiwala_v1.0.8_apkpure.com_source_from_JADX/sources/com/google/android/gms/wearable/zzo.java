package com.google.android.gms.wearable;

import com.google.android.gms.wearable.internal.zzfo;

final class zzo implements Runnable {
    private /* synthetic */ zzd zzlho;
    private /* synthetic */ zzfo zzlhq;

    zzo(zzd zzd, zzfo zzfo) {
        this.zzlho = zzd;
        this.zzlhq = zzfo;
    }

    public final void run() {
        this.zzlho.zzlhk.onPeerDisconnected(this.zzlhq);
    }
}
