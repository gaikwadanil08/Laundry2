package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.internal.zzbfn;

public final class zzm implements Creator<zzl> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        Parcel parcel2 = parcel;
        int zzd = zzbfn.zzd(parcel);
        int i = 0;
        byte b = i;
        byte b2 = b;
        byte b3 = b2;
        byte b4 = b3;
        String str = null;
        String str2 = str;
        String str3 = str2;
        String str4 = str3;
        String str5 = str4;
        String str6 = str5;
        String str7 = str6;
        while (parcel.dataPosition() < zzd) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 2:
                    i = zzbfn.zzg(parcel2, readInt);
                    break;
                case 3:
                    str = zzbfn.zzq(parcel2, readInt);
                    break;
                case 4:
                    str2 = zzbfn.zzq(parcel2, readInt);
                    break;
                case 5:
                    str3 = zzbfn.zzq(parcel2, readInt);
                    break;
                case 6:
                    str4 = zzbfn.zzq(parcel2, readInt);
                    break;
                case 7:
                    str5 = zzbfn.zzq(parcel2, readInt);
                    break;
                case 8:
                    str6 = zzbfn.zzq(parcel2, readInt);
                    break;
                case 9:
                    b = zzbfn.zze(parcel2, readInt);
                    break;
                case 10:
                    b2 = zzbfn.zze(parcel2, readInt);
                    break;
                case 11:
                    b3 = zzbfn.zze(parcel2, readInt);
                    break;
                case 12:
                    b4 = zzbfn.zze(parcel2, readInt);
                    break;
                case 13:
                    str7 = zzbfn.zzq(parcel2, readInt);
                    break;
                default:
                    zzbfn.zzb(parcel2, readInt);
                    break;
            }
        }
        zzbfn.zzaf(parcel2, zzd);
        return new zzl(i, str, str2, str3, str4, str5, str6, b, b2, b3, b4, str7);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new zzl[i];
    }
}
