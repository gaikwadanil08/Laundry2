package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.internal.zzbfm;
import com.google.android.gms.internal.zzbfp;

public final class zzi extends zzbfm {
    public static final Creator<zzi> CREATOR = new zzj();
    private final String mValue;
    private byte zzlib;
    private final byte zzlic;

    public zzi(byte b, byte b2, String str) {
        this.zzlib = b;
        this.zzlic = b2;
        this.mValue = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        zzi zzi = (zzi) obj;
        return this.zzlib == zzi.zzlib && this.zzlic == zzi.zzlic && this.mValue.equals(zzi.mValue);
    }

    public final int hashCode() {
        return ((((this.zzlib + 31) * 31) + this.zzlic) * 31) + this.mValue.hashCode();
    }

    public final String toString() {
        byte b = this.zzlib;
        byte b2 = this.zzlic;
        String str = this.mValue;
        StringBuilder stringBuilder = new StringBuilder(73 + String.valueOf(str).length());
        stringBuilder.append("AmsEntityUpdateParcelable{, mEntityId=");
        stringBuilder.append(b);
        stringBuilder.append(", mAttributeId=");
        stringBuilder.append(b2);
        stringBuilder.append(", mValue='");
        stringBuilder.append(str);
        stringBuilder.append("'}");
        return stringBuilder.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = zzbfp.zze(parcel);
        zzbfp.zza(parcel, 2, this.zzlib);
        zzbfp.zza(parcel, 3, this.zzlic);
        zzbfp.zza(parcel, 4, this.mValue, false);
        zzbfp.zzai(parcel, i);
    }
}
