package com.google.android.gms.wearable.internal;

interface zzbs {
    void zzb(zzav zzav);
}
